package com.campushelper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusHelpApplicationTests {

    @Test
    void contextLoads() {
    }

}
