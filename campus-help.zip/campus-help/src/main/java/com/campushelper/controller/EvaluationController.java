package com.campushelper.controller;

import com.campushelper.dto.EvaluationDTO;
import com.campushelper.entity.User;
import com.campushelper.service.EvaluationService;
import com.campushelper.service.UserService;
import com.campushelper.utils.Result;
import com.campushelper.vo.EvaluationVO;
import com.campushelper.vo.UserEvaluationStatsVO;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/api/evaluations")
@RequiredArgsConstructor
public class EvaluationController {

    private final EvaluationService evaluationService;
    private final UserService userService;

    /**
     * 获取当前用户ID的辅助方法
     */
    private Integer getCurrentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated()) {
            Object principal = authentication.getPrincipal();
            if (principal instanceof User) {
                return ((User) principal).getId();
            } else if (principal instanceof String) {
                User user = userService.getUserByUsername((String) principal);
                return user != null ? user.getId() : null;
            }
        }
        return null;
    }

    /**
     * 提交评价
     */
    @PostMapping
    public ResponseEntity<Result<String>> submitEvaluation(@Validated @RequestBody EvaluationDTO evaluationDTO) {
        try {
            Integer userId = getCurrentUserId();
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "用户未登录"));
            }

            Result<String> result = evaluationService.submitEvaluation(evaluationDTO, userId);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "提交评价失败: " + e.getMessage()));
        }
    }

    /**
     * 获取订单评价列表
     */
    @GetMapping("/order/{orderId}")
    public ResponseEntity<Result<List<EvaluationVO>>> getOrderEvaluations(@PathVariable Integer orderId) {
        try {
            Result<List<?>> result = evaluationService.getEvaluationsByOrderId(orderId);
            if (result.getCode() == 200) {
                @SuppressWarnings("unchecked")
                List<EvaluationVO> data = (List<EvaluationVO>) result.getData();
                return ResponseEntity.ok(Result.success(data));
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Result.error(result.getCode(), result.getMessage()));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取订单评价失败: " + e.getMessage()));
        }
    }

    /**
     * 获取用户收到的评价
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<Result<List<EvaluationVO>>> getUserEvaluations(@PathVariable Integer userId) {
        try {
            Result<List<?>> result = evaluationService.getEvaluationsByUserId(userId);
            if (result.getCode() == 200) {
                @SuppressWarnings("unchecked")
                List<EvaluationVO> data = (List<EvaluationVO>) result.getData();
                return ResponseEntity.ok(Result.success(data));
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Result.error(result.getCode(), result.getMessage()));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取用户评价失败: " + e.getMessage()));
        }
    }

    /**
     * 检查评价状态
     */
    @GetMapping("/check")
    public ResponseEntity<Result<Boolean>> checkEvaluationStatus(@RequestParam Integer orderId) {
        try {
            Integer userId = getCurrentUserId();
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "用户未登录"));
            }

            Result<Boolean> result = evaluationService.checkEvaluationStatus(orderId, userId);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "检查评价状态失败: " + e.getMessage()));
        }
    }

    /**
     * 获取用户评价统计
     */
    @GetMapping("/stats/{userId}")
    public ResponseEntity<Result<UserEvaluationStatsVO>> getUserEvaluationStats(@PathVariable Integer userId) {
        try {
            Result<UserEvaluationStatsVO> result = evaluationService.getUserEvaluationStats(userId);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取评价统计失败: " + e.getMessage()));
        }
    }

    /**
     * 获取我的评价统计
     */
    @GetMapping("/my-stats")
    public ResponseEntity<Result<UserEvaluationStatsVO>> getMyEvaluationStats() {
        try {
            Integer userId = getCurrentUserId();
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "用户未登录"));
            }

            Result<UserEvaluationStatsVO> result = evaluationService.getUserEvaluationStats(userId);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取我的评价统计失败: " + e.getMessage()));
        }
    }

    /**
     * 删除评价（暂未实现）
     */
    @DeleteMapping("/{evaluationId}")
    public ResponseEntity<Result<String>> deleteEvaluation(@PathVariable Integer evaluationId) {
        return ResponseEntity.status(HttpStatus.NOT_IMPLEMENTED)
                .body(Result.error(501, "功能暂未实现"));
    }
}