package com.campushelper.controller;

import com.campushelper.service.OrderService;
import com.campushelper.service.impl.OrderServiceImpl;
import com.campushelper.utils.ExportUtil;
import com.campushelper.utils.Result;
import com.campushelper.vo.OrderStatsVO;
import com.campushelper.vo.OrderVO;
import com.campushelper.vo.PageResult;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/order/admin")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class AdminOrderController {

    private final OrderService orderService;
    private final ExportUtil exportUtil;  // 新增ExportUtil依赖

    // 1. 获取任务统计数据
    @GetMapping("/stats")
    public ResponseEntity<Result<Map<String, Integer>>> getOrderStats() {
        try {
            Map<String, Integer> stats = orderService.getAdminOrderStats();
            return ResponseEntity.ok(Result.success("获取成功", stats));
        } catch (Exception e) {
            log.error("获取任务统计失败", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取失败: " + e.getMessage()));
        }
    }

    // 2. 获取任务列表（带分页和筛选）
    @GetMapping("/list")
    public ResponseEntity<Result<PageResult<OrderVO>>> getOrderList(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer limit,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String publisher,
            @RequestParam(required = false) String runner,
            @RequestParam(required = false) String time,
            @RequestParam(required = false) String search) {

        try {
            PageResult<OrderVO> result = orderService.getAdminOrderList(
                    page, limit, status, category, publisher, runner, time, search);
            return ResponseEntity.ok(Result.success("获取成功", result));
        } catch (Exception e) {
            log.error("获取任务列表失败", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取失败: " + e.getMessage()));
        }
    }

    // 3. 获取任务详情
    @GetMapping("/detail/{orderId}")
    public ResponseEntity<Result<OrderVO>> getOrderDetail(@PathVariable Integer orderId) {
        try {
            OrderVO orderDetail = orderService.getAdminOrderDetail(orderId);
            return ResponseEntity.ok(Result.success("获取成功", orderDetail));
        } catch (Exception e) {
            log.error("获取任务详情失败", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取失败: " + e.getMessage()));
        }
    }

    // 4. 管理员取消订单
    @PutMapping("/cancel/{orderId}")
    public ResponseEntity<Result<Void>> cancelOrder(@PathVariable Integer orderId) {
        try {
            boolean success = orderService.adminCancelOrder(orderId);
            if (success) {
                return ResponseEntity.ok(Result.success("取消成功"));
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Result.error(400, "取消失败"));
            }
        } catch (Exception e) {
            log.error("取消订单失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Result.error(400, "取消失败: " + e.getMessage()));
        }
    }

    // 5. 管理员标记订单完成
    @PutMapping("/complete/{orderId}")
    public ResponseEntity<Result<Void>> completeOrder(@PathVariable Integer orderId) {
        try {
            boolean success = orderService.adminCompleteOrder(orderId);
            if (success) {
                return ResponseEntity.ok(Result.success("标记完成成功"));
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Result.error(400, "标记完成失败"));
            }
        } catch (Exception e) {
            log.error("标记订单完成失败", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Result.error(400, "标记完成失败: " + e.getMessage()));
        }
    }

    // 6. 导出数据（预留接口）
    @GetMapping("/export")
    public ResponseEntity<Result<String>> exportData(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String publisher,
            @RequestParam(required = false) String runner,
            @RequestParam(required = false) String time,
            @RequestParam(required = false) String search) {

        try {
            // 这里可以生成导出文件的URL或返回导出数据
            // 暂时返回成功消息
            return ResponseEntity.ok(Result.success("导出功能开发中"));
        } catch (Exception e) {
            log.error("导出数据失败", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "导出失败: " + e.getMessage()));
        }
    }


    // 导出订单数据为Excel
    @GetMapping("/export/excel")
    public void exportOrdersToExcel(
            HttpServletResponse response,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String publisher,
            @RequestParam(required = false) String runner,
            @RequestParam(required = false) String time,
            @RequestParam(required = false) String search) throws IOException {

        try {
            log.info("开始导出订单Excel数据，参数: status={}, category={}, publisher={}, runner={}, time={}, search={}",
                    status, category, publisher, runner, time, search);

            // 获取要导出的数据
            List<OrderVO> orders = orderService.exportOrders(status, category, publisher, runner, time, search);

            if (orders.isEmpty()) {
                // 如果没有数据，返回空文件或提示信息
                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                response.getWriter().write("{\"code\":400,\"message\":\"没有可导出的数据\"}");
                return;
            }

            // 修复：使用 HashMap 而不是 Map.of()，避免 null 值问题
            Map<String, Object> filterParams = new HashMap<>();
            if (status != null) filterParams.put("status", status);
            if (category != null) filterParams.put("category", category);
            if (publisher != null) filterParams.put("publisher", publisher);
            if (runner != null) filterParams.put("runner", runner);
            if (time != null) filterParams.put("time", time);
            if (search != null) filterParams.put("search", search);

            // 生成导出文件
            byte[] excelBytes = exportUtil.exportOrdersToExcel(orders, filterParams);

            // 设置响应头
            String filename = exportUtil.generateExportFilename("任务数据");
            String encodedFilename = URLEncoder.encode(filename, StandardCharsets.UTF_8.toString())
                    .replaceAll("\\+", "%20");

            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION,
                    "attachment; filename=\"" + encodedFilename + "\"");
            response.setHeader(HttpHeaders.CONTENT_LENGTH, String.valueOf(excelBytes.length));

            // 写入响应流
            response.getOutputStream().write(excelBytes);
            response.getOutputStream().flush();

            log.info("导出Excel成功，文件名: {}，数据量: {}", filename, orders.size());

        } catch (Exception e) {
            log.error("导出Excel失败", e);
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
            response.getWriter().write("{\"code\":500,\"message\":\"导出失败: " + e.getMessage().replace("\"", "'") + "\"}");
        }
    }

    // 导出订单数据为JSON（备用接口）
    @GetMapping("/export/json")
    public ResponseEntity<Result<List<OrderVO>>> exportOrdersToJson(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String publisher,
            @RequestParam(required = false) String runner,
            @RequestParam(required = false) String time,
            @RequestParam(required = false) String search) {

        try {
            // 获取要导出的数据
            List<OrderVO> orders = orderService.exportOrders(status, category, publisher, runner, time, search);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=\"orders_" + System.currentTimeMillis() + ".json\"")
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(Result.success("导出成功", orders));

        } catch (Exception e) {
            log.error("导出JSON失败", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "导出失败: " + e.getMessage()));
        }
    }

    // 获取导出数据预览（用于前端显示）
    @GetMapping("/export/preview")
    public ResponseEntity<Result<Map<String, Object>>> getExportPreview(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String publisher,
            @RequestParam(required = false) String runner,
            @RequestParam(required = false) String time,
            @RequestParam(required = false) String search) {

        try {
            // 获取要导出的数据
            List<OrderVO> orders = orderService.exportOrders(status, category, publisher, runner, time, search);

            Map<String, Object> previewData = Map.of(
                    "total", orders.size(),
                    "sampleData", orders.size() > 10 ? orders.subList(0, Math.min(10, orders.size())) : orders,
                    "filters", Map.of(
                            "status", status != null ? status : "全部",
                            "category", category != null ? category : "全部",
                            "publisher", publisher != null ? publisher : "全部",
                            "runner", runner != null ? runner : "全部",
                            "time", time != null ? time : "全部",
                            "search", search != null ? search : "全部"
                    )
            );

            return ResponseEntity.ok(Result.success("获取导出预览成功", previewData));

        } catch (Exception e) {
            log.error("获取导出预览失败", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取预览失败: " + e.getMessage()));
        }
    }
}