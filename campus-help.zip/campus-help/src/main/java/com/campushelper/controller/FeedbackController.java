package com.campushelper.controller;

import com.campushelper.dto.FeedbackDTO;
import com.campushelper.dto.FeedbackQueryDTO;
import com.campushelper.dto.FeedbackReplyDTO;
import com.campushelper.service.FeedbackService;
import com.campushelper.utils.JwtUtil;
import com.campushelper.utils.Result;
import com.campushelper.vo.FeedbackStatsVO;
import com.campushelper.vo.FeedbackVO;
import com.campushelper.vo.PageResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;  // 改为 jakarta.servlet
import jakarta.validation.Valid;  // 改为 jakarta.validation
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/feedback")
@RequiredArgsConstructor
public class FeedbackController {

    private final FeedbackService feedbackService;
    private final JwtUtil jwtUtil;

    /**
     * 提交反馈
     */
    @PostMapping("/submit")
    public Result<Void> submitFeedback(@Valid @RequestBody FeedbackDTO feedbackDTO,
                                       HttpServletRequest request) {
        Integer userId = (Integer) request.getAttribute("userId");
        feedbackService.submitFeedback(userId, feedbackDTO);
        return Result.success("反馈提交成功");
    }

    /**
     * 获取我的反馈列表
     */
    @GetMapping("/my")
    public Result<List<FeedbackVO>> getMyFeedback(HttpServletRequest request) {
        Integer userId = (Integer) request.getAttribute("userId");
        List<FeedbackVO> feedbackList = feedbackService.getMyFeedback(userId);
        return Result.success(feedbackList);
    }

    /**
     * 获取反馈统计（管理员）
     */
    @GetMapping("/stats")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<FeedbackStatsVO> getFeedbackStats() {
        FeedbackStatsVO stats = feedbackService.getFeedbackStats();
        return Result.success(stats);
    }

    /**
     * 获取反馈列表（管理员）
     */
    @GetMapping("/list")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<PageResult<FeedbackVO>> getFeedbackList(@Validated FeedbackQueryDTO queryDTO) {
        PageResult<FeedbackVO> result = feedbackService.getFeedbackList(queryDTO);
        return Result.success(result);
    }

    /**
     * 获取反馈详情（管理员）
     */
    @GetMapping("/detail/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<FeedbackVO> getFeedbackDetail(@PathVariable Integer id) {
        FeedbackVO feedback = feedbackService.getFeedbackDetail(id);
        return Result.success(feedback);
    }

    /**
     * 回复反馈（管理员）
     */
    @PutMapping("/reply/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> replyFeedback(@PathVariable Integer id,
                                      @Valid @RequestBody FeedbackReplyDTO replyDTO) {
        feedbackService.replyFeedback(id, replyDTO);
        return Result.success("回复成功");
    }

    /**
     * 解决反馈（管理员）
     */
    @PutMapping("/resolve/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<Void> resolveFeedback(@PathVariable Integer id) {
        feedbackService.resolveFeedback(id);
        return Result.success("反馈已标记为已解决");
    }
}