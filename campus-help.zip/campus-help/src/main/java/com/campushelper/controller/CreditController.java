package com.campushelper.controller;

import com.campushelper.service.CreditService;
import com.campushelper.utils.Result;
import com.campushelper.vo.CreditOverviewVO;
import com.campushelper.vo.CreditLogVO;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/credit")
@RequiredArgsConstructor
public class CreditController {

    private final CreditService creditService;

    // 获取当前用户ID的辅助方法
    private Integer getCurrentUserId(HttpServletRequest request) {
        // 先从request属性中获取
        Object userIdObj = request.getAttribute("userId");
        if (userIdObj != null) {
            return (Integer) userIdObj;
        }

        // 如果request中没有，从SecurityContext获取
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated()) {
            Object principal = authentication.getPrincipal();
            if (principal instanceof com.campushelper.entity.User) {
                return ((com.campushelper.entity.User) principal).getId();
            } else if (principal instanceof String) {
                // 如果是用户名，需要通过UserService获取用户ID
                // 这里需要注入UserService，为了简化，我们假设能从request中获取
                return null;
            }
        }
        return null;
    }

    /**
     * 获取信用分概览
     */
    @GetMapping("/overview")
    public ResponseEntity<Result<CreditOverviewVO>> getCreditOverview(HttpServletRequest request) {
        try {
            Integer userId = getCurrentUserId(request);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            CreditOverviewVO overview = creditService.getCreditOverview(userId);
            if (overview == null) {
                return ResponseEntity.ok(Result.error(404, "用户不存在"));
            }

            return ResponseEntity.ok(Result.success("获取成功", overview));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取信用分概览失败: " + e.getMessage()));
        }
    }

    /**
     * 获取信用分变更记录
     */
    @GetMapping("/logs")
    public ResponseEntity<Result<List<CreditLogVO>>> getCreditLogs(
            HttpServletRequest request,
            @RequestParam(defaultValue = "all") String filter) {
        try {
            Integer userId = getCurrentUserId(request);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            List<CreditLogVO> logs = creditService.getCreditLogs(userId, filter);
            return ResponseEntity.ok(Result.success("获取成功", logs));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取信用分记录失败: " + e.getMessage()));
        }
    }

    /**
     * 获取最近N条信用分记录
     */
    @GetMapping("/logs/recent")
    public ResponseEntity<Result<List<CreditLogVO>>> getRecentCreditLogs(
            HttpServletRequest request,
            @RequestParam(defaultValue = "10") Integer limit) {
        try {
            Integer userId = getCurrentUserId(request);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            List<CreditLogVO> logs = creditService.getRecentCreditLogs(userId, limit);
            return ResponseEntity.ok(Result.success("获取成功", logs));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取最近信用分记录失败: " + e.getMessage()));
        }
    }

    /**
     * 获取当前信用分
     */
    @GetMapping("/current")
    public ResponseEntity<Result<Integer>> getCurrentCreditScore(HttpServletRequest request) {
        try {
            Integer userId = getCurrentUserId(request);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            Integer score = creditService.getCurrentCreditScore(userId);
            return ResponseEntity.ok(Result.success("获取成功", score));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取当前信用分失败: " + e.getMessage()));
        }
    }

    /**
     * 更新信用分（供其他服务调用）
     */
    @PostMapping("/update")
    public ResponseEntity<Result<Void>> updateCreditScore(
            @RequestParam Integer userId,
            @RequestParam Integer changeScore,
            @RequestParam String changeType,
            @RequestParam(required = false) String remark,
            @RequestParam(required = false) Integer orderId) {
        try {
            creditService.updateUserCreditScore(userId, changeScore, changeType, remark, orderId);
            return ResponseEntity.ok(Result.success("信用分更新成功"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "更新信用分失败: " + e.getMessage()));
        }
    }

    /**
     * 获取信用分规则
     */
    @GetMapping("/rules")
    public ResponseEntity<Result<List<Object>>> getCreditRules() {
        try {
            // 返回信用分规则
            List<Object> rules = List.of(
                    Map.of(
                            "title", "任务完成",
                            "score", "+5分",
                            "description", "成功完成一个任务，无论是作为发布者还是接单人，都会获得信用分奖励。"
                    ),
                    Map.of(
                            "title", "收到好评",
                            "score", "+3分",
                            "description", "收到其他用户的5星或4星评价，会额外增加信用分。"
                    ),
                    Map.of(
                            "title", "收到差评",
                            "score", "-5分",
                            "description", "收到1星或2星评价，会扣除信用分。"
                    ),
                    Map.of(
                            "title", "无故取消订单",
                            "score", "-10分",
                            "description", "在任务已被接受后无故取消订单，会扣除较多信用分。"
                    ),
                    Map.of(
                            "title", "信用分等级",
                            "description", "0-60分：信用差\n61-80分：信用一般\n81-100分：信用良好\n101-120分：信用优秀\n121分以上：信用极好"
                    ),
                    Map.of(
                            "title", "信用分影响",
                            "description", "信用分越高，发布任务时更容易被接单，接单时也更容易被选择。信用分过低可能无法发布或接取任务。"
                    )
            );

            return ResponseEntity.ok(Result.success("获取成功", rules));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取信用分规则失败: " + e.getMessage()));
        }
    }
}