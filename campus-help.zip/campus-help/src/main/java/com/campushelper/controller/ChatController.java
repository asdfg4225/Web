package com.campushelper.controller;

import com.campushelper.dto.ChatMessageDTO;
import com.campushelper.service.ChatService;
import com.campushelper.utils.Result;
import com.campushelper.vo.ChatListVO;
import com.campushelper.vo.ChatVO;
import com.campushelper.vo.PageResult;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/chat")
@RequiredArgsConstructor
@Validated
public class ChatController {

    private final ChatService chatService;

    /**
     * 获取当前用户ID（统一方法）
     * 优先级：1.从SecurityContext获取 2.从request属性获取
     */
    private Integer getCurrentUserId(HttpServletRequest request) {
        Integer userId = null;

        // 方式1: 从SecurityContext获取（Spring Security认证）
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated()) {
            Object principal = authentication.getPrincipal();
            if (principal instanceof com.campushelper.entity.User) {
                userId = ((com.campushelper.entity.User) principal).getId();
                log.debug("从SecurityContext获取用户ID: {}", userId);
                return userId;
            } else if (principal instanceof org.springframework.security.core.userdetails.UserDetails) {
                // 如果是UserDetails，需要查询用户ID
                String username = ((org.springframework.security.core.userdetails.UserDetails) principal).getUsername();
                log.debug("从SecurityContext获取用户名: {}", username);
                // 这里可以根据用户名查询用户ID，或者直接使用JwtUtil解析
            }
        }

        // 方式2: 从request属性获取（JwtFilter设置的）
        if (userId == null) {
            userId = (Integer) request.getAttribute("userId");
            if (userId != null) {
                log.debug("从request属性获取用户ID: {}", userId);
                return userId;
            }
        }

        // 方式3: 尝试从Authorization header解析（备用）
        if (userId == null) {
            String authHeader = request.getHeader("Authorization");
            if (authHeader != null && authHeader.startsWith("Bearer ")) {
                log.debug("尝试从Authorization header解析用户ID");
                // 这里可以添加JWT解析逻辑，如果需要的话
            }
        }

        if (userId == null) {
            log.warn("无法获取当前用户ID");
        } else {
            log.debug("最终获取的用户ID: {}", userId);
        }

        return userId;
    }

    /**
     * 增强版获取用户ID方法（带详细日志）
     */
    private Integer getCurrentUserIdEnhanced(HttpServletRequest request) {
        Integer userId = null;

        // 记录所有可能的获取方式
        Map<String, Object> debugInfo = new HashMap<>();

        // 1. SecurityContext
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            debugInfo.put("authenticationName", authentication.getName());
            debugInfo.put("isAuthenticated", authentication.isAuthenticated());
            debugInfo.put("principalType", authentication.getPrincipal() != null ?
                    authentication.getPrincipal().getClass().getName() : "null");

            if (authentication.isAuthenticated() && authentication.getPrincipal() instanceof com.campushelper.entity.User) {
                userId = ((com.campushelper.entity.User) authentication.getPrincipal()).getId();
                debugInfo.put("userIdFromSecurity", userId);
            }
        }

        // 2. Request属性
        Integer requestUserId = (Integer) request.getAttribute("userId");
        debugInfo.put("userIdFromRequest", requestUserId);
        if (userId == null && requestUserId != null) {
            userId = requestUserId;
        }

        // 3. Session（如果有）
        Integer sessionUserId = (Integer) request.getSession().getAttribute("userId");
        debugInfo.put("userIdFromSession", sessionUserId);
        if (userId == null && sessionUserId != null) {
            userId = sessionUserId;
        }

        log.debug("用户ID获取调试信息: {}", debugInfo);
        return userId;
    }

    /**
     * 测试用户ID获取
     */
    @GetMapping("/test-userid")
    public Result<Map<String, Object>> testGetUserId(HttpServletRequest request) {
        Integer userId1 = (Integer) request.getAttribute("userId");

        Integer userId2 = null;
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated()) {
            Object principal = authentication.getPrincipal();
            log.info("Principal类型: {}", principal.getClass().getName());
            log.info("Principal值: {}", principal.toString());

            if (principal instanceof com.campushelper.entity.User) {
                userId2 = ((com.campushelper.entity.User) principal).getId();
            }
        }

        // 使用增强方法
        Integer userId3 = getCurrentUserIdEnhanced(request);

        Map<String, Object> result = new HashMap<>();
        result.put("fromRequestAttribute", userId1);
        result.put("fromSecurityContext", userId2);
        result.put("fromEnhancedMethod", userId3);
        result.put("authentication", authentication != null ? authentication.getName() : "null");
        result.put("principalType", authentication != null && authentication.getPrincipal() != null ?
                authentication.getPrincipal().getClass().getName() : "null");

        return Result.success(result);
    }

    /**
     * 获取聊天列表
     */
    @GetMapping("/list")
    public Result<List<ChatListVO>> getChatList(HttpServletRequest request) {
        try {
            Integer userId = getCurrentUserId(request);
            if (userId == null) {
                return Result.error(401, "用户未认证，请重新登录");
            }

            log.info("获取用户 {} 的聊天列表", userId);
            List<ChatListVO> chatList = chatService.getChatList(userId);
            return Result.success(chatList);
        } catch (Exception e) {
            log.error("获取聊天列表失败: {}", e.getMessage(), e);
            return Result.error(500, "获取聊天列表失败: " + e.getMessage());
        }
    }

    /**
     * 获取未读消息数量
     */
    @GetMapping("/unread-count")
    public Result<Integer> getUnreadCount(HttpServletRequest request) {
        try {
            Integer userId = getCurrentUserId(request);
            if (userId == null) {
                log.warn("获取未读消息时用户ID为null");
                return Result.error(401, "用户未认证，请重新登录");
            }

            log.info("获取用户 {} 的未读消息数量", userId);
            Integer count = chatService.getUnreadCount(userId);
            return Result.success(count);
        } catch (Exception e) {
            log.error("获取未读消息数量失败: {}", e.getMessage(), e);
            return Result.error(500, "获取未读消息数量失败: " + e.getMessage());
        }
    }

    /**
     * 获取订单聊天记录
     */
    @GetMapping("/order/{orderId}")
    public Result<List<ChatVO>> getChatByOrderId(@PathVariable Integer orderId,
                                                 HttpServletRequest request) {
        try {
            Integer userId = getCurrentUserId(request);
            if (userId == null) {
                return Result.error(401, "用户未认证，请重新登录");
            }

            List<ChatVO> chatList = chatService.getChatByOrderId(orderId, userId);
            return Result.success(chatList);
        } catch (Exception e) {
            log.error("获取订单聊天记录失败: {}", e.getMessage(), e);
            return Result.error(500, "获取聊天记录失败: " + e.getMessage());
        }
    }

    /**
     * 发送消息
     */
    @PostMapping("/send")
    public Result<Void> sendMessage(@Valid @RequestBody ChatMessageDTO chatMessageDTO,
                                    HttpServletRequest request) {
        try {
            Integer userId = getCurrentUserId(request);
            if (userId == null) {
                return Result.error(401, "用户未认证，请重新登录");
            }

            chatService.sendMessage(chatMessageDTO, userId);
            return Result.success();
        } catch (Exception e) {
            log.error("发送消息失败: {}", e.getMessage(), e);
            return Result.error(500, "发送消息失败: " + e.getMessage());
        }
    }

    /**
     * 标记消息为已读
     */
    @PostMapping("/mark-read/{orderId}")
    public Result<Void> markMessagesAsRead(@PathVariable Integer orderId,
                                           HttpServletRequest request) {
        try {
            Integer userId = getCurrentUserId(request);
            if (userId == null) {
                return Result.error(401, "用户未认证，请重新登录");
            }

            chatService.markMessagesAsRead(orderId, userId);
            return Result.success();
        } catch (Exception e) {
            log.error("标记消息已读失败: {}", e.getMessage(), e);
            return Result.error(500, "标记消息已读失败: " + e.getMessage());
        }
    }

    /**
     * 获取聊天记录（分页）
     */
    @GetMapping("/messages")
    public Result<PageResult<ChatVO>> getChatMessages(
            @RequestParam Integer orderId,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "20") Integer size,
            HttpServletRequest request) {

        try {
            Integer userId = getCurrentUserId(request);
            if (userId == null) {
                return Result.error(401, "用户未认证，请重新登录");
            }

            PageResult<ChatVO> result = chatService.getChatMessages(orderId, userId, page, size);
            return Result.success(result);
        } catch (Exception e) {
            log.error("获取分页聊天记录失败: {}", e.getMessage(), e);
            return Result.error(500, "获取聊天记录失败: " + e.getMessage());
        }
    }

    /**
     * 获取订单的最后一条消息
     */
    @GetMapping("/last/{orderId}")
    public Result<String> getLastMessage(@PathVariable Integer orderId,
                                         HttpServletRequest request) {
        try {
            Integer userId = getCurrentUserId(request);
            if (userId == null) {
                return Result.error(401, "用户未认证，请重新登录");
            }

            List<ChatVO> chatList = chatService.getChatByOrderId(orderId, userId);
            if (chatList != null && !chatList.isEmpty()) {
                ChatVO lastMessage = chatList.get(chatList.size() - 1);
                return Result.success(lastMessage.getContent());
            }
            return Result.success("还没有消息");
        } catch (Exception e) {
            log.error("获取最后一条消息失败: {}", e.getMessage(), e);
            return Result.error(500, "无法获取消息");
        }
    }
}