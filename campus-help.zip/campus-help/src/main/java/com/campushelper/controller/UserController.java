package com.campushelper.controller;

import com.campushelper.entity.User;
import com.campushelper.service.ChatService;
import com.campushelper.service.UserService;
import com.campushelper.utils.Result;
import com.campushelper.vo.UserVO;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/user")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;
    private final ChatService chatService;

    // 获取当前用户ID的辅助方法（从HttpServletRequest获取）
    private Integer getCurrentUserId(HttpServletRequest request) {
        return (Integer) request.getAttribute("userId");
    }

    // 获取当前用户ID的辅助方法（从SecurityContext获取）
    private Integer getCurrentUserIdFromSecurity() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated()) {
            Object principal = authentication.getPrincipal();
            if (principal instanceof User) {
                return ((User) principal).getId();
            } else if (principal instanceof String) {
                User user = userService.getUserByUsername((String) principal);
                return user != null ? user.getId() : null;
            }
        }
        return null;
    }

    @GetMapping("/profile")
    public ResponseEntity<Result> getProfile() {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication != null && authentication.isAuthenticated()) {
                Object principal = authentication.getPrincipal();

                if (principal instanceof User) {
                    User user = (User) principal;
                    UserVO userVO = userService.getUserProfile(user.getId());
                    return ResponseEntity.ok(Result.success("获取成功", userVO));
                } else if (principal instanceof String) {
                    // 如果是username，通过username获取用户
                    String username = (String) principal;
                    User user = userService.getUserByUsername(username);
                    if (user != null) {
                        UserVO userVO = userService.getUserProfile(user.getId());
                        return ResponseEntity.ok(Result.success("获取成功", userVO));
                    }
                }

                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "用户信息异常"));
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取用户信息失败: " + e.getMessage()));
        }
    }

    @PutMapping("/profile")
    public ResponseEntity<Result> updateProfile(@RequestBody User user) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication != null && authentication.isAuthenticated()) {
                Object principal = authentication.getPrincipal();
                Integer userId = null;

                if (principal instanceof User) {
                    userId = ((User) principal).getId();
                } else if (principal instanceof String) {
                    User currentUser = userService.getUserByUsername((String) principal);
                    if (currentUser != null) {
                        userId = currentUser.getId();
                    }
                }

                if (userId != null) {
                    user.setId(userId);
                    userService.updateUser(user);
                    return ResponseEntity.ok(Result.success("更新成功"));
                } else {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                            .body(Result.error(401, "用户信息异常"));
                }
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "更新失败: " + e.getMessage()));
        }
    }

    @PostMapping("/switch-role")
    public ResponseEntity<Result> switchRole(@RequestParam String role) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication != null && authentication.isAuthenticated()) {
                Object principal = authentication.getPrincipal();
                Integer userId = null;

                if (principal instanceof User) {
                    userId = ((User) principal).getId();
                } else if (principal instanceof String) {
                    User currentUser = userService.getUserByUsername((String) principal);
                    if (currentUser != null) {
                        userId = currentUser.getId();
                    }
                }

                if (userId != null) {
                    userService.switchRole(userId, role);
                    return ResponseEntity.ok(Result.success("角色切换成功"));
                } else {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                            .body(Result.error(401, "用户信息异常"));
                }
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "角色切换失败: " + e.getMessage()));
        }
    }

    /**
     * 获取未读消息数量
     */
    @GetMapping("/unread-count")
    public ResponseEntity<Result<Integer>> getUnreadCount(HttpServletRequest request) {
        try {
            Integer userId = getCurrentUserId(request);
            if (userId == null) {
                userId = getCurrentUserIdFromSecurity();
            }

            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            Integer count = chatService.getUnreadCount(userId);
            return ResponseEntity.ok(Result.success(count));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取未读消息失败: " + e.getMessage()));
        }
    }
}