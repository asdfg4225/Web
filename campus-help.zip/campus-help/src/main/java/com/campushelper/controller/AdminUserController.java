package com.campushelper.controller;

import com.campushelper.dto.*;
import com.campushelper.service.UserAdminService;
import com.campushelper.utils.ExportUtil;
import com.campushelper.utils.Result;
import com.campushelper.vo.AdminUserDetailVO;
import com.campushelper.vo.AdminUserListVO;
import com.campushelper.dto.UserStatsDTO;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/user/admin")
@RequiredArgsConstructor
public class AdminUserController {

    private final UserAdminService userAdminService;
    private final ExportUtil exportUtil;  // 新增ExportUtil依赖

    /**
     * 获取用户统计信息
     */
    @GetMapping("/stats")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Result<UserStatsDTO>> getStats() {
        UserStatsDTO stats = userAdminService.getUserStats();
        return ResponseEntity.ok(Result.success(stats));
    }

    /**
     * 获取用户列表（分页+筛选）
     */
    @GetMapping("/list")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Result<AdminUserListVO>> getUserList(@Valid UserQueryDTO queryDTO) {
        AdminUserListVO result = userAdminService.getUserList(queryDTO);
        return ResponseEntity.ok(Result.success(result));
    }

    /**
     * 获取用户详情
     */
    @GetMapping("/detail/{userId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Result<AdminUserDetailVO>> getUserDetail(@PathVariable Integer userId) {
        AdminUserDetailVO detail = userAdminService.getUserDetail(userId);
        return ResponseEntity.ok(Result.success(detail));
    }

    /**
     * 认证用户
     */
    @PutMapping("/verify/{userId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Result<Void>> verifyUser(@PathVariable Integer userId) {
        userAdminService.verifyUser(userId);
        return ResponseEntity.ok(Result.success("用户认证成功"));
    }

    /**
     * 封禁用户
     */
    @PutMapping("/ban/{userId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Result<Void>> banUser(@PathVariable Integer userId,
                                                @RequestBody(required = false) BanUserDTO banUserDTO) {
        userAdminService.banUser(userId, banUserDTO != null ? banUserDTO.getReason() : null);
        return ResponseEntity.ok(Result.success("用户封禁成功"));
    }

    /**
     * 解封用户
     */
    @PutMapping("/unban/{userId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Result<Void>> unbanUser(@PathVariable Integer userId) {
        userAdminService.unbanUser(userId);
        return ResponseEntity.ok(Result.success("用户解封成功"));
    }

    /**
     * 重置用户密码
     */
    @PostMapping("/reset-password/{userId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Result<String>> resetPassword(@PathVariable Integer userId) {
        String newPassword = userAdminService.resetPassword(userId);
        return ResponseEntity.ok(Result.success("密码重置成功", newPassword));
    }

    /**
     * 更新用户信息
     */
    @PutMapping("/update/{userId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Result<Void>> updateUser(@PathVariable Integer userId,
                                                   @RequestBody UpdateUserDTO updateUserDTO) {
        userAdminService.updateUser(userId, updateUserDTO);
        return ResponseEntity.ok(Result.success("用户信息更新成功"));
    }

    /**
     * 删除用户
     */
    @DeleteMapping("/delete/{userId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Result<Void>> deleteUser(@PathVariable Integer userId) {
        userAdminService.deleteUser(userId);
        return ResponseEntity.ok(Result.success("用户删除成功"));
    }

    /**
     * 批量认证用户
     */
    @PostMapping("/bulk-verify")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Result<Void>> bulkVerify(@RequestBody BulkActionDTO bulkActionDTO) {
        userAdminService.bulkVerify(bulkActionDTO.getUserIds());
        return ResponseEntity.ok(Result.success("批量认证成功"));
    }

    /**
     * 批量封禁用户
     */
    @PostMapping("/bulk-ban")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Result<Void>> bulkBan(@RequestBody BulkActionDTO bulkActionDTO) {
        userAdminService.bulkBan(bulkActionDTO.getUserIds(), bulkActionDTO.getReason());
        return ResponseEntity.ok(Result.success("批量封禁成功"));
    }

    /**
     * 批量重置密码
     */
    @PostMapping("/bulk-reset-password")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Result<List<String>>> bulkResetPassword(@RequestBody BulkActionDTO bulkActionDTO) {
        List<String> newPasswords = userAdminService.bulkResetPassword(bulkActionDTO.getUserIds());
        return ResponseEntity.ok(Result.success("批量重置密码成功", newPasswords));
    }

    /**
     * 批量删除用户
     */
    @DeleteMapping("/bulk-delete")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Result<Void>> bulkDelete(@RequestBody BulkActionDTO bulkActionDTO) {
        userAdminService.bulkDelete(bulkActionDTO.getUserIds());
        return ResponseEntity.ok(Result.success("批量删除成功"));
    }

    /**
     * 导出用户数据为Excel
     */
    @GetMapping("/export/excel")
    @PreAuthorize("hasRole('ADMIN')")
    public void exportUsersToExcel(
            HttpServletResponse response,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String college,
            @RequestParam(required = false) String grade,
            @RequestParam(required = false) String time,
            @RequestParam(required = false) String search) throws IOException {

        try {
            log.info("开始导出用户Excel数据，参数: status={}, college={}, grade={}, time={}, search={}",
                    status, college, grade, time, search);

            // 构建查询条件
            UserQueryDTO queryDTO = new UserQueryDTO();
            queryDTO.setStatus(status);
            queryDTO.setCollege(college);
            queryDTO.setGrade(grade);
            queryDTO.setTime(time);
            queryDTO.setSearch(search);

            // 获取要导出的数据
            List<AdminUserDTO> users = userAdminService.exportUsers(queryDTO);

            if (users.isEmpty()) {
                // 如果没有数据，返回空文件或提示信息
                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                response.getWriter().write("{\"code\":400,\"message\":\"没有可导出的数据\"}");
                return;
            }

            // 构建筛选参数
            Map<String, Object> filterParams = new HashMap<>();
            if (status != null) filterParams.put("status", status);
            if (college != null) filterParams.put("college", college);
            if (grade != null) filterParams.put("grade", grade);
            if (time != null) filterParams.put("time", time);
            if (search != null) filterParams.put("search", search);

            // 生成导出文件
            byte[] excelBytes = exportUtil.exportUsersToExcel(users, filterParams);

            // 设置响应头
            String filename = exportUtil.generateExportFilename("用户数据");
            String encodedFilename = URLEncoder.encode(filename, StandardCharsets.UTF_8.toString())
                    .replaceAll("\\+", "%20");

            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            response.setHeader(HttpHeaders.CONTENT_DISPOSITION,
                    "attachment; filename=\"" + encodedFilename + "\"");
            response.setHeader(HttpHeaders.CONTENT_LENGTH, String.valueOf(excelBytes.length));

            // 写入响应流
            response.getOutputStream().write(excelBytes);
            response.getOutputStream().flush();

            log.info("导出Excel成功，文件名: {}，数据量: {}", filename, users.size());

        } catch (Exception e) {
            log.error("导出Excel失败", e);
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
            response.getWriter().write("{\"code\":500,\"message\":\"导出失败: " + e.getMessage().replace("\"", "'") + "\"}");
        }
    }

    /**
     * 导出用户数据为JSON（备用接口）
     */
    @GetMapping("/export/json")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Result<List<AdminUserDTO>>> exportUsersToJson(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String college,
            @RequestParam(required = false) String grade,
            @RequestParam(required = false) String time,
            @RequestParam(required = false) String search) {

        try {
            // 构建查询条件
            UserQueryDTO queryDTO = new UserQueryDTO();
            queryDTO.setStatus(status);
            queryDTO.setCollege(college);
            queryDTO.setGrade(grade);
            queryDTO.setTime(time);
            queryDTO.setSearch(search);

            // 获取要导出的数据
            List<AdminUserDTO> users = userAdminService.exportUsers(queryDTO);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=\"users_" + System.currentTimeMillis() + ".json\"")
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(Result.success("导出成功", users));

        } catch (Exception e) {
            log.error("导出JSON失败", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "导出失败: " + e.getMessage()));
        }
    }

    /**
     * 获取导出数据预览（用于前端显示）
     */
    @GetMapping("/export/preview")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Result<Map<String, Object>>> getExportPreview(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String college,
            @RequestParam(required = false) String grade,
            @RequestParam(required = false) String time,
            @RequestParam(required = false) String search) {

        try {
            // 构建查询条件
            UserQueryDTO queryDTO = new UserQueryDTO();
            queryDTO.setStatus(status);
            queryDTO.setCollege(college);
            queryDTO.setGrade(grade);
            queryDTO.setTime(time);
            queryDTO.setSearch(search);

            // 获取要导出的数据
            List<AdminUserDTO> users = userAdminService.exportUsers(queryDTO);

            Map<String, Object> previewData = new HashMap<>();
            previewData.put("total", users.size());
            previewData.put("sampleData", users.size() > 10 ? users.subList(0, Math.min(10, users.size())) : users);

            Map<String, String> filters = new HashMap<>();
            filters.put("status", status != null ? status : "全部");
            filters.put("college", college != null ? college : "全部");
            filters.put("grade", grade != null ? grade : "全部");
            filters.put("time", time != null ? time : "全部");
            filters.put("search", search != null ? search : "全部");
            previewData.put("filters", filters);

            return ResponseEntity.ok(Result.success("获取导出预览成功", previewData));

        } catch (Exception e) {
            log.error("获取导出预览失败", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取预览失败: " + e.getMessage()));
        }
    }
}