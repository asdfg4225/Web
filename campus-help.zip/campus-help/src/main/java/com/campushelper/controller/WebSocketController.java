package com.campushelper.controller;

import com.campushelper.dto.ChatMessageDTO;
import com.campushelper.service.WebSocketChatService;
import com.campushelper.utils.JwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.stereotype.Controller;

import java.security.Principal;

@Slf4j
@Controller
@RequiredArgsConstructor
public class WebSocketController {

    private final WebSocketChatService webSocketChatService;
    private final JwtUtil jwtUtil;

    /**
     * 处理聊天消息
     * 客户端发送到 /app/chat.sendMessage
     */
    @MessageMapping("/chat.sendMessage")
    public void sendMessage(@Payload ChatMessageDTO chatMessageDTO,
                            Principal principal,
                            SimpMessageHeaderAccessor headerAccessor) {

        // 从Principal获取用户ID
        String username = principal.getName();
        Integer userId = Integer.parseInt(username);

        // 发送消息
        webSocketChatService.sendMessage(chatMessageDTO, userId);
    }

    /**
     * 用户加入聊天
     * 客户端发送到 /app/chat.addUser
     */
    @MessageMapping("/chat.addUser")
    public void addUser(@Payload ChatMessageDTO chatMessageDTO,
                        Principal principal,
                        SimpMessageHeaderAccessor headerAccessor) {

        String username = principal.getName();
        Integer userId = Integer.parseInt(username);

        // 可以在这里添加用户到会话中
        headerAccessor.getSessionAttributes().put("userId", userId);
        headerAccessor.getSessionAttributes().put("orderId", chatMessageDTO.getOrderId());

        log.info("用户 {} 加入订单 {} 的聊天", userId, chatMessageDTO.getOrderId());
    }
}