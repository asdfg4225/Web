package com.campushelper.controller;

import com.campushelper.dto.RechargeDTO;
import com.campushelper.dto.WithdrawDTO;
import com.campushelper.service.BalanceService;
import com.campushelper.utils.Result;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/balance")
@RequiredArgsConstructor
public class BalanceController {

    private final BalanceService balanceService;

    /**
     * 获取余额概览
     */
    @GetMapping("/overview")
    public Result<?> getBalanceOverview(HttpServletRequest request) {
        Integer userId = (Integer) request.getAttribute("userId");
        if (userId == null) {
            return Result.error(401, "未登录");
        }

        return balanceService.getBalanceOverview(userId);
    }

    /**
     * 获取余额变动记录
     */
    @GetMapping("/logs")
    public Result<?> getBalanceLogs(
            HttpServletRequest request,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "20") Integer size) {

        Integer userId = (Integer) request.getAttribute("userId");
        if (userId == null) {
            return Result.error(401, "未登录");
        }

        return balanceService.getBalanceLogs(userId, page, size);
    }

    /**
     * 发起充值
     */
    @PostMapping("/recharge")
    public Result<?> recharge(@Validated @RequestBody RechargeDTO dto, HttpServletRequest request) {
        Integer userId = (Integer) request.getAttribute("userId");
        if (userId == null) {
            return Result.error(401, "未登录");
        }

        try {
            return balanceService.recharge(userId, dto.getAmount(), dto.getPaymentMethod());
        } catch (Exception e) {
            log.error("充值失败", e);
            return Result.error(500, e.getMessage());
        }
    }

    /**
     * 支付回调（微信/支付宝）
     */
    @PostMapping("/callback/{paymentMethod}")
    public String handlePaymentCallback(
            @PathVariable String paymentMethod,
            @RequestBody String callbackData) {

        log.info("收到{}支付回调: {}", paymentMethod, callbackData);

        // 解析回调数据，获取支付状态和订单号
        // 实际应根据支付平台文档解析

        String paymentNo = "从回调数据中解析";
        String status = "从回调数据中解析";

        // 处理充值回调
        balanceService.handleRechargeCallback(paymentNo, status);

        return "success";  // 返回给支付平台的成功响应
    }

    /**
     * 检查余额是否充足
     */
    @GetMapping("/check")
    public Result<?> checkBalance(HttpServletRequest request, @RequestParam BigDecimal amount) {
        Integer userId = (Integer) request.getAttribute("userId");
        if (userId == null) {
            return Result.error(401, "未登录");
        }

        boolean isSufficient = balanceService.checkBalance(userId, amount);
        return Result.success(isSufficient ? "余额充足" : "余额不足", isSufficient);
    }

    /**
     * 消费扣款（内部调用）
     */
    @PostMapping("/consume")
    public Result<?> consume(
            @RequestParam Integer userId,
            @RequestParam BigDecimal amount,
            @RequestParam Integer orderId,
            @RequestParam(defaultValue = "订单支付") String remark) {

        return balanceService.consume(userId, amount, orderId, remark);
    }

    // 在BalanceController.java中添加提现相关接口
    /**
     * 提现申请
     */
    @PostMapping("/withdraw")
    public Result<?> withdraw(@Validated @RequestBody WithdrawDTO dto, HttpServletRequest request) {
        Integer userId = (Integer) request.getAttribute("userId");
        if (userId == null) {
            return Result.error(401, "未登录");
        }

        try {
            return balanceService.withdraw(userId, dto.getAmount(), dto.getMethod(), dto.getRemark());
        } catch (Exception e) {
            log.error("提现失败", e);
            return Result.error(500, e.getMessage());
        }
    }

    /**
     * 提现回调（模拟）
     */
    @PostMapping("/withdraw/callback")
    public String handleWithdrawCallback(@RequestBody Map<String, String> callbackData) {
        String withdrawNo = callbackData.get("withdrawNo");
        String status = callbackData.get("status");

        log.info("收到提现回调: {}, 状态: {}", withdrawNo, status);

        balanceService.handleWithdrawCallback(withdrawNo, status);

        return "success";
    }

    /**
     * 获取提现状态
     */
    @GetMapping("/withdraw/status/{withdrawNo}")
    public Result<?> getWithdrawStatus(@PathVariable String withdrawNo, HttpServletRequest request) {
        Integer userId = (Integer) request.getAttribute("userId");
        if (userId == null) {
            return Result.error(401, "未登录");
        }

        return balanceService.getWithdrawStatus(withdrawNo);
    }

    /**
     * 获取提现记录
     */
    @GetMapping("/withdraw/logs")
    public Result<?> getWithdrawLogs(
            HttpServletRequest request,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "20") Integer size) {

        Integer userId = (Integer) request.getAttribute("userId");
        if (userId == null) {
            return Result.error(401, "未登录");
        }

        return balanceService.getWithdrawLogs(userId, page, size);
    }

    /**
     * 计算提现手续费
     */
    @GetMapping("/withdraw/fee")
    public Result<?> calculateWithdrawFee(
            @RequestParam BigDecimal amount,
            @RequestParam String method,
            HttpServletRequest request) {

        Integer userId = (Integer) request.getAttribute("userId");
        if (userId == null) {
            return Result.error(401, "未登录");
        }

        return balanceService.calculateWithdrawFee(amount, method, userId);
    }

    /**
     * 检查是否可以提现
     */
    @GetMapping("/withdraw/check")
    public Result<?> checkWithdrawAvailable(HttpServletRequest request) {
        Integer userId = (Integer) request.getAttribute("userId");
        if (userId == null) {
            return Result.error(401, "未登录");
        }

        return balanceService.checkWithdrawAvailable(userId);
    }
}