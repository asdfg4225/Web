package com.campushelper.controller;

import com.campushelper.dto.OrderDTO;
import com.campushelper.entity.User;
import com.campushelper.service.OrderService;
import com.campushelper.utils.Result;
import com.campushelper.vo.OrderLogVO;
import com.campushelper.vo.OrderStatsVO;
import com.campushelper.vo.OrderVO;
import com.campushelper.vo.PageResult;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;

    // 分页查询任务列表（任务大厅）
    @GetMapping
    public ResponseEntity<Result> getOrders(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String search) {  // 可选搜索参数
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer userId = getCurrentUserId(authentication);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            // 对于任务大厅，默认只显示待接单的任务
            if (status == null || status.isEmpty()) {
                status = "pending";
            }

            // 调用分页查询方法
            PageResult<OrderVO> pageResult = orderService.getOrderPage(userId, page, size, status, category);
            return ResponseEntity.ok(Result.success("获取成功", pageResult));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取失败: " + e.getMessage()));
        }
    }

    // 发布任务
    @PostMapping
    public ResponseEntity<Result> publishOrder(@RequestBody OrderDTO orderDTO) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer userId = getCurrentUserId(authentication);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            var order = orderService.publishTask(orderDTO, userId);
            return ResponseEntity.ok(Result.success("发布成功", order));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Result.error(400, "发布失败: " + e.getMessage()));
        }
    }

    // 接取任务
    @PostMapping("/{orderId}/accept")
    public ResponseEntity<Result> acceptOrder(@PathVariable Integer orderId) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer userId = getCurrentUserId(authentication);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            boolean success = orderService.acceptTask(orderId, userId);
            if (success) {
                return ResponseEntity.ok(Result.success("接单成功"));
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Result.error(400, "接单失败"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Result.error(400, "接单失败: " + e.getMessage()));
        }
    }

    // 获取可接取的任务列表
    @GetMapping("/available")
    public ResponseEntity<Result> getAvailableTasks() {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer userId = getCurrentUserId(authentication);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            List<OrderVO> tasks = orderService.getAvailableTasks(userId);
            return ResponseEntity.ok(Result.success("获取成功", tasks));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取失败: " + e.getMessage()));
        }
    }

    // 获取我发布的任务
    @GetMapping("/my-published")
    public ResponseEntity<Result> getMyPublishedTasks() {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer userId = getCurrentUserId(authentication);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            List<OrderVO> tasks = orderService.getMyPublishedTasks(userId);
            return ResponseEntity.ok(Result.success("获取成功", tasks));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取失败: " + e.getMessage()));
        }
    }

    // 获取我接取的任务
    @GetMapping("/my-accepted")
    public ResponseEntity<Result> getMyAcceptedTasks() {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer userId = getCurrentUserId(authentication);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            List<OrderVO> tasks = orderService.getMyAcceptedTasks(userId);
            return ResponseEntity.ok(Result.success("获取成功", tasks));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取失败: " + e.getMessage()));
        }
    }

    // 获取任务详情
    @GetMapping("/{orderId}")
    public ResponseEntity<Result> getOrderDetail(@PathVariable Integer orderId) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer userId = getCurrentUserId(authentication);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            OrderVO orderDetail = orderService.getOrderDetail(orderId, userId);
            return ResponseEntity.ok(Result.success("获取成功", orderDetail));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Result.error(400, "获取失败: " + e.getMessage()));
        }
    }

    // 取消任务
    @PostMapping("/{orderId}/cancel")
    public ResponseEntity<Result> cancelOrder(@PathVariable Integer orderId) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer userId = getCurrentUserId(authentication);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            boolean success = orderService.cancelTask(orderId, userId);
            if (success) {
                return ResponseEntity.ok(Result.success("取消成功"));
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Result.error(400, "取消失败"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Result.error(400, "取消失败: " + e.getMessage()));
        }
    }

    // 开始任务
    @PostMapping("/{orderId}/start")
    public ResponseEntity<Result> startOrder(@PathVariable Integer orderId) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer userId = getCurrentUserId(authentication);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            boolean success = orderService.startTask(orderId, userId);
            if (success) {
                return ResponseEntity.ok(Result.success("开始成功"));
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Result.error(400, "开始失败"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Result.error(400, "开始失败: " + e.getMessage()));
        }
    }

    // 完成任务
    @PostMapping("/{orderId}/complete")
    public ResponseEntity<Result> completeOrder(@PathVariable Integer orderId) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer userId = getCurrentUserId(authentication);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            boolean success = orderService.completeTask(orderId, userId);
            if (success) {
                return ResponseEntity.ok(Result.success("完成成功"));
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Result.error(400, "完成失败"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Result.error(400, "完成失败: " + e.getMessage()));
        }
    }

    // 获取任务统计
    @GetMapping("/stats")
    public ResponseEntity<Result> getOrderStats() {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer userId = getCurrentUserId(authentication);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            OrderStatsVO stats = orderService.getOrderStats(userId);
            return ResponseEntity.ok(Result.success("获取成功", stats));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取失败: " + e.getMessage()));
        }
    }

    // 辅助方法：从认证信息中获取当前用户ID
    private Integer getCurrentUserId(Authentication authentication) {
        if (authentication != null && authentication.isAuthenticated()) {
            Object principal = authentication.getPrincipal();
            if (principal instanceof User) {
                return ((User) principal).getId();
            } else if (principal instanceof String) {
                // 如果是username，可以通过userService获取用户信息
                // 这里简化处理，实际应该根据具体情况处理
                return null;
            }
        }
        return null;
    }

    // 获取订单状态日志
    @GetMapping("/{orderId}/logs")
    public ResponseEntity<Result> getOrderLogs(@PathVariable Integer orderId) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer userId = getCurrentUserId(authentication);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            // 验证权限
            OrderVO orderDetail = orderService.getOrderDetail(orderId, userId);
            if (orderDetail == null) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(Result.error(403, "无权查看此任务日志"));
            }

            List<OrderLogVO> logs = orderService.getOrderLogs(orderId);
            return ResponseEntity.ok(Result.success("获取成功", logs));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Result.error(400, "获取失败: " + e.getMessage()));
        }
    }

    // 发布者确认完成
    @PostMapping("/{orderId}/confirm/publisher")
    public ResponseEntity<Result> confirmByPublisher(@PathVariable Integer orderId) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer userId = getCurrentUserId(authentication);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            boolean success = orderService.confirmByPublisher(orderId, userId);
            if (success) {
                return ResponseEntity.ok(Result.success("确认成功"));
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Result.error(400, "确认失败"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Result.error(400, "确认失败: " + e.getMessage()));
        }
    }

    // 接单人确认完成
    @PostMapping("/{orderId}/confirm/runner")
    public ResponseEntity<Result> confirmByRunner(@PathVariable Integer orderId) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer userId = getCurrentUserId(authentication);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            boolean success = orderService.confirmByRunner(orderId, userId);
            if (success) {
                return ResponseEntity.ok(Result.success("确认成功"));
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Result.error(400, "确认失败"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Result.error(400, "确认失败: " + e.getMessage()));
        }
    }

    // 按状态搜索订单
    @GetMapping("/search")
    public ResponseEntity<Result> searchOrders(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String keyword) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer userId = getCurrentUserId(authentication);
            if (userId == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }

            // 这里可以调用专门的搜索方法，暂时使用现有方法
            PageResult<OrderVO> pageResult = orderService.getOrderPage(userId, page, size, status, category);
            return ResponseEntity.ok(Result.success("获取成功", pageResult));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "搜索失败: " + e.getMessage()));
        }
    }
}