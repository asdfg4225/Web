package com.campushelper.controller;

import com.campushelper.dto.*;
import com.campushelper.entity.User;
import com.campushelper.service.AuthService;
import com.campushelper.utils.Result;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
//valid 数据校验
    //@Requestbody json数据转化为java对象
    @PostMapping("/login")
    public ResponseEntity<Result> login(@Valid @RequestBody LoginDTO loginDTO) {
        try {
            AuthResponseDTO response = authService.login(loginDTO);
            return ResponseEntity.ok(Result.success("登录成功", response));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Result.error(401, "登录失败: " + e.getMessage()));
        }
    }

    @PostMapping("/register")
    public ResponseEntity<Result> register(@Valid @RequestBody RegisterDTO registerDTO) {
        try {
            authService.register(registerDTO);
            return ResponseEntity.ok(Result.success("注册成功"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Result.error(400, "注册失败: " + e.getMessage()));
        }
    }

/*    @PostMapping("/register/wx")
    public ResponseEntity<Result> wxRegister(@Valid @RequestBody RegisterUserDTO registerDTO) {
        try {
            authService.wxRegister(registerDTO);
            return ResponseEntity.ok(Result.success("微信注册成功"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Result.error(400, "微信注册失败: " + e.getMessage()));
        }
    }*/

    @PostMapping("/logout")
    public ResponseEntity<Result> logout(HttpServletRequest request) {
        try {
            String token = getTokenFromRequest(request);
            if (token != null) {
                authService.logout(token);
            }
            SecurityContextHolder.clearContext();
            return ResponseEntity.ok(Result.success("退出成功"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Result.error(400, "退出失败: " + e.getMessage()));
        }
    }

    @GetMapping("/me")
    public ResponseEntity<Result> getCurrentUser() {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication != null && authentication.isAuthenticated()) {
                Object principal = authentication.getPrincipal();

                if (principal instanceof User) {
                    User user = (User) principal;
                    UserDTO userDTO = new UserDTO();
                    BeanUtils.copyProperties(user, userDTO);
                    // 确保username字段有值
                    userDTO.setUsername(user.getStudentId());
                    userDTO.setStudentId(user.getStudentId());

                    return ResponseEntity.ok(Result.success("获取成功", userDTO));
                }

                return ResponseEntity.ok(Result.success("获取成功", principal));
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Result.error(401, "未认证"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Result.error(500, "获取用户信息失败: " + e.getMessage()));
        }
    }

    @GetMapping("/health")
    public ResponseEntity<Result> health() {
        return ResponseEntity.ok(Result.success("服务正常运行"));
    }

    private String getTokenFromRequest(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }
        return null;
    }
}