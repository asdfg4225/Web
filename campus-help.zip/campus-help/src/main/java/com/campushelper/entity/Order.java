package com.campushelper.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@TableName("orders")
public class Order {

    @TableId(type = IdType.AUTO)
    private Integer id;

    @TableField("order_no")
    private String orderNo;

    @TableField("publisher_id")
    private Integer publisherId;

    @TableField("runner_id")
    private Integer runnerId;

    private String category; // express, food, help, study

    private String title;

    private String description;

    private BigDecimal reward;

    private String status; // pending, waiting, accepted, in_progress, completed, cancelled

    private String location;

    private LocalDateTime deadline;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    // 关联的用户信息（非数据库字段）
    @TableField(exist = false)
    private String publisherName;

    @TableField(exist = false)
    private String runnerName;
}