package com.campushelper.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@TableName("balance_log")
public class BalanceLog {
    @TableId(type = IdType.AUTO)
    private Integer id;

    private Integer userId;

    private Integer orderId;

    private String type;

    private BigDecimal amount;

    @TableField("balance_before")
    private BigDecimal balanceBefore;

    @TableField("balance_after")
    private BigDecimal balanceAfter;

    @TableField("payment_method")
    private String paymentMethod;

    @TableField("payment_no")
    private String paymentNo;

    private String remark;

    private String status;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField("complete_time")
    private LocalDateTime completeTime;

    // 在BalanceLog.java中添加以下字段
    @TableField("fee")
    private BigDecimal fee;  // 手续费
}