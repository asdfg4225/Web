package com.campushelper.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("feedback")
public class Feedback {

    @TableId(type = IdType.AUTO)
    private Integer id;

    private Integer userId;

    private String type; // suggestion, bug, complaint

    private String content;

    private String status; // pending, processing, resolved

    private String adminReply;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;
}