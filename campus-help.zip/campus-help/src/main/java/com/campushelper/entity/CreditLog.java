package com.campushelper.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("credit_log")
public class CreditLog {
    @TableId(type = IdType.AUTO)
    private Integer id;

    private Integer userId;

    private String changeType;

    private Integer changeScore;

    private Integer currentScore;

    private Integer orderId;

    private String remark;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    // 关联订单号（非数据库字段，用于展示）
    private String orderNo;

    // 变更类型显示名称
    private String changeTypeName;
}