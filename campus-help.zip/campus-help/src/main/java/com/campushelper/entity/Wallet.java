package com.campushelper.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@TableName("wallet")
public class Wallet {
    @TableId(type = IdType.AUTO)
    private Integer id;

    private Integer userId;

    @TableField("balance")
    private BigDecimal balance;

    @TableField("total_recharge")
    private BigDecimal totalRecharge;

    @TableField("total_consume")
    private BigDecimal totalConsume;

    private String status;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}