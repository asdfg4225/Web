package com.campushelper.vo;

import lombok.Data;

@Data
public class FeedbackStatsVO {
    private Integer total;
    private Integer pending;
    private Integer processing;
    private Integer resolved;
}