package com.campushelper.vo;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class BalanceLogVO {
    private Integer id;
    private Integer orderId;
    private String type;                 // recharge, consume, refund, etc.
    private BigDecimal amount;           // 变动金额（正负）
    private BigDecimal balanceBefore;    // 变动前余额
    private BigDecimal balanceAfter;     // 变动后余额
    private String paymentMethod;        // 支付方式
    private String paymentNo;            // 支付订单号
    private String remark;               // 备注
    private String status;               // 状态
    private LocalDateTime createTime;    // 创建时间
    private LocalDateTime completeTime;  // 完成时间

    // 方便前端展示的字段
    private String typeName;             // 类型名称
    private String statusName;           // 状态名称
    private String timeAgo;              // 相对时间

    // 在BalanceLogVO.java中添加手续费字段
    private BigDecimal fee;  // 手续费
}