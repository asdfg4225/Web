package com.campushelper.vo;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class EvaluationVO {

    private Integer id;

    private Integer orderId;

    private Integer fromUserId;

    private String fromUserName;

    private String fromUserAvatar;

    private Integer toUserId;

    private String toUserName;

    private String toUserAvatar;

    private Integer score;

    private String content;

    private LocalDateTime createTime;

    // 订单信息
    private String orderTitle;

    private String orderNo;

    private Double orderReward;

    // 用户角色
    private String fromUserRole;

    private String toUserRole;
}