package com.campushelper.vo;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class AdminUserDetailVO {
    private Integer id;
    private String studentId;
    private String name;
    private String college;
    private String grade;
    private String role;
    private String status;
    private Integer creditScore;
    private BigDecimal balance;
    private String openid;
    private String remark;

    // 用户统计
    private UserStats stats;

    // 最近订单
    private List<RecentOrder> recentOrders;

    // 时间信息
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
    private LocalDateTime lastLogin;

    @Data
    public static class UserStats {
        private Integer orderCount;      // 发布任务数
        private Integer completeCount;   // 完成任务数
        private Integer evaluationCount; // 收到评价数
        private Integer creditScore;     // 信用分
    }

    @Data
    public static class RecentOrder {
        private String orderNo;
        private String title;
        private String category;
        private BigDecimal reward;
        private String status;
        private LocalDateTime createTime;
    }
}