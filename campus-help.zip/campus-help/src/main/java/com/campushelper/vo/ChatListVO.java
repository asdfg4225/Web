package com.campushelper.vo;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ChatListVO {
    private Integer orderId;
    private String orderTitle;
    private String orderStatus;
    private String orderCategory;
    private Double reward;
    private Integer otherUserId;
    private String otherUserName;
    private String otherUserAvatar;
    private String lastMessage;
    private LocalDateTime lastMessageTime;
    private Integer unreadCount;
    private LocalDateTime orderCreateTime;

    // 格式化时间
    private String formattedTime;
    private String statusName;
}