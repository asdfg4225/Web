package com.campushelper.vo;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class OrderLogVO {
    private Integer id;
    private Integer orderId;
    private String oldStatus;
    private String newStatus;
    private Integer operatorId;
    private String operatorName;
    private String remark;
    private LocalDateTime createTime;
}