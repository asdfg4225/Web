package com.campushelper.vo;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class CreditOverviewVO {
    private Integer userId;
    private Integer currentScore;
    private String scoreLevel;
    private String levelName;
    private Integer recent7DaysChange;
    private Integer completeCount;
    private Integer goodEvalCount;
    private Integer cancelCount;
    private List<Map<String, Object>> trendData;
}