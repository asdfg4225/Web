package com.campushelper.vo;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class FeedbackVO {
    private Integer id;
    private Integer userId;
    private String userName;
    private String type;
    private String content;
    private String status;
    private String adminReply;
    private String createTime;
    private String updateTime;
}