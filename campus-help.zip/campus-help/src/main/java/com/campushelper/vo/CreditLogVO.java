package com.campushelper.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class CreditLogVO {
    private Integer id;
    private Integer userId;
    private String changeType;
    private String changeTypeName;
    private Integer changeScore;
    private Integer currentScore;
    private Integer orderId;
    private String orderNo;
    private String remark;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    private String createTimeStr;
}