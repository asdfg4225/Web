package com.campushelper.vo;

import com.campushelper.dto.AdminUserDTO;
import lombok.Data;
import java.util.List;

@Data
public class AdminUserListVO {
    private List<AdminUserDTO> list;
    private Long total;
    private Integer page;
    private Integer size;
}