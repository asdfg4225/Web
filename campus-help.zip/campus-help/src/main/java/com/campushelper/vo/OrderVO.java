package com.campushelper.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class OrderVO {
    private Integer id;
    private String orderNo;
    private String category;
    private String categoryName;
    private String title;
    private String description;
    private BigDecimal reward;
    private String status;
    private String statusName;
    private String location;
    private LocalDateTime deadline;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    // 发布者信息
    private Integer publisherId;
    private String publisherName;
    private String publisherAvatar;

    // 接单者信息
    private Integer runnerId;
    private String runnerName;
    private String runnerAvatar;

    // 时间相关
    private String createTimeStr;
    private String deadlineStr;

    // 距离（用于接单页面）
    private Double distance;

    // 确认状态（用于前端状态显示）
    private Boolean publisherConfirmed;
    private Boolean runnerConfirmed;

    // 订单日志列表
    @TableField(exist = false)
    private List<OrderLogVO> logs;

    // 聊天记录列表（可选）
    @TableField(exist = false)
    private List<ChatVO> chats;

    // 用户评价信息（可选）
    @TableField(exist = false)
    private EvaluationVO evaluation;
}