package com.campushelper.vo;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class BalanceOverviewVO {
    private BigDecimal balance;          // 当前余额
    private BigDecimal totalRecharge;    // 累计充值
    private BigDecimal totalConsume;     // 累计消费
    private String status;               // 钱包状态
    private boolean canRecharge = true;  // 是否可以充值
    private boolean canWithdraw = false; // 是否可以提现（暂不支持）
}