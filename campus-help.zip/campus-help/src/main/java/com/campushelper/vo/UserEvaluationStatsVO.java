package com.campushelper.vo;

import lombok.Data;

@Data
public class UserEvaluationStatsVO {

    private Integer userId;

    private String userName;

    private Double averageScore;

    private Integer totalCount;

    private Integer fiveStarCount;

    private Integer fourStarCount;

    private Integer threeStarCount;

    private Integer twoStarCount;

    private Integer oneStarCount;


}