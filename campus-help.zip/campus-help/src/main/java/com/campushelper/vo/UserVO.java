package com.campushelper.vo;

import lombok.Data;
import java.util.Date;

@Data
public class UserVO {
    private Integer id;
    private String studentId;
    private String name;
    private String college;
    private String grade;
    private String role;
    private Integer creditScore;
    private String avatarUrl;
    private String status;
    private Date createTime;

    private String username;
    public String getUsername() {
        return this.username != null ? this.username : this.studentId;
    }
}
