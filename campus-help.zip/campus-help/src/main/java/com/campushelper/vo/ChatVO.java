package com.campushelper.vo;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ChatVO {
    private Integer id;
    private Integer orderId;
    private Integer senderId;
    private Integer receiverId;
    private String content;
    private String type;
    private Boolean isRead;
    private LocalDateTime createTime;
    private String senderName;
    private String senderAvatar;
    private String orderTitle;

    // 是否是自己发送的消息
    private Boolean isSelf;

    // 格式化时间
    private String formattedTime;
}