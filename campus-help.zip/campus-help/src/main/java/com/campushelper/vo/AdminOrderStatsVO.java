package com.campushelper.vo;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Map;

@Data
public class AdminOrderStatsVO {
    private Map<String, Integer> statusStats; // 状态统计
    private Map<String, Integer> categoryStats; // 分类统计
    private Integer todayCount; // 今日订单数
    private Integer weekCount; // 本周订单数
    private Integer monthCount; // 本月订单数
    private BigDecimal totalReward; // 总悬赏金额
    private BigDecimal completedReward; // 已完成悬赏金额
}