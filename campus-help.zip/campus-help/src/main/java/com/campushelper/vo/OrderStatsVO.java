package com.campushelper.vo;

import lombok.Data;

@Data
public class OrderStatsVO {
    private Integer totalPublished;      // 发布的总任务数
    private Integer totalAccepted;       // 接取的总任务数
    private Integer completedPublished;  // 完成的发布任务数
    private Integer completedAccepted;   // 完成的接取任务数


}