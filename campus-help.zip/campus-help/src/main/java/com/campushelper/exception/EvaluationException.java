package com.campushelper.exception;

public class EvaluationException extends BusinessException {

    public EvaluationException(String message) {
        super(message);
    }

    public EvaluationException(String message, Throwable cause) {
        super(message, cause);
    }
}