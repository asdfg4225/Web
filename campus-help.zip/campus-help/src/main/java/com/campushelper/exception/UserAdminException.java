package com.campushelper.exception;

public class UserAdminException extends BusinessException {

    public UserAdminException(String message) {
        super(message);
    }

    public UserAdminException(String message, Throwable cause) {
        super(message, cause);
    }
}