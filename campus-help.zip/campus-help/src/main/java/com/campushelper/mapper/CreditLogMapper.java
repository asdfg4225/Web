package com.campushelper.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campushelper.entity.CreditLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface CreditLogMapper extends BaseMapper<CreditLog> {

    @Select("SELECT cl.*, o.order_no FROM credit_log cl " +
            "LEFT JOIN orders o ON cl.order_id = o.id " +
            "WHERE cl.user_id = #{userId} " +
            "ORDER BY cl.create_time DESC")
    List<CreditLog> selectByUserIdWithOrderNo(@Param("userId") Integer userId);

    @Select("SELECT cl.*, o.order_no FROM credit_log cl " +
            "LEFT JOIN orders o ON cl.order_id = o.id " +
            "WHERE cl.user_id = #{userId} AND cl.create_time >= #{startTime} " +
            "ORDER BY cl.create_time DESC")
    List<CreditLog> selectByUserIdAndTime(@Param("userId") Integer userId,
                                          @Param("startTime") LocalDateTime startTime);

    @Select("SELECT COUNT(*) FROM credit_log WHERE user_id = #{userId} AND change_type = 'task_complete'")
    Integer countCompleteTasks(@Param("userId") Integer userId);

    @Select("SELECT COUNT(*) FROM credit_log WHERE user_id = #{userId} AND change_type = 'good_eval'")
    Integer countGoodEvaluations(@Param("userId") Integer userId);

    @Select("SELECT COUNT(*) FROM credit_log WHERE user_id = #{userId} AND change_type = 'cancel_order'")
    Integer countCancelOrders(@Param("userId") Integer userId);

    @Select("SELECT SUM(change_score) FROM credit_log WHERE user_id = #{userId} AND create_time >= #{startTime}")
    Integer sumChangeScoreSince(@Param("userId") Integer userId, @Param("startTime") LocalDateTime startTime);
}