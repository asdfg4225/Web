package com.campushelper.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campushelper.entity.Feedback;
import com.campushelper.vo.FeedbackStatsVO;
import com.campushelper.vo.FeedbackVO;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.time.LocalDateTime;
import java.util.List;

public interface FeedbackMapper extends BaseMapper<Feedback> {

    List<FeedbackVO> selectFeedbackList(
            @Param("type") String type,
            @Param("status") String status,
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime,
            @Param("offset") Integer offset,
            @Param("limit") Integer limit);

    Long countFeedbackList(
            @Param("type") String type,
            @Param("status") String status,
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime);

    FeedbackVO selectFeedbackDetail(Integer id);

    List<FeedbackVO> selectMyFeedback(Integer userId);

    FeedbackStatsVO selectFeedbackStats();
}