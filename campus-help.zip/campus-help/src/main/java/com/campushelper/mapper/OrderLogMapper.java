package com.campushelper.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campushelper.entity.OrderLog;
import com.campushelper.vo.OrderLogVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface OrderLogMapper extends BaseMapper<OrderLog> {
    // 查询订单日志
    List<OrderLogVO> selectOrderLogsByOrderId(@Param("orderId") Integer orderId);
}