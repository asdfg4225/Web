package com.campushelper.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campushelper.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;
import java.util.Map;

@Mapper
public interface UserMapper extends BaseMapper<User> {

    @Select("SELECT * FROM user WHERE student_id = #{studentId}")
    User selectByStudentId(String studentId);

    @Select("SELECT COUNT(*) FROM user WHERE student_id = #{studentId}")
    int countByStudentId(String studentId);

    @Update("UPDATE user SET status = #{status} WHERE id = #{userId}")
    int updateStatus(@Param("userId") Integer userId, @Param("status") String status);

    // 批量更新状态
    @Update("<script>" +
            "UPDATE user SET status = #{status}, update_time = NOW() " +
            "WHERE id IN " +
            "<foreach collection='userIds' item='id' open='(' separator=',' close=')'>" +
            "#{id}" +
            "</foreach>" +
            "</script>")
    int batchUpdateStatus(@Param("userIds") List<Integer> userIds, @Param("status") String status);

    // 根据条件查询用户（支持分页）
    @Select("<script>" +
            "SELECT * FROM user " +
            "<where>" +
            "<if test='status != null and status != \"\"'>" +
            "AND status = #{status}" +
            "</if>" +
            "<if test='college != null and college != \"\"'>" +
            "AND college = #{college}" +
            "</if>" +
            "<if test='grade != null and grade != \"\"'>" +
            "AND grade = #{grade}" +
            "</if>" +
            "<if test='search != null and search != \"\"'>" +
            "AND (student_id LIKE CONCAT('%', #{search}, '%') " +
            "OR name LIKE CONCAT('%', #{search}, '%') " +
            "OR college LIKE CONCAT('%', #{search}, '%'))" +
            "</if>" +
            "<if test='startTime != null'>" +
            "AND create_time &gt;= #{startTime}" +
            "</if>" +
            "</where>" +
            "ORDER BY create_time DESC" +
            "</script>")
    List<User> selectUsersByCondition(@Param("status") String status,
                                      @Param("college") String college,
                                      @Param("grade") String grade,
                                      @Param("search") String search,
                                      @Param("startTime") String startTime);

    // 根据条件查询用户列表（支持分页）- XML方式
    List<User> selectUserListByCondition(@Param("status") String status,
                                         @Param("college") String college,
                                         @Param("grade") String grade,
                                         @Param("search") String search,
                                         @Param("startTime") String startTime,
                                         @Param("offset") int offset,
                                         @Param("limit") int limit);
}