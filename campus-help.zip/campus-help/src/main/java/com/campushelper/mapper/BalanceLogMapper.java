package com.campushelper.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campushelper.entity.BalanceLog;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BalanceLogMapper extends BaseMapper<BalanceLog> {
}