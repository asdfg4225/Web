package com.campushelper.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campushelper.entity.Order;
import com.campushelper.vo.OrderVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface OrderMapper extends BaseMapper<Order> {

    // 新增：分页查询订单
    List<OrderVO> selectOrderPage(
            @Param("status") String status,
            @Param("category") String category,
            @Param("userId") Integer userId,  // 用于排除自己发布的任务
            @Param("offset") Integer offset,
            @Param("size") Integer size
    );

    // 新增：统计订单数量
    Long countOrderPage(
            @Param("status") String status,
            @Param("category") String category,
            @Param("userId") Integer userId
    );

    @Select("SELECT o.*, u.name as publisher_name " +
            "FROM orders o " +
            "LEFT JOIN user u ON o.publisher_id = u.id " +
            "WHERE o.status = 'pending' " +
            "ORDER BY o.create_time DESC")
    List<Order> selectAvailableTasks();

    @Select("SELECT o.*, " +
            "p.name as publisher_name, " +
            "r.name as runner_name " +
            "FROM orders o " +
            "LEFT JOIN user p ON o.publisher_id = p.id " +
            "LEFT JOIN user r ON o.runner_id = r.id " +
            "WHERE o.id = #{orderId}")
    Order selectOrderWithUserInfo(@Param("orderId") Integer orderId);

    @Select("SELECT COUNT(*) FROM orders WHERE publisher_id = #{userId}")
    Integer countByPublisher(@Param("userId") Integer userId);

    @Select("SELECT COUNT(*) FROM orders WHERE runner_id = #{userId}")
    Integer countByRunner(@Param("userId") Integer userId);

    @Select("SELECT COUNT(*) FROM orders WHERE publisher_id = #{userId} AND status = 'completed'")
    Integer countCompletedByPublisher(@Param("userId") Integer userId);

    @Select("SELECT COUNT(*) FROM orders WHERE runner_id = #{userId} AND status = 'completed'")
    Integer countCompletedByRunner(@Param("userId") Integer userId);

    // 管理员：查询任务列表（使用Map参数）
    @Select("<script>" +
            "SELECT o.*, " +
            "pu.name as publisher_name, " +
            "ru.name as runner_name " +
            "FROM orders o " +
            "LEFT JOIN user pu ON o.publisher_id = pu.id " +
            "LEFT JOIN user ru ON o.runner_id = ru.id " +
            "<where>" +
            "   <if test='status != null'>" +
            "       AND o.status = #{status}" +
            "   </if>" +
            "   <if test='category != null'>" +
            "       AND o.category = #{category}" +
            "   </if>" +
            "   <if test='startTime != null'>" +
            "       AND o.create_time >= #{startTime}" +
            "   </if>" +
            "   <if test='search != null'>" +
            "       AND (o.order_no LIKE #{search} OR o.title LIKE #{search} OR o.description LIKE #{search})" +
            "   </if>" +
            "   <if test='publisherIds != null'>" +
            "       AND o.publisher_id IN " +
            "       <foreach collection='publisherIds' item='id' open='(' separator=',' close=')'>" +
            "           #{id}" +
            "       </foreach>" +
            "   </if>" +
            "   <if test='runnerIds != null'>" +
            "       AND o.runner_id IN " +
            "       <foreach collection='runnerIds' item='id' open='(' separator=',' close=')'>" +
            "           #{id}" +
            "       </foreach>" +
            "   </if>" +
            "   <if test='emptyPublisher != null and emptyPublisher'>" +
            "       AND 1=0" +
            "   </if>" +
            "   <if test='emptyRunner != null and emptyRunner'>" +
            "       AND 1=0" +
            "   </if>" +
            "</where>" +
            "ORDER BY o.create_time DESC " +
            "LIMIT #{offset}, #{limit}" +
            "</script>")
    List<Order> selectAdminOrderList(Map<String, Object> params);

    // 管理员：统计任务数量
    @Select("<script>" +
            "SELECT COUNT(*) FROM orders o " +
            "<where>" +
            "   <if test='status != null'>" +
            "       AND o.status = #{status}" +
            "   </if>" +
            "   <if test='category != null'>" +
            "       AND o.category = #{category}" +
            "   </if>" +
            "   <if test='startTime != null'>" +
            "       AND o.create_time >= #{startTime}" +
            "   </if>" +
            "   <if test='search != null'>" +
            "       AND (o.order_no LIKE #{search} OR o.title LIKE #{search} OR o.description LIKE #{search})" +
            "   </if>" +
            "   <if test='publisherIds != null'>" +
            "       AND o.publisher_id IN " +
            "       <foreach collection='publisherIds' item='id' open='(' separator=',' close=')'>" +
            "           #{id}" +
            "       </foreach>" +
            "   </if>" +
            "   <if test='runnerIds != null'>" +
            "       AND o.runner_id IN " +
            "       <foreach collection='runnerIds' item='id' open='(' separator=',' close=')'>" +
            "           #{id}" +
            "       </foreach>" +
            "   </if>" +
            "   <if test='emptyPublisher != null and emptyPublisher'>" +
            "       AND 1=0" +
            "   </if>" +
            "   <if test='emptyRunner != null and emptyRunner'>" +
            "       AND 1=0" +
            "   </if>" +
            "</where>" +
            "</script>")
    Long countAdminOrderList(Map<String, Object> params);

    // 管理员：查询订单详情（包含用户信息和日志）
    @Select("SELECT o.*, " +
            "pu.name as publisher_name, pu.student_id as publisher_student_id, " +
            "ru.name as runner_name, ru.student_id as runner_student_id " +
            "FROM orders o " +
            "LEFT JOIN user pu ON o.publisher_id = pu.id " +
            "LEFT JOIN user ru ON o.runner_id = ru.id " +
            "WHERE o.id = #{orderId}")
    Order selectAdminOrderDetail(@Param("orderId") Integer orderId);
}