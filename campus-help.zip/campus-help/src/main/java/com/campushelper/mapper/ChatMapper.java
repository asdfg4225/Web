package com.campushelper.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campushelper.entity.Chat;
import com.campushelper.vo.ChatListVO;
import com.campushelper.vo.ChatVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ChatMapper extends BaseMapper<Chat> {

    // 获取聊天列表（按订单分组）
    List<ChatListVO> selectChatListByUserId(@Param("userId") Integer userId);

    // 获取订单的聊天记录
    List<ChatVO> selectChatByOrderId(@Param("orderId") Integer orderId);

    // 获取与特定订单相关的聊天记录（带用户信息）
    List<ChatVO> selectChatWithUsers(@Param("orderId") Integer orderId);

    // 获取未读消息数量
    Integer selectUnreadCount(@Param("userId") Integer userId);

    // 标记消息为已读
    int updateMessagesRead(@Param("orderId") Integer orderId,
                           @Param("userId") Integer userId);

    // 获取订单的最后一条消息
    Chat selectLastMessageByOrderId(@Param("orderId") Integer orderId);
}