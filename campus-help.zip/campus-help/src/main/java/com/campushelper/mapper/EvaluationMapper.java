package com.campushelper.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campushelper.entity.Evaluation;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface EvaluationMapper extends BaseMapper<Evaluation> {

    // 根据订单ID查询评价列表
    @Select("SELECT * FROM evaluation WHERE order_id = #{orderId} ORDER BY create_time DESC")
    List<Evaluation> selectByOrderId(@Param("orderId") Integer orderId);

    // 根据被评价用户ID查询评价列表
    @Select("SELECT * FROM evaluation WHERE to_user_id = #{userId} ORDER BY create_time DESC")
    List<Evaluation> selectByToUserId(@Param("userId") Integer userId);

    // 根据订单ID和评价人ID查询是否已评价
    @Select("SELECT COUNT(*) FROM evaluation WHERE order_id = #{orderId} AND from_user_id = #{fromUserId}")
    int countByOrderAndFromUser(@Param("orderId") Integer orderId, @Param("fromUserId") Integer fromUserId);

    // 获取用户平均评分
    @Select("SELECT AVG(score) FROM evaluation WHERE to_user_id = #{userId}")
    Double getAverageScoreByUserId(@Param("userId") Integer userId);

    // 获取用户评价总数
    @Select("SELECT COUNT(*) FROM evaluation WHERE to_user_id = #{userId}")
    int countByToUserId(@Param("userId") Integer userId);

    // 新增的方法 - 统计用户评价的星级分布
    @Select("SELECT " +
            "SUM(CASE WHEN score = 5 THEN 1 ELSE 0 END) as five_star, " +
            "SUM(CASE WHEN score = 4 THEN 1 ELSE 0 END) as four_star, " +
            "SUM(CASE WHEN score = 3 THEN 1 ELSE 0 END) as three_star, " +
            "SUM(CASE WHEN score = 2 THEN 1 ELSE 0 END) as two_star, " +
            "SUM(CASE WHEN score = 1 THEN 1 ELSE 0 END) as one_star " +
            "FROM evaluation WHERE to_user_id = #{userId}")
    Map<String, Object> countUserEvaluations(@Param("userId") Integer userId);
}