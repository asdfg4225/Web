package com.campushelper.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campushelper.entity.Wallet;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;
import java.math.BigDecimal;

@Mapper
public interface WalletMapper extends BaseMapper<Wallet> {

    @Update("UPDATE wallet SET balance = balance + #{amount}, total_recharge = total_recharge + #{amount} " +
            "WHERE user_id = #{userId} AND status = 'normal'")
    int recharge(@Param("userId") Integer userId, @Param("amount") BigDecimal amount);

    @Update("UPDATE wallet SET balance = balance - #{amount}, total_consume = total_consume + #{amount} " +
            "WHERE user_id = #{userId} AND balance >= #{amount} AND status = 'normal'")
    int consume(@Param("userId") Integer userId, @Param("amount") BigDecimal amount);

    @Update("UPDATE wallet SET balance = balance + #{amount} " +
            "WHERE user_id = #{userId} AND status = 'normal'")
    int refund(@Param("userId") Integer userId, @Param("amount") BigDecimal amount);

    @Update("UPDATE wallet SET balance = balance - #{amount}, total_consume = total_consume + #{amount} " +
            "WHERE user_id = #{userId} AND balance >= #{amount} AND status = 'normal'")
    int withdraw(@Param("userId") Integer userId, @Param("amount") BigDecimal amount);
}