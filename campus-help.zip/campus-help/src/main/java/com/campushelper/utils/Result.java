package com.campushelper.utils;

import lombok.Data;
import java.io.Serializable;

@Data
public class Result<T> implements Serializable {
    private int code;
    private String message;
    private T data;  // 改为泛型类型

    // 泛型版本的success方法
    public static <T> Result<T> success(String message, T data) {
        Result<T> result = new Result<>();
        result.setCode(200);
        result.setMessage(message);
        result.setData(data);
        return result;
    }

    // 无数据的成功方法
    public static <T> Result<T> success(String message) {
        return success(message, null);
    }

    // 只有数据的成功方法
    public static <T> Result<T> success(T data) {
        return success("操作成功", data);
    }

    // 无参成功方法（主要用于返回void类型的操作）
    public static <T> Result<T> success() {
        return success("操作成功", null);
    }

    // 错误方法
    public static <T> Result<T> error(int code, String message) {
        Result<T> result = new Result<>();
        result.setCode(code);
        result.setMessage(message);
        result.setData(null);
        return result;
    }
}