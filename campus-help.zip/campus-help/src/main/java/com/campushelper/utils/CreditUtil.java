package com.campushelper.utils;

import com.campushelper.entity.CreditLog;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class CreditUtil {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final DateTimeFormatter DATE_ONLY_FORMATTER = DateTimeFormatter.ofPattern("MM/dd");

    // 获取信用分等级
    public static String getScoreLevel(Integer score) {
        if (score == null) return "未知";
        if (score <= 60) return "差";
        if (score <= 80) return "一般";
        if (score <= 100) return "良好";
        if (score <= 120) return "优秀";
        return "极好";
    }

    // 获取等级显示名称
    public static String getLevelName(Integer score) {
        if (score == null) return "未知";
        if (score <= 60) return "信用较差";
        if (score <= 80) return "信用一般";
        if (score <= 100) return "信用良好";
        if (score <= 120) return "信用优秀";
        return "信用极好";
    }

    // 获取变更类型显示名称
    public static String getChangeTypeName(String changeType) {
        Map<String, String> typeMap = new HashMap<>();
        typeMap.put("task_complete", "任务完成");
        typeMap.put("good_eval", "收到好评");
        typeMap.put("bad_eval", "收到差评");
        typeMap.put("cancel_order", "订单取消");

        return typeMap.getOrDefault(changeType, changeType);
    }

    // 格式化时间
    public static String formatTime(LocalDateTime time) {
        if (time == null) return "";

        LocalDateTime now = LocalDateTime.now();
        long diffMinutes = java.time.Duration.between(time, now).toMinutes();

        if (diffMinutes < 1) return "刚刚";
        if (diffMinutes < 60) return diffMinutes + "分钟前";
        if (diffMinutes < 1440) return (diffMinutes / 60) + "小时前";
        if (diffMinutes < 43200) return (diffMinutes / 1440) + "天前";

        // 如果是今年，显示月日
        if (time.getYear() == now.getYear()) {
            return time.format(DATE_ONLY_FORMATTER);
        }

        return time.format(DATE_FORMATTER);
    }

    // 计算趋势数据（最近30天）
    public static List<Map<String, Object>> calculateTrendData(List<CreditLog> logs) {
        List<Map<String, Object>> trendData = new ArrayList<>();

        // 如果没有数据，生成模拟数据
        if (logs == null || logs.isEmpty()) {
            LocalDateTime now = LocalDateTime.now();
            int currentScore = 100; // 默认分数

            for (int i = 30; i >= 0; i--) {
                LocalDateTime date = now.minusDays(i);
                String displayDate = date.format(DATE_ONLY_FORMATTER);

                Map<String, Object> dataPoint = new HashMap<>();
                dataPoint.put("date", displayDate);
                // 模拟分数轻微波动
                dataPoint.put("score", currentScore + (int)(Math.random() * 10) - 5);

                trendData.add(dataPoint);
            }
            return trendData;
        }

        // 如果有数据，按日期分组
        Map<String, Integer> dailyScores = new HashMap<>();

        // 这里简化处理，实际应该根据日志计算每日分数
        LocalDateTime endDate = LocalDateTime.now();

        for (int i = 30; i >= 0; i--) {
            LocalDateTime date = endDate.minusDays(i);
            String displayDate = date.format(DATE_ONLY_FORMATTER);

            Map<String, Object> dataPoint = new HashMap<>();
            dataPoint.put("date", displayDate);
            dataPoint.put("score", 100 + (int)(Math.random() * 10) - 5); // 模拟数据

            trendData.add(dataPoint);
        }

        return trendData;
    }
}