package com.campushelper.utils;

import com.campushelper.dto.AdminUserDTO;
import com.campushelper.entity.Order;
import com.campushelper.vo.OrderVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class ExportUtil {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /**
     * 导出订单数据到Excel
     */
    public byte[] exportOrdersToExcel(List<OrderVO> orders, Map<String, Object> filters) throws IOException {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("任务数据");

            // 创建标题样式
            CellStyle headerStyle = createHeaderStyle(workbook);
            // 创建数据样式
            CellStyle dataStyle = createDataStyle(workbook);

            // 创建标题行
            createHeaderRow(sheet, headerStyle);

            // 填充数据行
            fillDataRows(sheet, dataStyle, orders);

            // 自动调整列宽
            autoSizeColumns(sheet);

            // 写入到字节数组
            try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
                workbook.write(outputStream);
                return outputStream.toByteArray();
            }
        }
    }

    /**
     * 创建标题样式
     */
    private CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 12);
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    /**
     * 创建数据样式
     */
    private CellStyle createDataStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setAlignment(HorizontalAlignment.LEFT);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setWrapText(true);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    /**
     * 创建标题行
     */
    private void createHeaderRow(Sheet sheet, CellStyle headerStyle) {
        Row headerRow = sheet.createRow(0);

        String[] headers = {
                "订单号", "任务标题", "任务分类", "发布者", "接单人",
                "悬赏金额(元)", "任务状态", "任务地点", "截止时间",
                "创建时间", "更新时间", "任务描述"
        };

        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerStyle);
        }
    }

    /**
     * 填充数据行
     */
    private void fillDataRows(Sheet sheet, CellStyle dataStyle, List<OrderVO> orders) {
        int rowNum = 1;

        for (OrderVO order : orders) {
            Row row = sheet.createRow(rowNum++);

            int colNum = 0;

            // 订单号
            Cell cell0 = row.createCell(colNum++);
            cell0.setCellValue(order.getOrderNo() != null ? order.getOrderNo() : "");
            cell0.setCellStyle(dataStyle);

            // 任务标题
            Cell cell1 = row.createCell(colNum++);
            cell1.setCellValue(order.getTitle() != null ? order.getTitle() : "");
            cell1.setCellStyle(dataStyle);

            // 任务分类 - 修复：检查是否有可能为null
            Cell cell2 = row.createCell(colNum++);
            String categoryDisplay = getCategoryDisplayName(order);
            cell2.setCellValue(categoryDisplay);
            cell2.setCellStyle(dataStyle);

            // 发布者
            Cell cell3 = row.createCell(colNum++);
            String publisherDisplay = order.getPublisherName() != null ?
                    order.getPublisherName() :
                    (order.getPublisherId() != null ? "用户ID:" + order.getPublisherId() : "");
            cell3.setCellValue(publisherDisplay);
            cell3.setCellStyle(dataStyle);

            // 接单人
            Cell cell4 = row.createCell(colNum++);
            String runnerDisplay = order.getRunnerName() != null ?
                    order.getRunnerName() :
                    (order.getRunnerId() != null ? "用户ID:" + order.getRunnerId() : "未接单");
            cell4.setCellValue(runnerDisplay);
            cell4.setCellStyle(dataStyle);

            // 悬赏金额
            Cell cell5 = row.createCell(colNum++);
            cell5.setCellValue(order.getReward() != null ? order.getReward().doubleValue() : 0.0);
            cell5.setCellStyle(dataStyle);

            // 任务状态
            Cell cell6 = row.createCell(colNum++);
            String statusDisplay = getStatusDisplayName(order);
            cell6.setCellValue(statusDisplay);
            cell6.setCellStyle(dataStyle);

            // 任务地点
            Cell cell7 = row.createCell(colNum++);
            cell7.setCellValue(order.getLocation() != null ? order.getLocation() : "");
            cell7.setCellStyle(dataStyle);

            // 截止时间
            Cell cell8 = row.createCell(colNum++);
            if (order.getDeadline() != null) {
                cell8.setCellValue(order.getDeadline().format(DATE_FORMATTER));
            } else {
                cell8.setCellValue("");
            }
            cell8.setCellStyle(dataStyle);

            // 创建时间
            Cell cell9 = row.createCell(colNum++);
            if (order.getCreateTime() != null) {
                cell9.setCellValue(order.getCreateTime().format(DATE_FORMATTER));
            } else {
                cell9.setCellValue("");
            }
            cell9.setCellStyle(dataStyle);

            // 更新时间
            Cell cell10 = row.createCell(colNum++);
            if (order.getUpdateTime() != null) {
                cell10.setCellValue(order.getUpdateTime().format(DATE_FORMATTER));
            } else {
                cell10.setCellValue("");
            }
            cell10.setCellStyle(dataStyle);

            // 任务描述
            Cell cell11 = row.createCell(colNum);
            cell11.setCellValue(order.getDescription() != null ? order.getDescription() : "");
            cell11.setCellStyle(dataStyle);
        }
    }

    /**
     * 获取分类显示名称
     */
    private String getCategoryDisplayName(OrderVO order) {
        if (order.getCategoryName() != null) {
            return order.getCategoryName();
        }
        if (order.getCategory() != null) {
            switch (order.getCategory()) {
                case "express": return "快递";
                case "food": return "外卖";
                case "help": return "帮忙";
                case "study": return "学习";
                default: return order.getCategory();
            }
        }
        return "";
    }

    /**
     * 获取状态显示名称
     */
    private String getStatusDisplayName(OrderVO order) {
        if (order.getStatusName() != null) {
            return order.getStatusName();
        }
        if (order.getStatus() != null) {
            switch (order.getStatus()) {
                case "pending": return "待接单";
                case "waiting": return "等待中";
                case "accepted": return "已接单";
                case "in_progress": return "进行中";
                case "completed": return "已完成";
                case "cancelled": return "已取消";
                default: return order.getStatus();
            }
        }
        return "";
    }

    /**
     * 自动调整列宽
     */
    private void autoSizeColumns(Sheet sheet) {
        int columnCount = sheet.getRow(0).getLastCellNum();
        for (int i = 0; i < columnCount; i++) {
            sheet.autoSizeColumn(i);
            // 设置最小宽度
            int currentWidth = sheet.getColumnWidth(i);
            if (currentWidth < 4000) {
                sheet.setColumnWidth(i, 4000);
            } else if (currentWidth > 10000) {
                sheet.setColumnWidth(i, 10000);
            }
        }
    }

    /**
     * 生成导出文件名
     */
    public String generateExportFilename(String prefix) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        String timestamp = LocalDateTime.now().format(formatter);
        return prefix + "_" + timestamp + ".xlsx";
    }

    /**
     * 导出用户数据到Excel
     */
    public byte[] exportUsersToExcel(List<AdminUserDTO> users, Map<String, Object> filters) throws IOException {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("用户数据");

            // 创建标题样式
            CellStyle headerStyle = createHeaderStyle(workbook);
            // 创建数据样式
            CellStyle dataStyle = createDataStyle(workbook);

            // 创建标题行
            createUserHeaderRow(sheet, headerStyle);

            // 填充数据行
            fillUserDataRows(sheet, dataStyle, users);

            // 自动调整列宽
            autoSizeColumns(sheet);

            // 写入到字节数组
            try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
                workbook.write(outputStream);
                return outputStream.toByteArray();
            }
        }
    }

    /**
     * 创建用户标题行
     */
    private void createUserHeaderRow(Sheet sheet, CellStyle headerStyle) {
        Row headerRow = sheet.createRow(0);

        String[] headers = {
                "用户ID", "学号", "姓名", "学院", "年级",
                "角色", "信用分", "账户余额(元)", "状态",
                "注册时间", "最后更新", "微信OpenID", "备注"
        };

        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerStyle);
        }
    }

    /**
     * 填充用户数据行
     */
    private void fillUserDataRows(Sheet sheet, CellStyle dataStyle, List<AdminUserDTO> users) {
        int rowNum = 1;

        for (AdminUserDTO user : users) {
            Row row = sheet.createRow(rowNum++);

            int colNum = 0;

            // 用户ID
            Cell cell0 = row.createCell(colNum++);
            cell0.setCellValue(user.getId() != null ? user.getId().toString() : "");
            cell0.setCellStyle(dataStyle);

            // 学号
            Cell cell1 = row.createCell(colNum++);
            cell1.setCellValue(user.getStudentId() != null ? user.getStudentId() : "");
            cell1.setCellStyle(dataStyle);

            // 姓名
            Cell cell2 = row.createCell(colNum++);
            cell2.setCellValue(user.getName() != null ? user.getName() : "");
            cell2.setCellStyle(dataStyle);

            // 学院
            Cell cell3 = row.createCell(colNum++);
            cell3.setCellValue(user.getCollege() != null ? user.getCollege() : "");
            cell3.setCellStyle(dataStyle);

            // 年级
            Cell cell4 = row.createCell(colNum++);
            cell4.setCellValue(user.getGrade() != null ? user.getGrade() : "");
            cell4.setCellStyle(dataStyle);

            // 角色
            Cell cell5 = row.createCell(colNum++);
            String roleDisplay = getRoleDisplayName(user);
            cell5.setCellValue(roleDisplay);
            cell5.setCellStyle(dataStyle);

            // 信用分
            Cell cell6 = row.createCell(colNum++);
            cell6.setCellValue(user.getCreditScore() != null ? user.getCreditScore().doubleValue() : 0.0);
            cell6.setCellStyle(dataStyle);

            // 账户余额
            Cell cell7 = row.createCell(colNum++);
            cell7.setCellValue(user.getBalance() != null ? user.getBalance().doubleValue() : 0.0);
            cell7.setCellStyle(dataStyle);

            // 状态
            Cell cell8 = row.createCell(colNum++);
            String statusDisplay = getStatusDisplayName(user);
            cell8.setCellValue(statusDisplay);
            cell8.setCellStyle(dataStyle);

            // 注册时间
            Cell cell9 = row.createCell(colNum++);
            if (user.getCreateTimeStr() != null) {
                cell9.setCellValue(user.getCreateTimeStr());
            } else if (user.getCreateTime() != null) {
                cell9.setCellValue(user.getCreateTime());
            } else {
                cell9.setCellValue("");
            }
            cell9.setCellStyle(dataStyle);

            // 最后更新
            Cell cell10 = row.createCell(colNum++);
            if (user.getUpdateTimeStr() != null) {
                cell10.setCellValue(user.getUpdateTimeStr());
            } else if (user.getUpdateTime() != null) {
                cell10.setCellValue(user.getUpdateTime());
            } else {
                cell10.setCellValue("");
            }
            cell10.setCellStyle(dataStyle);

            // 微信OpenID
            Cell cell11 = row.createCell(colNum++);
            cell11.setCellValue(user.getOpenid() != null ? user.getOpenid() : "");
            cell11.setCellStyle(dataStyle);

            // 备注
            Cell cell12 = row.createCell(colNum);
            cell12.setCellValue(user.getRemark() != null ? user.getRemark() : "");
            cell12.setCellStyle(dataStyle);
        }
    }

    /**
     * 获取角色显示名称
     */
    private String getRoleDisplayName(AdminUserDTO user) {
        if (user.getRoleName() != null) {
            return user.getRoleName();
        }
        if (user.getRole() != null) {
            switch (user.getRole()) {
                case "requester": return "委托人";
                case "runner": return "接单人";
                case "admin": return "管理员";
                default: return user.getRole();
            }
        }
        return "";
    }

    /**
     * 获取状态显示名称
     */
    private String getStatusDisplayName(AdminUserDTO user) {
        if (user.getStatusName() != null) {
            return user.getStatusName();
        }
        if (user.getStatus() != null) {
            switch (user.getStatus()) {
                case "verified": return "已认证";
                case "unverified": return "未认证";
                case "banned": return "已封禁";
                default: return user.getStatus();
            }
        }
        return "";
    }

}