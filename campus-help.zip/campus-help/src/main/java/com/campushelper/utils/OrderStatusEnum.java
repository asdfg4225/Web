package com.campushelper.utils;

import lombok.Getter;

@Getter
public enum OrderStatusEnum {
    PENDING("pending", "待接单"),
    WAITING("waiting", "等待中"),
    ACCEPTED("accepted", "已接单"),
    IN_PROGRESS("in_progress", "进行中"),
    COMPLETED("completed", "已完成"),
    CANCELLED("cancelled", "已取消"),
    EVALUATED("evaluated", "已评价"); // 注意：这里是分号，不是逗号

    private final String code;
    private final String name;

    OrderStatusEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public static String getNameByCode(String code) {
        for (OrderStatusEnum status : OrderStatusEnum.values()) {
            if (status.getCode().equals(code)) {
                return status.getName();
            }
        }
        return code;
    }

}