package com.campushelper.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class OrderNoUtil {

    private static final Random random = new Random();
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    // 订单号生成器
    public static String generateOrderNo() {
        String timeStr = LocalDateTime.now().format(formatter);
        int randomNum = random.nextInt(9000) + 1000; // 1000-9999
        return "ORD" + timeStr + randomNum;
    }

    // 支付订单号生成器（新增）
    public static String generatePaymentNo() {
        String timeStr = LocalDateTime.now().format(formatter);
        int randomNum = random.nextInt(9000) + 1000; // 1000-9999
        return "PAY" + timeStr + randomNum;
    }



    // 在OrderNoUtil.java中添加提现订单号生成方法
    // 提现订单号生成器
    public static String generateWithdrawNo() {
        String timeStr = LocalDateTime.now().format(formatter);
        int randomNum = random.nextInt(9000) + 1000; // 1000-9999
        return "WTH" + timeStr + randomNum;
    }
}