package com.campushelper.utils;

import lombok.Getter;

@Getter
public enum CategoryEnum {
    EXPRESS("express", "快递取送"),
    FOOD("food", "代买饮食"),
    STUDY("study", "学习互助"),
    HELP("help", "其他帮助");

    private final String code;
    private final String name;

    CategoryEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public static String getNameByCode(String code) {
        for (CategoryEnum category : CategoryEnum.values()) {
            if (category.getCode().equals(code)) {
                return category.getName();
            }
        }
        return code;
    }
}