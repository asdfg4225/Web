package com.campushelper.dto;

import lombok.Data;

@Data
public class UserDTO {
    private Integer id;
    private String studentId;
    private String name;
    private String college;
    private String grade;
    private String role;
    private Integer creditScore;
    private String avatarUrl;
    private String status;
    private String username; // 添加这个字段用于前端显示
}
