package com.campushelper.dto;

import lombok.Data;

@Data
public class UpdateUserDTO {
    private String name;
    private String studentId;
    private String college;
    private String grade;
    private String status;
    private Integer creditScore;
    private String remark;
}