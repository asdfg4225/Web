package com.campushelper.dto;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class AdminUserDTO {
    private Integer id;
    private String openid;
    private String studentId;
    private String name;
    private String college;
    private String grade;
    private String role;
    private String roleName;  // 角色显示名称
    private Integer creditScore;
    private BigDecimal balance;
    private String avatarUrl;
    private String status;
    private String statusName;  // 状态显示名称
    private String createTime;  // 原始时间
    private String createTimeStr;  // 格式化时间字符串
    private String updateTime;  // 原始时间
    private String updateTimeStr;  // 格式化时间字符串
    private String remark;  // 备注
}