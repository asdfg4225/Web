package com.campushelper.dto;

import lombok.Data;
import javax.validation.constraints.NotBlank;

@Data
public class FeedbackReplyDTO {

    @NotBlank(message = "回复内容不能为空")
    private String reply;
}
