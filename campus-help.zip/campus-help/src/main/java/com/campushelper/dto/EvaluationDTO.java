package com.campushelper.dto;

import lombok.Data;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class EvaluationDTO {

    @NotNull(message = "订单ID不能为空")
    private Integer orderId;

    @NotNull(message = "被评价用户ID不能为空")
    private Integer toUserId;

    @NotNull(message = "评分不能为空")
    @Min(value = 1, message = "评分最低为1分")
    @Max(value = 5, message = "评分最高为5分")
    private Integer score;

    private String content;

    // 评价类型：1-发布者评价接单人，2-接单人评价发布者
    private Integer type;
}