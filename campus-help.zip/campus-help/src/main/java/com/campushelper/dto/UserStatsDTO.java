package com.campushelper.dto;

import lombok.Data;
import java.io.Serializable;

@Data
public class UserStatsDTO implements Serializable {
    private Long total;       // 总用户数
    private Long verified;    // 已认证用户数
    private Long unverified;  // 未认证用户数
    private Long banned;      // 已封禁用户数
    private Integer todayNew;    // 今日新增用户数
}