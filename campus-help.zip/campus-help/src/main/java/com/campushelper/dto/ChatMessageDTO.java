package com.campushelper.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class ChatMessageDTO {

    @NotNull(message = "订单ID不能为空")
    private Integer orderId;

    @NotBlank(message = "消息内容不能为空")
    private String content;

    private String type = "text";
}