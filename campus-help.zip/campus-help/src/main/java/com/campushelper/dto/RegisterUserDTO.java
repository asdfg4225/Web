// RegisterUserDTO.java
package com.campushelper.dto;

import lombok.Data;
import jakarta.validation.constraints.NotBlank;

@Data
public class RegisterUserDTO {
    @NotBlank(message = "学号不能为空")
    private String studentId;

    @NotBlank(message = "密码不能为空")
    private String password;

    @NotBlank(message = "姓名不能为空")
    private String name;

    private String college;

    private String grade;

    private String openid; // 可选，用于微信注册
}