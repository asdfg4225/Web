package com.campushelper.dto;

import lombok.Data;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
public class RechargeDTO {
    @NotNull(message = "充值金额不能为空")
    @DecimalMin(value = "0.01", message = "充值金额必须大于0")
    private BigDecimal amount;

    @NotNull(message = "支付方式不能为空")
    private String paymentMethod;  // wechat, alipay, etc.

    private String redirectUrl;    // 支付完成后跳转的URL
}