package com.campushelper.dto;

import lombok.Data;
import java.util.List;

@Data
public class BulkActionDTO {
    private List<Integer> userIds;
    private String reason;
}