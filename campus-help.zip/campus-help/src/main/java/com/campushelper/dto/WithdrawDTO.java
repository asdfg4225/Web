package com.campushelper.dto;

import lombok.Data;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
public class WithdrawDTO {
    @NotNull(message = "提现金额不能为空")
    @DecimalMin(value = "10.00", message = "提现金额不能低于10元")
    private BigDecimal amount;

    @NotNull(message = "提现方式不能为空")
    private String method;  // wechat, alipay, bank

    private String remark;  // 备注
}