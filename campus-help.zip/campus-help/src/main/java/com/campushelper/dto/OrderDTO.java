package com.campushelper.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class OrderDTO {
    private String category;
    private String title;
    private String description;
    private BigDecimal reward;
    private String location;
    private LocalDateTime deadline;
    private String remark;
}