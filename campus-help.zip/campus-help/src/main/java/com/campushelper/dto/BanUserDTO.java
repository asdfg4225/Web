package com.campushelper.dto;

import lombok.Data;

@Data
public class BanUserDTO {
    private String reason;
}