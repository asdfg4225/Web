package com.campushelper.dto;

import lombok.Data;

@Data
public class FeedbackQueryDTO {
    private String type;
    private String status;
    private String time; // today, week, month
    private Integer page = 1;
    private Integer limit = 10;
}