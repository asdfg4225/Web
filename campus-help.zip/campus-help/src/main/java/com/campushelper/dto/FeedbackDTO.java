package com.campushelper.dto;

import lombok.Data;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class FeedbackDTO {

    @NotBlank(message = "反馈类型不能为空")
    private String type; // suggestion, bug, complaint

    @NotBlank(message = "反馈内容不能为空")
    private String content;
}
