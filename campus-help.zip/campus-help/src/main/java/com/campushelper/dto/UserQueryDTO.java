package com.campushelper.dto;

import lombok.Data;

@Data
public class UserQueryDTO {
    private Integer page = 1;
    private Integer limit = 15;
    private String status;
    private String college;
    private String grade;
    private String time;
    private String search;
}