package com.campushelper.security;

import com.campushelper.entity.User;
import com.campushelper.service.UserService;
import com.campushelper.utils.JwtUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Slf4j
@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;
    private final UserDetailsService userDetailsService;
    private final UserService userService;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        String token = getTokenFromRequest(request);

        if (token != null && jwtUtil.validateToken(token)) {
            String username = jwtUtil.getUsernameFromToken(token);
            log.debug("JWT验证成功，用户名: {}", username);

            try {
                // 使用userDetailsService加载用户信息
                UserDetails userDetails = userDetailsService.loadUserByUsername(username);

                if (userDetails == null) {
                    log.warn("未找到用户: {}", username);
                    filterChain.doFilter(request, response);
                    return;
                }

                log.debug("加载用户详情成功: {}, 类型: {}",
                        userDetails.getUsername(), userDetails.getClass().getName());

                // 创建认证对象
                UsernamePasswordAuthenticationToken authentication =
                        new UsernamePasswordAuthenticationToken(
                                userDetails,
                                null,
                                userDetails.getAuthorities());

                // 设置认证详情
                authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                // 设置到SecurityContext
                SecurityContextHolder.getContext().setAuthentication(authentication);

                // 将用户ID设置到request属性中
                if (userDetails instanceof User) {
                    User user = (User) userDetails;
                    log.debug("设置用户ID到request: {}", user.getId());
                    request.setAttribute("userId", user.getId());
                    // 也可以将整个用户对象存入，方便其他地方使用
                    request.setAttribute("user", user);
                } else {
                    // 如果不是User实体，尝试通过userService获取
                    User user = userService.getUserByStudentId(username);
                    if (user != null) {
                        log.debug("通过userService获取用户并设置ID: {}", user.getId());
                        request.setAttribute("userId", user.getId());
                        request.setAttribute("user", user);
                    } else {
                        log.warn("无法获取用户实体: {}", username);
                    }
                }
            } catch (Exception e) {
                log.error("用户认证失败: {}", e.getMessage(), e);
            }
        }

        filterChain.doFilter(request, response);
    }

    private String getTokenFromRequest(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");

        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }

        return null;
    }
}