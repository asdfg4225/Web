package com.campushelper.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.campushelper.dto.*;
import com.campushelper.entity.*;
import com.campushelper.exception.BusinessException;
import com.campushelper.mapper.*;
import com.campushelper.service.BalanceService;
import com.campushelper.service.UserAdminService;
import com.campushelper.utils.JwtUtil;
import com.campushelper.vo.AdminUserDetailVO;
import com.campushelper.vo.AdminUserListVO;
import com.campushelper.dto.UserStatsDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserAdminServiceImpl implements UserAdminService {

    private final UserMapper userMapper;
    private final OrderMapper orderMapper;
    private final EvaluationMapper evaluationMapper;
    private final CreditLogMapper creditLogMapper;
    private final WalletMapper walletMapper;
    private final PasswordEncoder passwordEncoder;
    private final BalanceService balanceService;
    private final JwtUtil jwtUtil;

    @Override
    public UserStatsDTO getUserStats() {
        UserStatsDTO stats = new UserStatsDTO();

        // 总用户数
        Long total = userMapper.selectCount(null);
        stats.setTotal(total);

        // 已认证用户数
        LambdaQueryWrapper<User> verifiedQuery = new LambdaQueryWrapper<>();
        verifiedQuery.eq(User::getStatus, "verified");
        Long verified = userMapper.selectCount(verifiedQuery);
        stats.setVerified(verified);

        // 未认证用户数
        LambdaQueryWrapper<User> unverifiedQuery = new LambdaQueryWrapper<>();
        unverifiedQuery.eq(User::getStatus, "unverified");
        Long unverified = userMapper.selectCount(unverifiedQuery);
        stats.setUnverified(unverified);

        // 已封禁用户数
        LambdaQueryWrapper<User> bannedQuery = new LambdaQueryWrapper<>();
        bannedQuery.eq(User::getStatus, "banned");
        Long banned = userMapper.selectCount(bannedQuery);
        stats.setBanned(banned);

        return stats;
    }

    @Override
    public AdminUserListVO getUserList(UserQueryDTO queryDTO) {
        // 构建查询条件
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();

        // 状态筛选
        if (StringUtils.hasText(queryDTO.getStatus())) {
            queryWrapper.eq(User::getStatus, queryDTO.getStatus());
        }

        // 学院筛选
        if (StringUtils.hasText(queryDTO.getCollege())) {
            queryWrapper.eq(User::getCollege, queryDTO.getCollege());
        }

        // 年级筛选
        if (StringUtils.hasText(queryDTO.getGrade())) {
            queryWrapper.eq(User::getGrade, queryDTO.getGrade());
        }

        // 注册时间筛选
        if (StringUtils.hasText(queryDTO.getTime())) {
            LocalDateTime startTime = getTimeFilter(queryDTO.getTime());
            if (startTime != null) {
                queryWrapper.ge(User::getCreateTime, startTime);
            }
        }

        // 搜索条件（学号、姓名、学院）
        if (StringUtils.hasText(queryDTO.getSearch())) {
            String search = queryDTO.getSearch();
            queryWrapper.and(wrapper -> wrapper
                    .like(User::getStudentId, search)
                    .or()
                    .like(User::getName, search)
                    .or()
                    .like(User::getCollege, search)
            );
        }

        // 按注册时间倒序
        queryWrapper.orderByDesc(User::getCreateTime);

        // 分页查询
        Page<User> page = new Page<>(queryDTO.getPage(), queryDTO.getLimit());
        IPage<User> userPage = userMapper.selectPage(page, queryWrapper);

        // 获取用户钱包信息
        List<User> users = userPage.getRecords();
        List<AdminUserDTO> userDTOs = new ArrayList<>();

        for (User user : users) {
            AdminUserDTO userDTO = new AdminUserDTO();
            BeanUtils.copyProperties(user, userDTO);

            // 获取用户余额
            BigDecimal balance = balanceService.getUserBalance(user.getId());
            userDTO.setBalance(balance);

            // 格式化时间
            if (user.getCreateTime() != null) {
                userDTO.setCreateTime(user.getCreateTime().toString());
            }

            userDTOs.add(userDTO);
        }

        // 构建返回结果
        AdminUserListVO result = new AdminUserListVO();
        result.setList(userDTOs);
        result.setTotal(userPage.getTotal());
        result.setPage(queryDTO.getPage());
        result.setSize(queryDTO.getLimit());

        return result;
    }

    @Override
    @Transactional(readOnly = true)
    public AdminUserDetailVO getUserDetail(Integer userId) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }

        AdminUserDetailVO detailVO = new AdminUserDetailVO();
        BeanUtils.copyProperties(user, detailVO);

        // 获取用户余额
        BigDecimal balance = balanceService.getUserBalance(userId);
        detailVO.setBalance(balance);

        // 获取用户统计信息
        AdminUserDetailVO.UserStats stats = new AdminUserDetailVO.UserStats();

        // 发布任务数
        LambdaQueryWrapper<Order> publishQuery = new LambdaQueryWrapper<>();
        publishQuery.eq(Order::getPublisherId, userId);
        long publishCount = orderMapper.selectCount(publishQuery);
        stats.setOrderCount((int) publishCount);

        // 完成任务数（作为接单人）
        LambdaQueryWrapper<Order> completeQuery = new LambdaQueryWrapper<>();
        completeQuery.eq(Order::getRunnerId, userId)
                .eq(Order::getStatus, "completed");
        long completeCount = orderMapper.selectCount(completeQuery);
        stats.setCompleteCount((int) completeCount);

        // 收到评价数
        LambdaQueryWrapper<Evaluation> evalQuery = new LambdaQueryWrapper<>();
        evalQuery.eq(Evaluation::getToUserId, userId);
        long evalCount = evaluationMapper.selectCount(evalQuery);
        stats.setEvaluationCount((int) evalCount);

        // 信用分
        stats.setCreditScore(user.getCreditScore());

        detailVO.setStats(stats);

        // 获取最近订单
        List<AdminUserDetailVO.RecentOrder> recentOrders = getRecentOrders(userId);
        detailVO.setRecentOrders(recentOrders);

        return detailVO;
    }

    @Override
    @Transactional
    public void verifyUser(Integer userId) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }

        if ("verified".equals(user.getStatus())) {
            throw new BusinessException("用户已认证");
        }

        user.setStatus("verified");
        user.setUpdateTime(LocalDateTime.now());
        userMapper.updateById(user);

        log.info("管理员认证用户: userId={}", userId);
    }

    @Override
    @Transactional
    public void banUser(Integer userId, String reason) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }

        if ("banned".equals(user.getStatus())) {
            throw new BusinessException("用户已被封禁");
        }

        // 检查是否是管理员
        if ("admin".equals(user.getRole())) {
            throw new BusinessException("不能封禁管理员");
        }

        user.setStatus("banned");
        user.setUpdateTime(LocalDateTime.now());
        userMapper.updateById(user);

        log.info("管理员封禁用户: userId={}, reason={}", userId, reason);
    }

    @Override
    @Transactional
    public void unbanUser(Integer userId) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }

        if (!"banned".equals(user.getStatus())) {
            throw new BusinessException("用户未被封禁");
        }

        user.setStatus("verified");
        user.setUpdateTime(LocalDateTime.now());
        userMapper.updateById(user);

        log.info("管理员解封用户: userId={}", userId);
    }

    @Override
    @Transactional
    public String resetPassword(Integer userId) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }

        // 使用固定默认密码
        String newPassword = "123456";
        String encodedPassword = passwordEncoder.encode(newPassword);

        user.setPassword(encodedPassword);
        user.setUpdateTime(LocalDateTime.now());
        userMapper.updateById(user);

        log.info("管理员重置用户密码: userId={}", userId);

        // 返回固定密码给管理员
        return newPassword;
    }

    @Override
    @Transactional
    public void updateUser(Integer userId, UpdateUserDTO updateUserDTO) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }

        // 更新基本信息
        if (StringUtils.hasText(updateUserDTO.getName())) {
            user.setName(updateUserDTO.getName());
        }

        if (StringUtils.hasText(updateUserDTO.getStudentId())) {
            // 检查学号是否重复
            LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(User::getStudentId, updateUserDTO.getStudentId())
                    .ne(User::getId, userId);
            Long count = userMapper.selectCount(queryWrapper);
            if (count > 0) {
                throw new BusinessException("学号已存在");
            }
            user.setStudentId(updateUserDTO.getStudentId());
        }

        if (StringUtils.hasText(updateUserDTO.getCollege())) {
            user.setCollege(updateUserDTO.getCollege());
        }

        if (StringUtils.hasText(updateUserDTO.getGrade())) {
            user.setGrade(updateUserDTO.getGrade());
        }

        // 更新状态
        if (StringUtils.hasText(updateUserDTO.getStatus())) {
            user.setStatus(updateUserDTO.getStatus());
        }

        // 更新信用分
        if (updateUserDTO.getCreditScore() != null) {
            user.setCreditScore(updateUserDTO.getCreditScore());
        }

        user.setUpdateTime(LocalDateTime.now());
        userMapper.updateById(user);

        log.info("管理员更新用户信息: userId={}", userId);
    }

    @Override
    @Transactional
    public void deleteUser(Integer userId) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }

        // 检查是否是管理员
        if ("admin".equals(user.getRole())) {
            throw new BusinessException("不能删除管理员");
        }

        // 删除用户
        userMapper.deleteById(userId);

        // 删除相关数据（可选，根据业务需求）
        // 这里可以根据需要删除用户的订单、评价等相关数据

        log.info("管理员删除用户: userId={}", userId);
    }

    @Override
    @Transactional
    public void bulkVerify(List<Integer> userIds) {
        if (userIds == null || userIds.isEmpty()) {
            throw new BusinessException("请选择用户");
        }

        List<User> users = userMapper.selectBatchIds(userIds);
        for (User user : users) {
            if ("verified".equals(user.getStatus())) {
                continue;
            }
            user.setStatus("verified");
            user.setUpdateTime(LocalDateTime.now());
        }

        // 批量更新
        for (User user : users) {
            userMapper.updateById(user);
        }

        log.info("批量认证用户: count={}, userIds={}", userIds.size(), userIds);
    }

    @Override
    @Transactional
    public void bulkBan(List<Integer> userIds, String reason) {
        if (userIds == null || userIds.isEmpty()) {
            throw new BusinessException("请选择用户");
        }

        List<User> users = userMapper.selectBatchIds(userIds);
        for (User user : users) {
            if ("admin".equals(user.getRole())) {
                throw new BusinessException("不能封禁管理员用户: " + user.getStudentId());
            }
            user.setStatus("banned");
            user.setUpdateTime(LocalDateTime.now());
        }

        // 批量更新
        for (User user : users) {
            userMapper.updateById(user);
        }

        log.info("批量封禁用户: count={}, reason={}, userIds={}", userIds.size(), reason, userIds);
    }

    @Override
    @Transactional
    public List<String> bulkResetPassword(List<Integer> userIds) {
        if (userIds == null || userIds.isEmpty()) {
            throw new BusinessException("请选择用户");
        }

        List<String> newPasswords = new ArrayList<>();
        List<User> users = userMapper.selectBatchIds(userIds);

        for (User user : users) {
            // 改为固定默认密码
            String newPassword = "123456";
            String encodedPassword = passwordEncoder.encode(newPassword);

            user.setPassword(encodedPassword);
            user.setUpdateTime(LocalDateTime.now());
            userMapper.updateById(user);

            newPasswords.add(newPassword);
        }

        log.info("批量重置密码: count={}, userIds={}", userIds.size(), userIds);

        return newPasswords;
    }

    @Override
    @Transactional
    public void bulkDelete(List<Integer> userIds) {
        if (userIds == null || userIds.isEmpty()) {
            throw new BusinessException("请选择用户");
        }

        // 检查是否包含管理员
        LambdaQueryWrapper<User> adminQuery = new LambdaQueryWrapper<>();
        adminQuery.in(User::getId, userIds)
                .eq(User::getRole, "admin");
        Long adminCount = userMapper.selectCount(adminQuery);
        if (adminCount > 0) {
            throw new BusinessException("不能删除管理员用户");
        }

        // 批量删除
        userMapper.deleteBatchIds(userIds);

        log.info("批量删除用户: count={}, userIds={}", userIds.size(), userIds);
    }

    /**
     * 获取时间筛选条件
     */
    private LocalDateTime getTimeFilter(String time) {
        LocalDate today = LocalDate.now();

        switch (time) {
            case "today":
                return LocalDateTime.of(today, LocalTime.MIN);
            case "week":
                LocalDate startOfWeek = today.minusDays(today.getDayOfWeek().getValue() - 1);
                return LocalDateTime.of(startOfWeek, LocalTime.MIN);
            case "month":
                LocalDate startOfMonth = today.withDayOfMonth(1);
                return LocalDateTime.of(startOfMonth, LocalTime.MIN);
            default:
                return null;
        }
    }

    /**
     * 获取用户最近订单
     */
    private List<AdminUserDetailVO.RecentOrder> getRecentOrders(Integer userId) {
        LambdaQueryWrapper<Order> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.and(wrapper -> wrapper
                        .eq(Order::getPublisherId, userId)
                        .or()
                        .eq(Order::getRunnerId, userId)
                )
                .orderByDesc(Order::getCreateTime)
                .last("LIMIT 10");

        List<Order> orders = orderMapper.selectList(queryWrapper);

        return orders.stream().map(order -> {
            AdminUserDetailVO.RecentOrder recentOrder = new AdminUserDetailVO.RecentOrder();
            BeanUtils.copyProperties(order, recentOrder);
            return recentOrder;
        }).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<AdminUserDTO> exportUsers(UserQueryDTO queryDTO) {
        log.info("导出用户数据: queryDTO={}", queryDTO);

        // 构建查询条件（与getUserList相同，但不分页）
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();

        // 状态筛选
        if (StringUtils.hasText(queryDTO.getStatus())) {
            queryWrapper.eq(User::getStatus, queryDTO.getStatus());
        }

        // 学院筛选
        if (StringUtils.hasText(queryDTO.getCollege())) {
            queryWrapper.eq(User::getCollege, queryDTO.getCollege());
        }

        // 年级筛选
        if (StringUtils.hasText(queryDTO.getGrade())) {
            queryWrapper.eq(User::getGrade, queryDTO.getGrade());
        }

        // 注册时间筛选
        if (StringUtils.hasText(queryDTO.getTime())) {
            LocalDateTime startTime = getTimeFilter(queryDTO.getTime());
            if (startTime != null) {
                queryWrapper.ge(User::getCreateTime, startTime);
            }
        }

        // 搜索条件（学号、姓名、学院）
        if (StringUtils.hasText(queryDTO.getSearch())) {
            String search = queryDTO.getSearch();
            queryWrapper.and(wrapper -> wrapper
                    .like(User::getStudentId, search)
                    .or()
                    .like(User::getName, search)
                    .or()
                    .like(User::getCollege, search)
            );
        }

        // 按注册时间倒序
        queryWrapper.orderByDesc(User::getCreateTime);

        // 查询所有数据（不分页）
        List<User> users = userMapper.selectList(queryWrapper);

        // 转换为AdminUserDTO列表
        List<AdminUserDTO> userDTOs = new ArrayList<>();

        for (User user : users) {
            AdminUserDTO userDTO = new AdminUserDTO();
            BeanUtils.copyProperties(user, userDTO);

            // 获取用户余额
            BigDecimal balance = balanceService.getUserBalance(user.getId());
            userDTO.setBalance(balance);

            // 格式化时间
            if (user.getCreateTime() != null) {
                userDTO.setCreateTime(user.getCreateTime().toString());
                userDTO.setCreateTimeStr(user.getCreateTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            }
            if (user.getUpdateTime() != null) {
                userDTO.setUpdateTime(user.getUpdateTime().toString());
                userDTO.setUpdateTimeStr(user.getUpdateTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            }

            // 设置状态显示名称
            userDTO.setStatusName(getStatusDisplayName(user.getStatus()));

            userDTOs.add(userDTO);
        }

        log.info("导出用户数据成功，共{}条记录", userDTOs.size());
        return userDTOs;
    }

    // 辅助方法：获取状态显示名称
    private String getStatusDisplayName(String status) {
        if (status == null) return "";
        switch (status) {
            case "verified": return "已认证";
            case "unverified": return "未认证";
            case "banned": return "已封禁";
            default: return status;
        }
    }
}