package com.campushelper.service;

import com.campushelper.dto.AuthResponseDTO;
import com.campushelper.dto.LoginDTO;
import com.campushelper.dto.RegisterDTO;
import com.campushelper.dto.RegisterUserDTO;

public interface AuthService {
    AuthResponseDTO login(LoginDTO loginDTO);
    void register(RegisterDTO registerDTO);
/*    void wxRegister(RegisterUserDTO registerDTO); // 微信注册*/
    void logout(String token);
}
