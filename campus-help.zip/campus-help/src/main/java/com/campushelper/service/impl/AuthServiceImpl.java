package com.campushelper.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.campushelper.dto.*;
import com.campushelper.entity.User;
import com.campushelper.mapper.UserMapper;
import com.campushelper.service.AuthService;
import com.campushelper.service.UserService;
import com.campushelper.utils.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final AuthenticationManager authenticationManager;
    private final UserMapper userMapper;
    private final UserService userService;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public AuthResponseDTO login(LoginDTO loginDTO) {
        // 使用Spring Security进行认证
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginDTO.getStudentId(),
                        loginDTO.getPassword()
                )
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);

        // 获取用户信息
        User user = (User) authentication.getPrincipal();

        // 检查用户状态 - 已封禁用户不能登录
        if ("banned".equals(user.getStatus())) {
            throw new RuntimeException("账号已被封禁，请联系管理员");
        }

        // 不再自动将 unverified 改为 verified
        // 管理员需要在后台手动认证用户

        // 生成JWT令牌
        String token = jwtUtil.generateToken(user.getStudentId(), user.getRole());

        // 转换为DTO
        UserDTO userDTO = new UserDTO();
        BeanUtils.copyProperties(user, userDTO);

        // 设置必要的字段
        userDTO.setStudentId(user.getStudentId());
        userDTO.setUsername(user.getStudentId()); // 设置username字段

        // 获取过期时间
        Date expirationDate = jwtUtil.getExpirationDateFromToken(token);
        Long expiresIn = (expirationDate.getTime() - System.currentTimeMillis()) / 1000;

        return new AuthResponseDTO(token, "Bearer", expiresIn, userDTO);
    }

    @Override
    @Transactional
    public void register(RegisterDTO registerDTO) {
        // 检查学号是否已存在
        if (userService.existsByStudentId(registerDTO.getStudentId())) {
            throw new RuntimeException("该学号已注册");
        }

        // 创建新用户
        User user = new User();
        BeanUtils.copyProperties(registerDTO, user);
        user.setPassword(passwordEncoder.encode(registerDTO.getPassword()));
        user.setRole("requester"); // 默认角色
        user.setCreditScore(100);
        user.setStatus("unverified"); // 新用户默认为未认证状态，需要管理员认证

        // 为密码注册的用户生成一个随机的openid
        // 格式：sys_时间戳_随机数
        String timestamp = String.valueOf(System.currentTimeMillis());
        String randomStr = UUID.randomUUID().toString().substring(0, 8);
        user.setOpenid("sys_" + timestamp + "_" + randomStr);

        // 保存用户
        userService.saveUser(user);
    }

/*    @Override
    @Transactional
    public void wxRegister(RegisterUserDTO registerDTO) {
        // 检查学号是否已存在
        if (userService.existsByStudentId(registerDTO.getStudentId())) {
            throw new RuntimeException("该学号已注册");
        }

        // 检查openid是否已存在
        User existingUser = userMapper.selectOne(new QueryWrapper<User>()
                .eq("openid", registerDTO.getOpenid()));
        if (existingUser != null) {
            throw new RuntimeException("微信账号已注册");
        }

        // 创建新用户
        User user = new User();
        BeanUtils.copyProperties(registerDTO, user);
        user.setPassword(passwordEncoder.encode(registerDTO.getPassword()));
        user.setRole("requester"); // 默认角色
        user.setCreditScore(100);
        user.setStatus("unverified"); // 微信注册也默认为未认证状态，需要管理员认证
        user.setOpenid(registerDTO.getOpenid());

        // 保存用户
        userService.saveUser(user);
    }*/

    @Override
    public void logout(String token) {
        // 可以在这里添加token到黑名单的逻辑
        SecurityContextHolder.clearContext();
    }
}