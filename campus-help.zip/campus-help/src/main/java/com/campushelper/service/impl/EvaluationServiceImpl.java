package com.campushelper.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.campushelper.dto.EvaluationDTO;
import com.campushelper.entity.Evaluation;
import com.campushelper.entity.Order;
import com.campushelper.entity.User;
import com.campushelper.exception.BusinessException;
import com.campushelper.mapper.EvaluationMapper;
import com.campushelper.mapper.OrderMapper;
import com.campushelper.mapper.UserMapper;
import com.campushelper.service.CreditService;
import com.campushelper.service.EvaluationService;
import com.campushelper.utils.Result;
import com.campushelper.vo.EvaluationVO;
import com.campushelper.vo.UserEvaluationStatsVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class EvaluationServiceImpl implements EvaluationService {

    private final EvaluationMapper evaluationMapper;
    private final OrderMapper orderMapper;
    private final UserMapper userMapper;
    private final CreditService creditService;  // 添加这行

    @Override
    @Transactional
    public Result<String> submitEvaluation(EvaluationDTO evaluationDTO, Integer fromUserId) {
        try {
            // 1. 验证订单是否存在且已完成
            Order order = orderMapper.selectById(evaluationDTO.getOrderId());
            if (order == null) {
                throw new BusinessException("订单不存在");
            }

            if (!"completed".equals(order.getStatus())) {
                throw new BusinessException("只有已完成的订单才能评价");
            }

            // 2. 验证评价对象是否正确
            if (!order.getPublisherId().equals(evaluationDTO.getToUserId()) &&
                    !order.getRunnerId().equals(evaluationDTO.getToUserId())) {
                throw new BusinessException("只能评价订单的相关用户");
            }

            if (fromUserId.equals(evaluationDTO.getToUserId())) {
                throw new BusinessException("不能评价自己");
            }

            // 3. 检查是否已评价过
            LambdaQueryWrapper<Evaluation> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(Evaluation::getOrderId, evaluationDTO.getOrderId())
                    .eq(Evaluation::getFromUserId, fromUserId);
            Evaluation existingEvaluation = evaluationMapper.selectOne(queryWrapper);
            if (existingEvaluation != null) {
                throw new BusinessException("您已经评价过此订单");
            }

            // 4. 创建评价记录
            Evaluation evaluation = new Evaluation();
            evaluation.setOrderId(evaluationDTO.getOrderId());
            evaluation.setFromUserId(fromUserId);
            evaluation.setToUserId(evaluationDTO.getToUserId());
            evaluation.setScore(evaluationDTO.getScore());
            evaluation.setContent(evaluationDTO.getContent());
            evaluation.setCreateTime(LocalDateTime.now());

            // 5. 保存评价
            int result = evaluationMapper.insert(evaluation);
            if (result <= 0) {
                throw new BusinessException("评价提交失败");
            }

            // 6. 更新用户信用分（根据评分）
            // 修改这行：使用CreditService更新信用分
            updateUserCreditScoreByService(evaluationDTO.getToUserId(), evaluationDTO.getScore(), evaluationDTO.getOrderId());

            return Result.success("评价提交成功");

        } catch (BusinessException e) {
            return Result.error(400, e.getMessage());
        } catch (Exception e) {
            log.error("提交评价失败", e);
            return Result.error(500, "提交评价失败");
        }
    }

    @Override
    public Result<List<?>> getEvaluationsByOrderId(Integer orderId) {
        try {
            List<Evaluation> evaluations = evaluationMapper.selectByOrderId(orderId);
            List<EvaluationVO> evaluationVOs = convertToVOList(evaluations);
            return Result.success(evaluationVOs);
        } catch (Exception e) {
            log.error("获取订单评价失败", e);
            return Result.error(500, "获取评价失败");
        }
    }

    @Override
    public Result<List<?>> getEvaluationsByUserId(Integer userId) {
        try {
            List<Evaluation> evaluations = evaluationMapper.selectByToUserId(userId);
            List<EvaluationVO> evaluationVOs = convertToVOList(evaluations);
            return Result.success(evaluationVOs);
        } catch (Exception e) {
            log.error("获取用户评价失败", e);
            return Result.error(500, "获取评价失败");
        }
    }

    @Override
    public Result<Boolean> checkEvaluationStatus(Integer orderId, Integer userId) {
        try {
            int count = evaluationMapper.countByOrderAndFromUser(orderId, userId);
            return Result.success(count > 0);
        } catch (Exception e) {
            log.error("检查评价状态失败", e);
            return Result.error(500, "检查失败");
        }
    }

    @Override
    public Result<UserEvaluationStatsVO> getUserEvaluationStats(Integer userId) {
        try {
            UserEvaluationStatsVO stats = new UserEvaluationStatsVO();
            stats.setUserId(userId);

            // 获取用户信息
            User user = userMapper.selectById(userId);
            if (user != null) {
                stats.setUserName(user.getName());
            }

            // 获取平均分
            Double avgScore = evaluationMapper.getAverageScoreByUserId(userId);
            stats.setAverageScore(avgScore != null ? avgScore : 0.0);

            // 获取评价总数
            int totalCount = evaluationMapper.countByToUserId(userId);
            stats.setTotalCount(totalCount);

            // 获取评分分布（通过XML查询）
            Map<String, Object> scoreDistribution = evaluationMapper.countUserEvaluations(userId);
            if (scoreDistribution != null) {
                stats.setFiveStarCount(((Number) scoreDistribution.get("five_star")).intValue());
                stats.setFourStarCount(((Number) scoreDistribution.get("four_star")).intValue());
                stats.setThreeStarCount(((Number) scoreDistribution.get("three_star")).intValue());
                stats.setTwoStarCount(((Number) scoreDistribution.get("two_star")).intValue());
                stats.setOneStarCount(((Number) scoreDistribution.get("one_star")).intValue());
            }

            return Result.success(stats);
        } catch (Exception e) {
            log.error("获取用户评价统计失败", e);
            return Result.error(500, "获取统计失败");
        }
    }

    /**
     * 将Evaluation实体列表转换为EvaluationVO列表
     */
    private List<EvaluationVO> convertToVOList(List<Evaluation> evaluations) {
        if (evaluations == null || evaluations.isEmpty()) {
            return new ArrayList<>();
        }

        return evaluations.stream().map(evaluation -> {
            EvaluationVO vo = new EvaluationVO();
            vo.setId(evaluation.getId());
            vo.setOrderId(evaluation.getOrderId());
            vo.setFromUserId(evaluation.getFromUserId());
            vo.setToUserId(evaluation.getToUserId());
            vo.setScore(evaluation.getScore());
            vo.setContent(evaluation.getContent());
            vo.setCreateTime(evaluation.getCreateTime());

            // 获取用户信息
            User fromUser = userMapper.selectById(evaluation.getFromUserId());
            User toUser = userMapper.selectById(evaluation.getToUserId());

            if (fromUser != null) {
                vo.setFromUserName(fromUser.getName());
                vo.setFromUserAvatar(fromUser.getAvatarUrl());
                vo.setFromUserRole(fromUser.getRole());
            }

            if (toUser != null) {
                vo.setToUserName(toUser.getName());
                vo.setToUserAvatar(toUser.getAvatarUrl());
                vo.setToUserRole(toUser.getRole());
            }

            // 获取订单信息
            Order order = orderMapper.selectById(evaluation.getOrderId());
            if (order != null) {
                vo.setOrderTitle(order.getTitle());
                vo.setOrderNo(order.getOrderNo());
                vo.setOrderReward(order.getReward() != null ? order.getReward().doubleValue() : 0.0);
            }

            return vo;
        }).collect(Collectors.toList());
    }

    /**
     * 通过CreditService更新用户信用分（推荐方式）
     */
    private void updateUserCreditScoreByService(Integer userId, Integer score, Integer orderId) {
        try {
            int changeScore;
            String changeType;

            // 根据评分调整信用分
            if (score >= 4) {
                // 4-5分：+3分
                changeScore = 3;
                changeType = "good_eval";
            } else if (score == 3) {
                // 3分：+1分
                changeScore = 1;
                changeType = "good_eval";
            } else {
                // 1-2分：-5分
                changeScore = -5;
                changeType = "bad_eval";
            }

            // 使用CreditService统一更新信用分并记录日志
            creditService.updateUserCreditScore(
                    userId,
                    changeScore,
                    changeType,
                    "评价变更信用分，评分：" + score + "分",
                    orderId
            );

        } catch (Exception e) {
            log.error("更新用户信用分失败", e);
        }
    }
}