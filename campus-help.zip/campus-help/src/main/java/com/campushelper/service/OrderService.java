package com.campushelper.service;

import com.campushelper.dto.OrderDTO;
import com.campushelper.entity.Order;
import com.campushelper.vo.OrderLogVO;
import com.campushelper.vo.OrderStatsVO;
import com.campushelper.vo.OrderVO;
import com.campushelper.vo.PageResult;

import java.util.List;
import java.util.Map;

public interface OrderService {

    // 分页查询订单列表
    PageResult<OrderVO> getOrderPage(Integer userId, Integer page, Integer size, String status, String category);

    // 发布任务
    Order publishTask(OrderDTO orderDTO, Integer publisherId);

    // 接取任务
    boolean acceptTask(Integer orderId, Integer runnerId);

    // 获取可接取的任务列表
    List<OrderVO> getAvailableTasks(Integer userId);

    // 获取我发布的任务
    List<OrderVO> getMyPublishedTasks(Integer userId);

    // 获取我接取的任务
    List<OrderVO> getMyAcceptedTasks(Integer userId);

    // 获取任务详情
    OrderVO getOrderDetail(Integer orderId, Integer userId);

    // 取消任务
    boolean cancelTask(Integer orderId, Integer userId);

    // 开始任务
    boolean startTask(Integer orderId, Integer userId);

    // 完成任务
    boolean completeTask(Integer orderId, Integer userId);

    // 获取任务统计
    OrderStatsVO getOrderStats(Integer userId);

    // 获取订单日志
    List<OrderLogVO> getOrderLogs(Integer orderId);

    // 发布者确认完成
    boolean confirmByPublisher(Integer orderId, Integer publisherId);

    // 接单人确认完成
    boolean confirmByRunner(Integer orderId, Integer runnerId);

    // 管理员：获取任务统计数据
    Map<String, Integer> getAdminOrderStats();

    // 管理员：获取任务列表（带分页和筛选）
    PageResult<OrderVO> getAdminOrderList(Integer page, Integer limit,
                                          String status, String category,
                                          String publisher, String runner,
                                          String time, String search);

    // 管理员：获取任务详情
    OrderVO getAdminOrderDetail(Integer orderId);

    // 管理员：取消订单
    boolean adminCancelOrder(Integer orderId);

    // 管理员：标记订单完成
    boolean adminCompleteOrder(Integer orderId);

    // 添加导出方法
    // 导出订单数据
    List<OrderVO> exportOrders(String status, String category,
                               String publisher, String runner,
                               String time, String search);
}