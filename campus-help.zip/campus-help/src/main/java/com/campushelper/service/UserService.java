package com.campushelper.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.campushelper.dto.UserDTO;
import com.campushelper.entity.User;
import com.campushelper.vo.UserVO;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.math.BigDecimal;
import java.util.List;

public interface UserService extends UserDetailsService {
    User getUserByStudentId(String studentId);
    UserDTO getUserById(Integer id);
    boolean existsByStudentId(String studentId);
    User saveUser(User user);
    User getUserByUsername(String username);
    UserVO getUserProfile(Integer userId);
    void updateUser(User user);
    void switchRole(Integer userId, String role);

    // 获取用户实体
    User getUserEntityById(Integer id);

    // 新增余额相关方法
    boolean checkUserBalance(Integer userId, BigDecimal amount);
    BigDecimal getUserBalance(Integer userId);
    boolean initUserWallet(Integer userId);

    // 添加通用方法
    List<User> list(QueryWrapper<User> queryWrapper);
}