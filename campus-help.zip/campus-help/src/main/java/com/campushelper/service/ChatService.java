package com.campushelper.service;

import com.campushelper.dto.ChatMessageDTO;
import com.campushelper.vo.ChatListVO;
import com.campushelper.vo.ChatVO;
import com.campushelper.vo.PageResult;

import java.util.List;

public interface ChatService {

    // 获取聊天列表
    List<ChatListVO> getChatList(Integer userId);

    // 获取订单聊天记录
    List<ChatVO> getChatByOrderId(Integer orderId, Integer userId);

    // 发送消息
    void sendMessage(ChatMessageDTO chatMessageDTO, Integer senderId);

    // 获取未读消息数量
    Integer getUnreadCount(Integer userId);

    // 标记消息为已读
    void markMessagesAsRead(Integer orderId, Integer userId);

    // 获取聊天记录（分页）
    PageResult<ChatVO> getChatMessages(Integer orderId, Integer userId,
                                       Integer page, Integer size);
}