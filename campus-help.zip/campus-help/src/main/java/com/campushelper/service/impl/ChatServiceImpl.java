package com.campushelper.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campushelper.dto.ChatMessageDTO;
import com.campushelper.entity.Chat;
import com.campushelper.entity.Order;
import com.campushelper.entity.User;
import com.campushelper.exception.BusinessException;
import com.campushelper.mapper.ChatMapper;
import com.campushelper.mapper.OrderMapper;
import com.campushelper.mapper.UserMapper;
import com.campushelper.service.ChatService;
import com.campushelper.utils.OrderStatusEnum;
import com.campushelper.vo.ChatListVO;
import com.campushelper.vo.ChatVO;
import com.campushelper.vo.PageResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ChatServiceImpl extends ServiceImpl<ChatMapper, Chat> implements ChatService {

    private final ChatMapper chatMapper;
    private final OrderMapper orderMapper;
    private final UserMapper userMapper;

    private static final DateTimeFormatter TIME_FORMATTER =
            DateTimeFormatter.ofPattern("HH:mm");
    private static final DateTimeFormatter DATE_FORMATTER =
            DateTimeFormatter.ofPattern("MM-dd HH:mm");

    @Override
    public List<ChatListVO> getChatList(Integer userId) {
        log.info("获取用户 {} 的聊天列表", userId);
        List<ChatListVO> chatList = chatMapper.selectChatListByUserId(userId);

        // 格式化时间和状态名称
        for (ChatListVO chat : chatList) {
            // 格式化时间
            if (chat.getLastMessageTime() != null) {
                chat.setFormattedTime(formatChatTime(chat.getLastMessageTime()));
            }

            // 设置状态名称
            if (chat.getOrderStatus() != null) {
                chat.setStatusName(getStatusName(chat.getOrderStatus()));
            }
        }

        log.info("用户 {} 的聊天列表返回 {} 条记录", userId, chatList.size());
        return chatList;
    }

    @Override
    public List<ChatVO> getChatByOrderId(Integer orderId, Integer userId) {
        log.info("获取订单 {} 的聊天记录，用户ID: {}", orderId, userId);

        if (userId == null) {
            throw new BusinessException("用户ID不能为空");
        }

        // 先检查用户是否有权限查看该订单的聊天记录
        Order order = orderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException("订单不存在");
        }

        // 权限检查：发布者、接单人、管理员可以查看
        boolean hasPermission = order.getPublisherId().equals(userId) ||
                (order.getRunnerId() != null && order.getRunnerId().equals(userId));

        if (!hasPermission) {
            // 检查是否是管理员
            User user = userMapper.selectById(userId);
            if (user == null || !"admin".equals(user.getRole())) {
                throw new BusinessException("您没有权限查看该订单的聊天记录");
            }
        }

        // 获取聊天记录，需要传递用户ID以设置isSelf字段
        List<ChatVO> chatList = chatMapper.selectChatByOrderId(orderId);

        // 设置isSelf字段并格式化时间
        for (ChatVO chat : chatList) {
            chat.setIsSelf(chat.getSenderId().equals(userId));

            // 格式化时间
            if (chat.getCreateTime() != null) {
                chat.setFormattedTime(formatChatTime(chat.getCreateTime()));
            }

            // 获取发送者信息
            User sender = userMapper.selectById(chat.getSenderId());
            if (sender != null) {
                chat.setSenderName(sender.getName());
                chat.setSenderAvatar(sender.getAvatarUrl());

                // 如果没有头像，使用默认
                if (chat.getSenderAvatar() == null) {
                    String defaultColor = getDefaultAvatarColor(sender.getName());
                    chat.setSenderAvatar("https://via.placeholder.com/50/" + defaultColor + "/ffffff?text="
                            + (sender.getName() != null && !sender.getName().isEmpty() ? sender.getName().charAt(0) : "U"));
                }
            }
        }

        // 标记消息为已读
        markMessagesAsRead(orderId, userId);

        return chatList;
    }

    @Override
    @Transactional
    public void sendMessage(ChatMessageDTO chatMessageDTO, Integer senderId) {
        log.info("开始发送消息 - 订单ID: {}, 发送者ID: {}, 内容: {}",
                chatMessageDTO.getOrderId(), senderId, chatMessageDTO.getContent());

        if (senderId == null) {
            throw new BusinessException("发送者ID不能为空");
        }

        // 检查订单是否存在
        Order order = orderMapper.selectById(chatMessageDTO.getOrderId());
        if (order == null) {
            log.error("订单不存在 - 订单ID: {}", chatMessageDTO.getOrderId());
            throw new BusinessException("订单不存在");
        }

        log.info("订单详情 - 订单ID: {}, 状态: {}, 发布者ID: {}, 接单人ID: {}",
                order.getId(), order.getStatus(), order.getPublisherId(), order.getRunnerId());

        // 检查用户是否是订单相关方
        boolean isPublisher = order.getPublisherId().equals(senderId);
        boolean isRunner = order.getRunnerId() != null && order.getRunnerId().equals(senderId);

        if (!isPublisher && !isRunner) {
            // 检查是否是管理员
            User sender = userMapper.selectById(senderId);
            if (sender == null || !"admin".equals(sender.getRole())) {
                log.warn("用户不是订单相关方 - 订单ID: {}, 用户ID: {}, 发布者ID: {}, 接单人ID: {}",
                        order.getId(), senderId, order.getPublisherId(), order.getRunnerId());
                throw new BusinessException("您不是订单相关方，无法发送消息");
            }
        }

        // 检查订单状态：pending状态下只有发布者可以发送消息（用于沟通任务详情）
        // accepted、in_progress、completed状态下双方都可以聊天
        // cancelled状态下不允许聊天

        String status = order.getStatus();
        boolean canChat = false;

        if ("pending".equals(status)) {
            // pending状态下，只有发布者可以发送消息（用于询问详情、修改任务等）
            canChat = isPublisher;
            if (!canChat && isRunner) {
                throw new BusinessException("任务尚未被接取，只有发布者可以发送消息");
            }
        } else if ("accepted".equals(status) ||
                "in_progress".equals(status) ||
                "completed".equals(status)) {
            // 已接单、进行中、已完成状态下，双方都可以聊天
            canChat = true;
        } else if ("cancelled".equals(status)) {
            // 已取消状态下不允许聊天
            throw new BusinessException("订单已取消，无法发送消息");
        } else {
            // 其他未知状态不允许聊天
            throw new BusinessException("订单当前状态不允许聊天");
        }

        if (!canChat) {
            throw new BusinessException("当前状态下不允许发送消息");
        }

        // 确定接收者
        Integer receiverId = null;
        if (isPublisher && order.getRunnerId() != null) {
            receiverId = order.getRunnerId();
        } else if (isRunner) {
            receiverId = order.getPublisherId();
        } else {
            // 如果是管理员发送消息，发给对方用户
            if (order.getPublisherId().equals(senderId)) {
                receiverId = order.getRunnerId();
            } else if (order.getRunnerId() != null && order.getRunnerId().equals(senderId)) {
                receiverId = order.getPublisherId();
            } else {
                // 管理员发给双方（这里发给发布者）
                receiverId = order.getPublisherId();
            }
        }

        log.info("消息接收者ID: {}", receiverId);

        // 保存聊天记录
        Chat chat = new Chat();
        chat.setOrderId(chatMessageDTO.getOrderId());
        chat.setSenderId(senderId);
        chat.setReceiverId(receiverId);
        chat.setContent(chatMessageDTO.getContent());
        chat.setType(chatMessageDTO.getType());
        chat.setIsRead(false);
        chat.setCreateTime(LocalDateTime.now());

        int result = chatMapper.insert(chat);
        log.info("消息保存成功 - 消息ID: {}, 影响行数: {}", chat.getId(), result);
    }

    @Override
    public Integer getUnreadCount(Integer userId) {
        log.info("查询用户 {} 的未读消息数量", userId);
        Integer count = chatMapper.selectUnreadCount(userId);
        log.info("用户 {} 的未读消息数量为: {}", userId, count);
        return count;
    }

    @Override
    @Transactional
    public void markMessagesAsRead(Integer orderId, Integer userId) {
        log.info("标记订单 {} 的消息为已读，用户ID: {}", orderId, userId);
        chatMapper.updateMessagesRead(orderId, userId);
    }

    @Override
    public PageResult<ChatVO> getChatMessages(Integer orderId, Integer userId,
                                              Integer page, Integer size) {
        // 验证用户权限
        Order order = orderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException("订单不存在");
        }

        boolean hasPermission = order.getPublisherId().equals(userId) ||
                (order.getRunnerId() != null && order.getRunnerId().equals(userId));

        if (!hasPermission) {
            // 检查是否是管理员
            User user = userMapper.selectById(userId);
            if (user == null || !"admin".equals(user.getRole())) {
                throw new BusinessException("没有权限查看聊天记录");
            }
        }

        // 创建分页查询
        Page<Chat> pageParam = new Page<>(page, size);
        LambdaQueryWrapper<Chat> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Chat::getOrderId, orderId)
                .orderByDesc(Chat::getCreateTime);

        Page<Chat> chatPage = page(pageParam, wrapper);

        // 转换为VO
        List<ChatVO> chatVOList = chatPage.getRecords().stream()
                .map(chat -> {
                    ChatVO chatVO = new ChatVO();
                    // 设置基本属性
                    chatVO.setId(chat.getId());
                    chatVO.setOrderId(chat.getOrderId());
                    chatVO.setSenderId(chat.getSenderId());
                    chatVO.setReceiverId(chat.getReceiverId());
                    chatVO.setContent(chat.getContent());
                    chatVO.setType(chat.getType());
                    chatVO.setIsRead(chat.getIsRead());
                    chatVO.setCreateTime(chat.getCreateTime());
                    chatVO.setFormattedTime(formatChatTime(chat.getCreateTime()));
                    chatVO.setIsSelf(chat.getSenderId().equals(userId));

                    // 获取发送者信息
                    User sender = userMapper.selectById(chat.getSenderId());
                    if (sender != null) {
                        chatVO.setSenderName(sender.getName());
                        chatVO.setSenderAvatar(sender.getAvatarUrl());

                        // 如果没有头像，使用默认
                        if (chatVO.getSenderAvatar() == null) {
                            String defaultColor = getDefaultAvatarColor(sender.getName());
                            chatVO.setSenderAvatar("https://via.placeholder.com/50/" + defaultColor + "/ffffff?text="
                                    + (sender.getName() != null && !sender.getName().isEmpty() ? sender.getName().charAt(0) : "U"));
                        }
                    }

                    return chatVO;
                })
                .collect(Collectors.toList());

        // 标记为已读
        markMessagesAsRead(orderId, userId);

        // 创建PageResult对象
        return new PageResult<>(
                chatVOList,
                chatPage.getTotal(),
                page,
                size
        );
    }

    // 格式化聊天时间
    private String formatChatTime(LocalDateTime time) {
        if (time == null) {
            return "";
        }

        LocalDateTime now = LocalDateTime.now();
        if (time.toLocalDate().equals(now.toLocalDate())) {
            return time.format(TIME_FORMATTER);
        } else {
            return time.format(DATE_FORMATTER);
        }
    }

    // 获取状态名称
    private String getStatusName(String status) {
        return OrderStatusEnum.getNameByCode(status);
    }

    // 获取默认头像颜色
    private String getDefaultAvatarColor(String name) {
        if (name == null || name.isEmpty()) {
            return "667eea";
        }

        // 根据名字的第一个字符生成颜色
        char firstChar = name.charAt(0);
        String[] colors = {
                "667eea", "805ad5", "3182ce", "38a169",
                "dd6b20", "e53e3e", "d69e2e", "38b2ac"
        };

        int index = Math.abs(firstChar) % colors.length;
        return colors[index];
    }
}