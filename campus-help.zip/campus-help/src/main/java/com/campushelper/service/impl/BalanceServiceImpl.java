package com.campushelper.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.campushelper.entity.BalanceLog;
import com.campushelper.entity.Wallet;
import com.campushelper.exception.BusinessException;
import com.campushelper.mapper.BalanceLogMapper;
import com.campushelper.mapper.WalletMapper;
import com.campushelper.service.BalanceService;
import com.campushelper.utils.OrderNoUtil;
import com.campushelper.utils.Result;
import com.campushelper.vo.BalanceOverviewVO;
import com.campushelper.vo.BalanceLogVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BalanceServiceImpl implements BalanceService {

    private final WalletMapper walletMapper;
    private final BalanceLogMapper balanceLogMapper;
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("MM-dd HH:mm");

    @Override
    public Result<Wallet> getWallet(Integer userId) {
        Wallet wallet = walletMapper.selectOne(
                new QueryWrapper<Wallet>().eq("user_id", userId)
        );

        if (wallet == null) {
            // 如果钱包不存在，创建默认钱包
            wallet = createDefaultWallet(userId);
        }

        return Result.success(wallet);
    }

    @Override
    public Result<BalanceOverviewVO> getBalanceOverview(Integer userId) {
        Wallet wallet = walletMapper.selectOne(
                new QueryWrapper<Wallet>().eq("user_id", userId)
        );

        if (wallet == null) {
            // 如果钱包不存在，创建默认钱包
            wallet = createDefaultWallet(userId);
        }

        BalanceOverviewVO vo = new BalanceOverviewVO();
        vo.setBalance(wallet.getBalance());
        vo.setTotalRecharge(wallet.getTotalRecharge());
        vo.setTotalConsume(wallet.getTotalConsume());
        vo.setStatus(wallet.getStatus());

        return Result.success(vo);
    }

    @Override
    public Result<List<BalanceLogVO>> getBalanceLogs(Integer userId, Integer page, Integer size) {
        Page<BalanceLog> pageInfo = new Page<>(page, size);
        QueryWrapper<BalanceLog> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId)
                .orderByDesc("create_time");

        Page<BalanceLog> result = balanceLogMapper.selectPage(pageInfo, wrapper);

        List<BalanceLogVO> logs = result.getRecords().stream()
                .map(this::convertToVO)
                .collect(Collectors.toList());

        return Result.success(logs);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result<String> recharge(Integer userId, BigDecimal amount, String paymentMethod) {
        // 验证充值金额
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new BusinessException("充值金额必须大于0");
        }

        if (amount.compareTo(new BigDecimal("5000")) > 0) {
            throw new BusinessException("单次充值金额不能超过5000元");
        }

        // 支持微信和支付宝充值
        if (!"wechat".equals(paymentMethod) && !"alipay".equals(paymentMethod)) {
            throw new BusinessException("目前仅支持微信和支付宝充值");
        }

        // 获取用户钱包
        Wallet wallet = walletMapper.selectOne(
                new QueryWrapper<Wallet>().eq("user_id", userId)
        );

        if (wallet == null) {
            wallet = createDefaultWallet(userId);
        }

        // 检查钱包状态
        if (!"normal".equals(wallet.getStatus())) {
            throw new BusinessException("钱包状态异常，无法充值");
        }

        // 生成支付订单号
        String paymentNo = OrderNoUtil.generatePaymentNo();

        // 创建充值记录
        BalanceLog balanceLog = new BalanceLog();
        balanceLog.setUserId(userId);
        balanceLog.setType("recharge");
        balanceLog.setAmount(amount);
        balanceLog.setBalanceBefore(wallet.getBalance());
        balanceLog.setBalanceAfter(wallet.getBalance().add(amount));
        balanceLog.setPaymentMethod(paymentMethod);
        balanceLog.setPaymentNo(paymentNo);
        balanceLog.setRemark(getPaymentMethodName(paymentMethod) + "充值");
        balanceLog.setStatus("pending");

        balanceLogMapper.insert(balanceLog);

        // 模拟支付成功回调
        // 在实际应用中，这里应该调用微信/支付宝的支付接口，然后通过回调来确认支付成功
        // 这里为了简化，直接模拟成功
        try {
            // 模拟支付过程（延迟1秒）
            Thread.sleep(1000);

            // 处理支付回调
            handleRechargeCallback(paymentNo, "success");

            log.info("用户{} {}充值成功，金额：{}，订单号：{}",
                    userId, getPaymentMethodName(paymentMethod), amount, paymentNo);
            return Result.success(getPaymentMethodName(paymentMethod) + "充值成功", paymentNo);
        } catch (Exception e) {
            log.error("充值异常", e);
            throw new BusinessException("充值处理异常");
        }
    }

    // 添加获取支付方式名称的方法
    private String getPaymentMethodName(String method) {
        if ("wechat".equals(method)) {
            return "微信";
        } else if ("alipay".equals(method)) {
            return "支付宝";
        }
        return method;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result<Boolean> handleRechargeCallback(String paymentNo, String status) {
        BalanceLog balanceLog = balanceLogMapper.selectOne(
                new QueryWrapper<BalanceLog>().eq("payment_no", paymentNo)
        );

        if (balanceLog == null) {
            throw new BusinessException("充值记录不存在");
        }

        if (!"pending".equals(balanceLog.getStatus())) {
            return Result.success("订单已处理");
        }

        if ("success".equals(status)) {
            // 更新充值记录状态
            balanceLog.setStatus("success");
            balanceLog.setCompleteTime(LocalDateTime.now());
            balanceLogMapper.updateById(balanceLog);

            // 更新钱包余额
            walletMapper.recharge(balanceLog.getUserId(), balanceLog.getAmount());

            log.info("用户{}充值成功，金额：{}", balanceLog.getUserId(), balanceLog.getAmount());
            return Result.success(true);
        } else {
            // 充值失败
            balanceLog.setStatus("failed");
            balanceLog.setCompleteTime(LocalDateTime.now());
            balanceLogMapper.updateById(balanceLog);

            return Result.success(false);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result<Boolean> consume(Integer userId, BigDecimal amount, Integer orderId, String remark) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new BusinessException("消费金额必须大于0");
        }

        Wallet wallet = walletMapper.selectOne(
                new QueryWrapper<Wallet>().eq("user_id", userId)
        );

        if (wallet == null || wallet.getBalance().compareTo(amount) < 0) {
            throw new BusinessException("余额不足");
        }

        // 创建消费记录
        BalanceLog balanceLog = new BalanceLog();
        balanceLog.setUserId(userId);
        balanceLog.setOrderId(orderId);
        balanceLog.setType("consume");
        balanceLog.setAmount(amount.negate()); // 负数为消费
        balanceLog.setBalanceBefore(wallet.getBalance());
        balanceLog.setBalanceAfter(wallet.getBalance().subtract(amount));
        balanceLog.setRemark(remark);
        balanceLog.setStatus("success");
        balanceLog.setCompleteTime(LocalDateTime.now());

        balanceLogMapper.insert(balanceLog);

        // 更新钱包
        int affected = walletMapper.consume(userId, amount);
        if (affected == 0) {
            throw new BusinessException("消费失败");
        }

        return Result.success(true);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result<Boolean> refund(Integer userId, BigDecimal amount, Integer orderId, String remark) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new BusinessException("退款金额必须大于0");
        }

        Wallet wallet = walletMapper.selectOne(
                new QueryWrapper<Wallet>().eq("user_id", userId)
        );

        if (wallet == null) {
            throw new BusinessException("用户钱包不存在");
        }

        // 创建退款记录
        BalanceLog balanceLog = new BalanceLog();
        balanceLog.setUserId(userId);
        balanceLog.setOrderId(orderId);
        balanceLog.setType("refund");
        balanceLog.setAmount(amount); // 正数为退款
        balanceLog.setBalanceBefore(wallet.getBalance());
        balanceLog.setBalanceAfter(wallet.getBalance().add(amount));
        balanceLog.setRemark(remark);
        balanceLog.setStatus("success");
        balanceLog.setCompleteTime(LocalDateTime.now());

        balanceLogMapper.insert(balanceLog);

        // 更新钱包
        int affected = walletMapper.refund(userId, amount);
        if (affected == 0) {
            throw new BusinessException("退款失败");
        }

        return Result.success(true);
    }

    @Override
    public boolean checkBalance(Integer userId, BigDecimal amount) {
        Wallet wallet = walletMapper.selectOne(
                new QueryWrapper<Wallet>().eq("user_id", userId)
        );

        return wallet != null && wallet.getBalance().compareTo(amount) >= 0;
    }

    @Override
    public Result<Boolean> createWallet(Integer userId) {
        // 检查是否已存在钱包
        Wallet existingWallet = walletMapper.selectOne(
                new QueryWrapper<Wallet>().eq("user_id", userId)
        );

        if (existingWallet != null) {
            return Result.success(true);
        }

        // 创建新钱包
        Wallet wallet = new Wallet();
        wallet.setUserId(userId);
        wallet.setBalance(BigDecimal.ZERO);
        wallet.setTotalRecharge(BigDecimal.ZERO);
        wallet.setTotalConsume(BigDecimal.ZERO);
        wallet.setStatus("normal");

        int result = walletMapper.insert(wallet);
        return Result.success(result > 0);
    }

    @Override
    public Result<String> getRechargeStatus(String paymentNo) {
        BalanceLog balanceLog = balanceLogMapper.selectOne(
                new QueryWrapper<BalanceLog>().eq("payment_no", paymentNo)
        );

        if (balanceLog == null) {
            return Result.error(404, "充值记录不存在");
        }

        return Result.success(balanceLog.getStatus());
    }

    @Override
    public Result<Wallet> getTotalStats(Integer userId) {
        Wallet wallet = walletMapper.selectOne(
                new QueryWrapper<Wallet>().eq("user_id", userId)
        );

        if (wallet == null) {
            return Result.error(404, "钱包不存在");
        }

        return Result.success(wallet);
    }

    private Wallet createDefaultWallet(Integer userId) {
        Wallet wallet = new Wallet();
        wallet.setUserId(userId);
        wallet.setBalance(BigDecimal.ZERO);
        wallet.setTotalRecharge(BigDecimal.ZERO);
        wallet.setTotalConsume(BigDecimal.ZERO);
        wallet.setStatus("normal");

        walletMapper.insert(wallet);
        return wallet;
    }

    private BalanceLogVO convertToVO(BalanceLog log) {
        BalanceLogVO vo = new BalanceLogVO();
        BeanUtils.copyProperties(log, vo);

        // 设置类型名称
        String typeName = "";
        switch (log.getType()) {
            case "recharge":
                typeName = "充值";
                break;
            case "consume":
                typeName = "消费";
                break;
            case "refund":
                typeName = "退款";
                break;
            case "withdraw":
                typeName = "提现";
                break;
            case "system_adjust":
                typeName = "系统调整";
                break;
            default:
                typeName = "其他";
        }
        vo.setTypeName(typeName);

        // 设置状态名称
        String statusName = "";
        switch (log.getStatus()) {
            case "pending":
                statusName = "处理中";
                break;
            case "success":
                statusName = "成功";
                break;
            case "failed":
                statusName = "失败";
                break;
            case "cancelled":
                statusName = "已取消";
                break;
            default:
                statusName = log.getStatus();
        }
        vo.setStatusName(statusName);

        // 设置相对时间
        if (log.getCreateTime() != null) {
            vo.setTimeAgo(formatTimeAgo(log.getCreateTime()));
        }

        return vo;
    }

    private String formatTimeAgo(LocalDateTime time) {
        // 这里可以添加时间格式化逻辑
        return time.format(TIME_FORMATTER);
    }


    // 在BalanceServiceImpl.java中添加以下方法
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result<String> withdraw(Integer userId, BigDecimal amount, String method, String remark) {
        // 验证提现金额
        if (amount.compareTo(new BigDecimal("10.00")) < 0) {
            throw new BusinessException("提现金额不能低于10元");
        }

        if (amount.compareTo(new BigDecimal("10000.00")) > 0) {
            throw new BusinessException("单次提现金额不能超过10000元");
        }

        // 获取用户钱包
        Wallet wallet = walletMapper.selectOne(
                new QueryWrapper<Wallet>().eq("user_id", userId)
        );

        if (wallet == null) {
            throw new BusinessException("钱包不存在");
        }

        // 检查钱包状态
        if (!"normal".equals(wallet.getStatus())) {
            throw new BusinessException("钱包状态异常，无法提现");
        }

        // 计算手续费（实际应该调用calculateWithdrawFee方法）
        BigDecimal fee = calculateFee(amount, method, userId);
        BigDecimal totalAmount = amount.add(fee); // 提现金额 + 手续费

        // 检查余额是否充足
        if (wallet.getBalance().compareTo(totalAmount) < 0) {
            throw new BusinessException("余额不足，无法提现");
        }

        // 生成提现订单号
        String withdrawNo = OrderNoUtil.generateWithdrawNo();

        // 创建提现记录
        BalanceLog balanceLog = new BalanceLog();
        balanceLog.setUserId(userId);
        balanceLog.setType("withdraw");
        balanceLog.setAmount(amount.negate()); // 负数为提现
        balanceLog.setFee(fee);
        balanceLog.setBalanceBefore(wallet.getBalance());
        balanceLog.setBalanceAfter(wallet.getBalance().subtract(totalAmount));
        balanceLog.setPaymentMethod(method);
        balanceLog.setPaymentNo(withdrawNo);
        balanceLog.setRemark(remark != null ? remark : "提现到" + getMethodName(method));
        balanceLog.setStatus("pending");

        balanceLogMapper.insert(balanceLog);

        // 更新钱包余额（扣除提现金额和手续费）
        int affected = walletMapper.withdraw(userId, totalAmount);
        if (affected == 0) {
            throw new BusinessException("提现失败，请稍后重试");
        }

        // 模拟提现处理（实际应调用第三方提现接口）
        // 这里直接标记为处理中，需要后续回调确认
        handleWithdrawCallback(withdrawNo, "processing");

        log.info("用户{}提现申请成功，金额：{}，手续费：{}", userId, amount, fee);
        return Result.success("提现申请已提交，请等待处理", withdrawNo);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result<Boolean> handleWithdrawCallback(String withdrawNo, String status) {
        BalanceLog balanceLog = balanceLogMapper.selectOne(
                new QueryWrapper<BalanceLog>().eq("payment_no", withdrawNo)
        );

        if (balanceLog == null) {
            throw new BusinessException("提现记录不存在");
        }

        // 更新提现记录状态
        balanceLog.setStatus(status);
        balanceLog.setCompleteTime(LocalDateTime.now());
        balanceLogMapper.updateById(balanceLog);

        if ("success".equals(status)) {
            log.info("提现成功，订单号：{}", withdrawNo);
        } else if ("failed".equals(status)) {
            // 提现失败，退款到用户账户
            walletMapper.refund(balanceLog.getUserId(), balanceLog.getAmount().abs());
            log.warn("提现失败，已退款，订单号：{}", withdrawNo);
        }

        return Result.success(true);
    }

    @Override
    public Result<String> getWithdrawStatus(String withdrawNo) {
        BalanceLog balanceLog = balanceLogMapper.selectOne(
                new QueryWrapper<BalanceLog>().eq("payment_no", withdrawNo)
        );

        if (balanceLog == null) {
            return Result.error(404, "提现记录不存在");
        }

        return Result.success(balanceLog.getStatus());
    }

    @Override
    public Result<List<BalanceLogVO>> getWithdrawLogs(Integer userId, Integer page, Integer size) {
        Page<BalanceLog> pageInfo = new Page<>(page, size);
        QueryWrapper<BalanceLog> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId)
                .eq("type", "withdraw")
                .orderByDesc("create_time");

        Page<BalanceLog> result = balanceLogMapper.selectPage(pageInfo, wrapper);

        List<BalanceLogVO> logs = result.getRecords().stream()
                .map(this::convertToVO)
                .collect(Collectors.toList());

        return Result.success(logs);
    }

    @Override
    public Result<BigDecimal> calculateWithdrawFee(BigDecimal amount, String method, Integer userId) {
        // 计算手续费规则：提现金额的1%，最低1元
        BigDecimal fee = amount.multiply(new BigDecimal("0.01"));
        if (fee.compareTo(new BigDecimal("1.00")) < 0) {
            fee = new BigDecimal("1.00");
        }

        // 检查本月提现次数（这里简化处理）
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime startOfMonth = now.withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);

        // 将 Integer 改为 Long
        Long withdrawCount = balanceLogMapper.selectCount(
                new QueryWrapper<BalanceLog>()
                        .eq("user_id", userId)
                        .eq("type", "withdraw")
                        .eq("status", "success")
                        .ge("create_time", startOfMonth)
        );

        // 每月前3次免手续费
        if (withdrawCount != null && withdrawCount < 3) {
            fee = BigDecimal.ZERO;
        }

        return Result.success(fee);
    }

    @Override
    public Result<Boolean> checkWithdrawAvailable(Integer userId) {
        Wallet wallet = walletMapper.selectOne(
                new QueryWrapper<Wallet>().eq("user_id", userId)
        );

        if (wallet == null) {
            return Result.success(false);
        }

        // 检查钱包状态
        boolean isNormal = "normal".equals(wallet.getStatus());

        // 检查余额是否大于最低提现金额
        boolean hasEnoughBalance = wallet.getBalance().compareTo(new BigDecimal("10.00")) >= 0;

        return Result.success(isNormal && hasEnoughBalance);
    }

    // 私有方法：计算手续费
    private BigDecimal calculateFee(BigDecimal amount, String method, Integer userId) {
        Result<BigDecimal> feeResult = calculateWithdrawFee(amount, method, userId);
        if (feeResult.getCode() == 200) {
            return feeResult.getData();
        }
        // 默认计算
        BigDecimal fee = amount.multiply(new BigDecimal("0.01"));
        return fee.compareTo(new BigDecimal("1.00")) < 0 ? new BigDecimal("1.00") : fee;
    }

    // 私有方法：获取提现方式名称
    private String getMethodName(String method) {
        switch (method) {
            case "wechat":
                return "微信零钱";
            case "alipay":
                return "支付宝余额";
            case "bank":
                return "银行卡";
            default:
                return "其他方式";
        }
    }

    @Override
    public BigDecimal getUserBalance(Integer userId) {
        Wallet wallet = walletMapper.selectOne(
                new LambdaQueryWrapper<Wallet>()
                        .eq(Wallet::getUserId, userId)
        );
        return wallet != null ? wallet.getBalance() : BigDecimal.ZERO;
    }
}