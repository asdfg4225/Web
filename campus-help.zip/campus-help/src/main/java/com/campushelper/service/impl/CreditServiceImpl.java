package com.campushelper.service.impl;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.campushelper.entity.CreditLog;
import com.campushelper.entity.User;
import com.campushelper.mapper.CreditLogMapper;
import com.campushelper.mapper.UserMapper;
import com.campushelper.service.CreditService;
import com.campushelper.utils.CreditUtil;
import com.campushelper.vo.CreditOverviewVO;
import com.campushelper.vo.CreditLogVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class CreditServiceImpl implements CreditService {

    private final CreditLogMapper creditLogMapper;
    private final UserMapper userMapper;

    @Override
    public CreditOverviewVO getCreditOverview(Integer userId) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            return null;
        }

        CreditOverviewVO overview = new CreditOverviewVO();
        overview.setUserId(userId);
        overview.setCurrentScore(user.getCreditScore());
        overview.setScoreLevel(CreditUtil.getScoreLevel(user.getCreditScore()));
        overview.setLevelName(CreditUtil.getLevelName(user.getCreditScore()));

        // 统计各类变更次数
        overview.setCompleteCount(creditLogMapper.countCompleteTasks(userId));
        overview.setGoodEvalCount(creditLogMapper.countGoodEvaluations(userId));
        overview.setCancelCount(creditLogMapper.countCancelOrders(userId));

        // 计算最近7天变化
        LocalDateTime sevenDaysAgo = LocalDateTime.now().minusDays(7);
        Integer recentChange = creditLogMapper.sumChangeScoreSince(userId, sevenDaysAgo);
        overview.setRecent7DaysChange(recentChange != null ? recentChange : 0);

        // 获取最近30天的信用分趋势数据（简化版）
        List<CreditLog> recentLogs = creditLogMapper.selectByUserIdAndTime(userId,
                LocalDateTime.now().minusDays(30));
        overview.setTrendData(CreditUtil.calculateTrendData(recentLogs));

        return overview;
    }

    @Override
    public List<CreditLogVO> getCreditLogs(Integer userId, String filterType) {
        List<CreditLog> logs;

        if ("all".equals(filterType)) {
            logs = creditLogMapper.selectByUserIdWithOrderNo(userId);
        } else if ("add".equals(filterType)) {
            logs = creditLogMapper.selectByUserIdWithOrderNo(userId).stream()
                    .filter(log -> log.getChangeScore() > 0)
                    .collect(Collectors.toList());
        } else if ("subtract".equals(filterType)) {
            logs = creditLogMapper.selectByUserIdWithOrderNo(userId).stream()
                    .filter(log -> log.getChangeScore() < 0)
                    .collect(Collectors.toList());
        } else if ("month".equals(filterType)) {
            LocalDateTime oneMonthAgo = LocalDateTime.now().minusMonths(1);
            logs = creditLogMapper.selectByUserIdAndTime(userId, oneMonthAgo);
        } else {
            logs = creditLogMapper.selectByUserIdWithOrderNo(userId);
        }

        return logs.stream()
                .map(this::convertToVO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void addCreditLog(CreditLog creditLog) {
        creditLog.setCreateTime(LocalDateTime.now());
        creditLogMapper.insert(creditLog);
        log.info("添加信用分记录: userId={}, changeType={}, changeScore={}",
                creditLog.getUserId(), creditLog.getChangeType(), creditLog.getChangeScore());
    }

    @Override
    public Integer getCurrentCreditScore(Integer userId) {
        User user = userMapper.selectById(userId);
        return user != null ? user.getCreditScore() : null;
    }

    @Override
    @Transactional
    public void updateUserCreditScore(Integer userId, Integer changeScore, String changeType,
                                      String remark, Integer orderId) {
        // 获取当前用户和信用分
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new RuntimeException("用户不存在");
        }

        int oldScore = user.getCreditScore();
        int newScore = oldScore + changeScore;

        // 确保信用分不低于0
        if (newScore < 0) {
            newScore = 0;
            changeScore = newScore - oldScore;
        }

        // 使用 UpdateWrapper 只更新信用分字段，性能更好
        UpdateWrapper<User> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", userId)
                .set("credit_score", newScore);
        userMapper.update(null, updateWrapper);

        // 记录信用分变更日志
        CreditLog creditLog = new CreditLog();
        creditLog.setUserId(userId);
        creditLog.setChangeType(changeType);
        creditLog.setChangeScore(changeScore);
        creditLog.setCurrentScore(newScore);
        creditLog.setOrderId(orderId);
        creditLog.setRemark(remark);
        creditLog.setCreateTime(LocalDateTime.now());

        creditLogMapper.insert(creditLog);

        log.info("更新用户信用分: userId={}, oldScore={}, changeScore={}, newScore={}, type={}",
                userId, oldScore, changeScore, newScore, changeType);
    }

    @Override
    public List<CreditLogVO> getRecentCreditLogs(Integer userId, Integer limit) {
        List<CreditLog> logs = creditLogMapper.selectByUserIdWithOrderNo(userId).stream()
                .limit(limit)
                .collect(Collectors.toList());

        return logs.stream()
                .map(this::convertToVO)
                .collect(Collectors.toList());
    }

    private CreditLogVO convertToVO(CreditLog creditLog) {
        CreditLogVO vo = new CreditLogVO();
        BeanUtils.copyProperties(creditLog, vo);

        // 设置变更类型显示名称
        vo.setChangeTypeName(CreditUtil.getChangeTypeName(creditLog.getChangeType()));

        // 格式化时间
        vo.setCreateTimeStr(CreditUtil.formatTime(creditLog.getCreateTime()));

        return vo;
    }
}