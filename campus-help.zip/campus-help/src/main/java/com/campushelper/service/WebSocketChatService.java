package com.campushelper.service;

import com.campushelper.dto.ChatMessageDTO;
import com.campushelper.entity.Chat;
import com.campushelper.entity.User;
import com.campushelper.mapper.UserMapper;
import com.campushelper.utils.JwtUtil;
import com.campushelper.vo.ChatVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Slf4j
@Service
@RequiredArgsConstructor
public class WebSocketChatService {

    private final SimpMessagingTemplate messagingTemplate;
    private final ChatService chatService;
    private final UserMapper userMapper;
    private final JwtUtil jwtUtil;

    private static final DateTimeFormatter TIME_FORMATTER =
            DateTimeFormatter.ofPattern("HH:mm");

    /**
     * 发送实时消息
     */
    public void sendMessage(ChatMessageDTO chatMessageDTO, Integer senderId) {
        // 保存消息到数据库
        chatService.sendMessage(chatMessageDTO, senderId);

        // 获取发送者信息
        User sender = userMapper.selectById(senderId);

        // 创建返回给前端的消息对象
        ChatVO chatVO = new ChatVO();
        chatVO.setOrderId(chatMessageDTO.getOrderId());
        chatVO.setSenderId(senderId);
        chatVO.setContent(chatMessageDTO.getContent());
        chatVO.setType(chatMessageDTO.getType());
        chatVO.setCreateTime(LocalDateTime.now());
        chatVO.setFormattedTime(LocalDateTime.now().format(TIME_FORMATTER));

        if (sender != null) {
            chatVO.setSenderName(sender.getName());
            chatVO.setSenderAvatar(sender.getAvatarUrl());
        }

        // 发送消息给订单相关的用户
        String orderTopic = "/topic/order/" + chatMessageDTO.getOrderId();
        messagingTemplate.convertAndSend(orderTopic, chatVO);

        log.info("WebSocket消息发送成功: 订单{}，发送者{}",
                chatMessageDTO.getOrderId(), senderId);
    }

    /**
     * 发送系统通知
     */
    public void sendSystemNotification(Integer userId, String message) {
        ChatVO notification = new ChatVO();
        notification.setSenderId(0); // 系统消息
        notification.setSenderName("系统通知");
        notification.setContent(message);
        notification.setType("system");
        notification.setCreateTime(LocalDateTime.now());
        notification.setFormattedTime(LocalDateTime.now().format(TIME_FORMATTER));

        // 发送给指定用户
        String userQueue = "/queue/notifications/" + userId;
        messagingTemplate.convertAndSendToUser(userId.toString(), "/queue/notifications", notification);
    }

    /**
     * 发送订单状态更新通知
     */
    public void sendOrderStatusUpdate(Integer orderId, String status, String message) {
        ChatVO notification = new ChatVO();
        notification.setOrderId(orderId);
        notification.setSenderId(0);
        notification.setSenderName("系统通知");
        notification.setContent("订单状态更新: " + message);
        notification.setType("system");
        notification.setCreateTime(LocalDateTime.now());
        notification.setFormattedTime(LocalDateTime.now().format(TIME_FORMATTER));

        // 发送给订单相关的所有用户
        String orderTopic = "/topic/order/" + orderId;
        messagingTemplate.convertAndSend(orderTopic, notification);
    }
}