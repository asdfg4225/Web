package com.campushelper.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.campushelper.dto.OrderDTO;
import com.campushelper.entity.Order;
import com.campushelper.entity.OrderLog;
import com.campushelper.entity.User;
import com.campushelper.exception.BusinessException;
import com.campushelper.mapper.OrderLogMapper;
import com.campushelper.mapper.OrderMapper;
import com.campushelper.service.BalanceService;
import com.campushelper.service.CreditService;
import com.campushelper.service.OrderService;
import com.campushelper.service.UserService;
import com.campushelper.utils.*;
import com.campushelper.vo.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private final OrderMapper orderMapper;
    private final OrderLogMapper orderLogMapper;
    private final UserService userService;
    private final CreditService creditService;
    private final BalanceService balanceService; // 新增余额服务

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    @Override
    @Transactional(readOnly = true)
    public PageResult<OrderVO> getOrderPage(Integer userId, Integer page, Integer size, String status, String category) {
        log.info("分页查询订单: userId={}, page={}, size={}, status={}, category={}",
                userId, page, size, status, category);

        // 计算分页偏移量
        int offset = (page - 1) * size;

        // 查询数据（排除自己发布的任务）
        List<OrderVO> orderList = orderMapper.selectOrderPage(
                status,
                category,
                userId,
                offset,
                size
        );

        // 查询总数
        Long total = orderMapper.countOrderPage(status, category, userId);

        return new PageResult<>(orderList, total, page, size);
    }

    @Override
    @Transactional
    public Order publishTask(OrderDTO orderDTO, Integer publisherId) {
        log.info("发布任务: publisherId={}, orderDTO={}", publisherId, orderDTO);

        // 验证发布者
        User publisher = userService.getUserEntityById(publisherId);
        if (publisher == null) {
            throw new BusinessException("发布者不存在");
        }
        if (!"requester".equals(publisher.getRole())) {
            throw new BusinessException("只有委托人才能发布任务");
        }

        // 验证任务信息
        if (orderDTO.getReward() == null || orderDTO.getReward().compareTo(BigDecimal.ZERO) <= 0) {
            throw new BusinessException("悬赏金额必须大于0");
        }

        if (orderDTO.getDeadline() == null || orderDTO.getDeadline().isBefore(LocalDateTime.now())) {
            throw new BusinessException("截止时间必须晚于当前时间");
        }

        // 检查发布者余额是否充足（新增）
        boolean balanceSufficient = userService.checkUserBalance(publisherId, orderDTO.getReward());
        if (!balanceSufficient) {
            throw new BusinessException("余额不足，请先充值。当前余额: " +
                    userService.getUserBalance(publisherId) + "，需要金额: " + orderDTO.getReward());
        }

        // 创建订单
        Order order = new Order();
        BeanUtils.copyProperties(orderDTO, order);
        order.setOrderNo(OrderNoUtil.generateOrderNo());
        order.setPublisherId(publisherId);
        order.setStatus("pending");
        order.setCreateTime(LocalDateTime.now());
        order.setUpdateTime(LocalDateTime.now());

        orderMapper.insert(order);

        // 记录发布任务的日志
        recordOrderLog(order.getId(), null, "pending", publisherId, "发布任务");

        // 预扣款（冻结金额）（新增）
        try {
            var freezeResult = balanceService.consume(publisherId, orderDTO.getReward(), order.getId(), "发布任务预扣款");
            if (freezeResult != null && freezeResult.getCode() == 200 && Boolean.TRUE.equals(freezeResult.getData())) {
                log.info("发布任务预扣款成功: orderId={}, publisherId={}, amount={}",
                        order.getId(), publisherId, orderDTO.getReward());
            } else {
                // 扣款失败，需要回滚订单
                throw new BusinessException("预扣款失败，请重试");
            }
        } catch (Exception e) {
            log.error("发布任务预扣款失败: orderId={}, publisherId={}", order.getId(), publisherId, e);
            throw new BusinessException("预扣款失败: " + e.getMessage());
        }

        log.info("任务发布成功: orderId={}, 预扣款金额={}", order.getId(), orderDTO.getReward());
        return order;
    }

    @Override
    @Transactional
    public boolean acceptTask(Integer orderId, Integer runnerId) {
        log.info("接取任务: orderId={}, runnerId={}", orderId, runnerId);

        // 验证接单人
        User runner = userService.getUserEntityById(runnerId);
        if (runner == null) {
            throw new BusinessException("接单人不存在");
        }
        if (!"runner".equals(runner.getRole())) {
            throw new BusinessException("只有接单人才能接取任务");
        }

        // 验证订单
        Order order = orderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException("任务不存在");
        }
        if (!"pending".equals(order.getStatus())) {
            throw new BusinessException("任务已不可接取");
        }
        if (order.getPublisherId().equals(runnerId)) {
            throw new BusinessException("不能接取自己发布的任务");
        }

        String oldStatus = order.getStatus();

        // 更新订单
        order.setRunnerId(runnerId);
        order.setStatus("accepted");
        order.setUpdateTime(LocalDateTime.now());

        int result = orderMapper.updateById(order);

        if (result > 0) {
            // 记录接单日志
            recordOrderLog(orderId, oldStatus, "accepted", runnerId, "接取任务");
            log.info("任务接取成功: orderId={}, runnerId={}", orderId, runnerId);
        } else {
            log.error("任务接取失败: orderId={}, runnerId={}", orderId, runnerId);
        }

        return result > 0;
    }

    @Override
    @Transactional(readOnly = true)
    public List<OrderVO> getAvailableTasks(Integer userId) {
        log.info("获取可接取任务: userId={}", userId);

        QueryWrapper<Order> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("status", "pending")
                .ne("publisher_id", userId)
                .orderByDesc("create_time");

        List<Order> orders = orderMapper.selectList(queryWrapper);
        return convertToOrderVOs(orders);
    }

    @Override
    @Transactional(readOnly = true)
    public List<OrderVO> getMyPublishedTasks(Integer userId) {
        log.info("获取我发布的任务: userId={}", userId);

        QueryWrapper<Order> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("publisher_id", userId)
                .orderByDesc("create_time");

        List<Order> orders = orderMapper.selectList(queryWrapper);
        return convertToOrderVOs(orders);
    }

    @Override
    @Transactional(readOnly = true)
    public List<OrderVO> getMyAcceptedTasks(Integer userId) {
        log.info("获取我接取的任务: userId={}", userId);

        QueryWrapper<Order> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("runner_id", userId)
                .orderByDesc("create_time");

        List<Order> orders = orderMapper.selectList(queryWrapper);
        return convertToOrderVOs(orders);
    }

    @Override
    @Transactional(readOnly = true)
    public OrderVO getOrderDetail(Integer orderId, Integer userId) {
        log.info("获取订单详情: orderId={}, userId={}", orderId, userId);

        Order order = orderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException("任务不存在");
        }

        // 验证权限：发布者、接单人可以查看
        if (!order.getPublisherId().equals(userId) &&
                (order.getRunnerId() == null || !order.getRunnerId().equals(userId))) {
            // 可以添加管理员权限检查
            throw new BusinessException("无权查看此任务");
        }

        OrderVO orderVO = convertToOrderVO(order);

        // 设置确认状态
        orderVO.setPublisherConfirmed(checkUserConfirmed(orderId, order.getPublisherId(), "publisher"));
        orderVO.setRunnerConfirmed(checkUserConfirmed(orderId, order.getRunnerId(), "runner"));

        return orderVO;
    }

    // 辅助方法：检查用户确认状态
    private Boolean checkUserConfirmed(Integer orderId, Integer userId, String userType) {
        if (userId == null) {
            return false;
        }

        try {
            QueryWrapper<OrderLog> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("order_id", orderId)
                    .eq("operator_id", userId)
                    .like("remark", userType.equals("publisher") ? "发布者确认完成" : "接单人确认完成");
            Long count = orderLogMapper.selectCount(queryWrapper);
            return count > 0;
        } catch (Exception e) {
            log.error("查询确认状态失败: orderId={}, userId={}", orderId, userId, e);
            return false;
        }
    }

    @Override
    @Transactional
    public boolean cancelTask(Integer orderId, Integer userId) {
        log.info("取消任务: orderId={}, userId={}", orderId, userId);

        Order order = orderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException("任务不存在");
        }

        String oldStatus = order.getStatus();

        // 验证权限：发布者或接单人可以在特定状态下取消
        boolean isPublisher = order.getPublisherId().equals(userId);
        boolean isRunner = order.getRunnerId() != null && order.getRunnerId().equals(userId);

        if (!isPublisher && !isRunner) {
            throw new BusinessException("无权取消此任务");
        }

        // 允许取消的状态
        List<String> allowedStatus = Arrays.asList("pending", "accepted", "in_progress");
        if (!allowedStatus.contains(order.getStatus())) {
            throw new BusinessException("当前状态不允许取消");
        }

        // 特定规则：发布者可以取消任何状态，接单人在accepted和in_progress时可以取消
        if (isRunner && !Arrays.asList("accepted", "in_progress").contains(order.getStatus())) {
            throw new BusinessException("接单人只能取消已接单或进行中的任务");
        }

        // 记录原状态，用于后续处理退款
        String originalStatus = order.getStatus();

        order.setStatus("cancelled");
        order.setUpdateTime(LocalDateTime.now());

        int result = orderMapper.updateById(order);

        if (result > 0) {
            String remark = isPublisher ? "发布者取消任务" : "接单人取消接单";
            recordOrderLog(orderId, oldStatus, "cancelled", userId, remark);

            // 如果是接单人取消，需要清空runnerId
            if (isRunner) {
                order.setRunnerId(null);
                orderMapper.updateById(order);
            }

            // 处理退款逻辑（新增）
            handleOrderCancelRefund(order, isPublisher, originalStatus);

            log.info("任务取消成功: orderId={}, userId={}", orderId, userId);
        } else {
            log.error("任务取消失败: orderId={}, userId={}", orderId, userId);
        }

        return result > 0;
    }

    /**
     * 处理订单取消退款（新增方法）
     */
    private void handleOrderCancelRefund(Order order, boolean isPublisher, String originalStatus) {
        try {
            // 只有发布者取消且在pending状态才退款
            if (isPublisher && "pending".equals(originalStatus)) {
                // 订单还未被接单，全额退款
                var refundResult = balanceService.refund(
                        order.getPublisherId(),
                        order.getReward(),
                        order.getId(),
                        "订单取消退款"
                );

                if (refundResult != null && refundResult.getCode() == 200 && Boolean.TRUE.equals(refundResult.getData())) {
                    log.info("订单取消退款成功: orderId={}, amount={}", order.getId(), order.getReward());
                } else {
                    log.warn("订单取消退款处理失败: orderId={}", order.getId());
                }
            }
        } catch (Exception e) {
            log.error("处理订单取消退款异常: orderId={}", order.getId(), e);
        }
    }

    @Override
    @Transactional
    public boolean startTask(Integer orderId, Integer userId) {
        log.info("开始任务: orderId={}, userId={}", orderId, userId);

        Order order = orderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException("任务不存在");
        }

        String oldStatus = order.getStatus();

        // 验证权限：只有接单人可以开始任务
        if (!order.getRunnerId().equals(userId)) {
            throw new BusinessException("只有接单人可以开始任务");
        }

        if (!"accepted".equals(order.getStatus())) {
            throw new BusinessException("只有已接单的任务可以开始");
        }

        order.setStatus("in_progress");
        order.setUpdateTime(LocalDateTime.now());

        int result = orderMapper.updateById(order);

        if (result > 0) {
            // 记录开始日志
            recordOrderLog(orderId, oldStatus, "in_progress", userId, "开始任务");
            log.info("任务开始成功: orderId={}, userId={}", orderId, userId);
        } else {
            log.error("任务开始失败: orderId={}, userId={}", orderId, userId);
        }

        return result > 0;
    }

    @Override
    @Transactional
    public boolean completeTask(Integer orderId, Integer userId) {
        log.info("完成任务: orderId={}, userId={}", orderId, userId);

        Order order = orderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException("任务不存在");
        }

        String oldStatus = order.getStatus();

        // 验证权限：只有接单人可以完成任务
        if (!order.getRunnerId().equals(userId)) {
            throw new BusinessException("只有接单人可以完成任务");
        }

        if (!"in_progress".equals(order.getStatus())) {
            throw new BusinessException("只有进行中的任务可以完成");
        }

        order.setStatus("completed");
        order.setUpdateTime(LocalDateTime.now());

        int result = orderMapper.updateById(order);

        if (result > 0) {
            // 记录完成日志
            recordOrderLog(orderId, oldStatus, "completed", userId, "完成任务");

            // ✅ 完成任务时更新信用分（发布者和接单人都加分）
            if (order.getPublisherId() != null) {
                creditService.updateUserCreditScore(
                        order.getPublisherId(),
                        5,  // 发布者完成任务+5分
                        "task_complete",
                        "任务完成奖励（发布者）-" + order.getOrderNo(),
                        orderId
                );
            }

            if (order.getRunnerId() != null) {
                creditService.updateUserCreditScore(
                        order.getRunnerId(),
                        5,  // 接单人完成任务+5分
                        "task_complete",
                        "任务完成奖励（接单人）-" + order.getOrderNo(),
                        orderId
                );
            }

            // 处理任务完成支付（新增）：将预扣款转移给接单人
            handleTaskCompletePayment(order);

            log.info("任务完成成功: orderId={}, userId={}", orderId, userId);
        } else {
            log.error("任务完成失败: orderId={}, userId={}", orderId, userId);
        }

        return result > 0;
    }

    /**
     * 处理任务完成支付（新增方法）
     */
    private void handleTaskCompletePayment(Order order) {
        try {
            // 给接单人支付报酬
            var paymentResult = balanceService.refund(
                    order.getRunnerId(),
                    order.getReward(),
                    order.getId(),
                    "任务完成报酬支付"
            );

            if (paymentResult != null && paymentResult.getCode() == 200 && Boolean.TRUE.equals(paymentResult.getData())) {
                log.info("任务报酬支付成功: orderId={}, runnerId={}, amount={}",
                        order.getId(), order.getRunnerId(), order.getReward());
            } else {
                log.warn("任务报酬支付处理失败: orderId={}", order.getId());
            }
        } catch (Exception e) {
            log.error("处理任务完成支付异常: orderId={}", order.getId(), e);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public OrderStatsVO getOrderStats(Integer userId) {
        log.info("获取订单统计: userId={}", userId);

        OrderStatsVO stats = new OrderStatsVO();

        stats.setTotalPublished(orderMapper.countByPublisher(userId));
        stats.setTotalAccepted(orderMapper.countByRunner(userId));
        stats.setCompletedPublished(orderMapper.countCompletedByPublisher(userId));
        stats.setCompletedAccepted(orderMapper.countCompletedByRunner(userId));

        log.info("订单统计结果: {}", stats);
        return stats;
    }

    @Override
    @Transactional(readOnly = true)
    public List<OrderLogVO> getOrderLogs(Integer orderId) {
        log.info("获取订单日志: orderId={}", orderId);

        QueryWrapper<OrderLog> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("order_id", orderId)
                .orderByDesc("create_time");

        List<OrderLog> logs = orderLogMapper.selectList(queryWrapper);
        return convertToOrderLogVOs(logs);
    }

    @Override
    @Transactional
    public boolean confirmByPublisher(Integer orderId, Integer publisherId) {
        log.info("发布者确认完成: orderId={}, publisherId={}", orderId, publisherId);

        Order order = orderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException("任务不存在");
        }

        if (!order.getPublisherId().equals(publisherId)) {
            throw new BusinessException("只有发布者可以确认");
        }

        if (!"completed".equals(order.getStatus())) {
            throw new BusinessException("只有已完成的任务可以确认");
        }

        // 记录确认日志
        recordOrderLog(orderId, null, "confirmed", publisherId, "发布者确认完成");

        log.info("发布者确认成功: orderId={}, publisherId={}", orderId, publisherId);
        return true;
    }

    @Override
    @Transactional
    public boolean confirmByRunner(Integer orderId, Integer runnerId) {
        log.info("接单人确认完成: orderId={}, runnerId={}", orderId, runnerId);

        Order order = orderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException("任务不存在");
        }

        if (!order.getRunnerId().equals(runnerId)) {
            throw new BusinessException("只有接单人可以确认");
        }

        if (!"completed".equals(order.getStatus())) {
            throw new BusinessException("只有已完成的任务可以确认");
        }

        // 记录确认日志
        recordOrderLog(orderId, null, "confirmed", runnerId, "接单人确认完成");

        log.info("接单人确认成功: orderId={}, runnerId={}", orderId, runnerId);
        return true;
    }

    /**
     * 记录订单日志的辅助方法
     */
    private void recordOrderLog(Integer orderId, String oldStatus, String newStatus,
                                Integer operatorId, String remark) {
        try {
            OrderLog orderLog = new OrderLog();
            orderLog.setOrderId(orderId);
            orderLog.setOldStatus(oldStatus);
            orderLog.setNewStatus(newStatus);
            orderLog.setOperatorId(operatorId);
            orderLog.setRemark(remark);
            orderLog.setCreateTime(LocalDateTime.now());

            orderLogMapper.insert(orderLog);

            log.debug("订单日志记录成功: orderId={}, oldStatus={}, newStatus={}, operatorId={}, remark={}",
                    orderId, oldStatus, newStatus, operatorId, remark);
        } catch (Exception e) {
            log.error("记录订单日志失败: orderId={}, error={}", orderId, e.getMessage(), e);
            // 这里只是记录错误，不抛出异常，以免影响主要业务逻辑
        }
    }

    /**
     * 转换工具方法：Order列表转OrderVO列表
     */
    private List<OrderVO> convertToOrderVOs(List<Order> orders) {
        List<OrderVO> orderVOs = new ArrayList<>();
        for (Order order : orders) {
            orderVOs.add(convertToOrderVO(order));
        }
        return orderVOs;
    }

    /**
     * 转换工具方法：Order转OrderVO
     */
    private OrderVO convertToOrderVO(Order order) {
        OrderVO orderVO = new OrderVO();
        BeanUtils.copyProperties(order, orderVO);

        // 设置分类名称
        orderVO.setCategoryName(CategoryEnum.getNameByCode(order.getCategory()));

        // 设置状态名称
        orderVO.setStatusName(OrderStatusEnum.getNameByCode(order.getStatus()));

        // 设置格式化时间
        if (order.getCreateTime() != null) {
            orderVO.setCreateTimeStr(order.getCreateTime().format(dateTimeFormatter));
        }
        if (order.getDeadline() != null) {
            orderVO.setDeadlineStr(order.getDeadline().format(dateTimeFormatter));
        }

        // 获取发布者信息
        if (order.getPublisherId() != null) {
            User publisher = userService.getUserEntityById(order.getPublisherId());
            if (publisher != null) {
                orderVO.setPublisherName(publisher.getName());
                orderVO.setPublisherAvatar(publisher.getAvatarUrl());
            }
        }

        // 获取接单人信息
        if (order.getRunnerId() != null) {
            User runner = userService.getUserEntityById(order.getRunnerId());
            if (runner != null) {
                orderVO.setRunnerName(runner.getName());
                orderVO.setRunnerAvatar(runner.getAvatarUrl());
            }
        }

        return orderVO;
    }

    /**
     * 转换工具方法：OrderLog列表转OrderLogVO列表
     */
    private List<OrderLogVO> convertToOrderLogVOs(List<OrderLog> orderLogs) {
        List<OrderLogVO> logVOs = new ArrayList<>();
        for (OrderLog log : orderLogs) {
            logVOs.add(convertToOrderLogVO(log));
        }
        return logVOs;
    }

    /**
     * 转换工具方法：OrderLog转OrderLogVO
     */
    private OrderLogVO convertToOrderLogVO(OrderLog orderLog) {
        OrderLogVO logVO = new OrderLogVO();
        BeanUtils.copyProperties(orderLog, logVO);

        // 获取操作者信息
        if (orderLog.getOperatorId() != null) {
            User operator = userService.getUserEntityById(orderLog.getOperatorId());
            if (operator != null) {
                logVO.setOperatorName(operator.getName());
            }
        }

        return logVO;
    }


    // 另外，需要修改统计方法，避免使用错误的列名
    @Override
    public Map<String, Integer> getAdminOrderStats() {
        log.info("获取管理员任务统计");

        Map<String, Integer> stats = new HashMap<>();

        try {
            // 使用简单的SQL查询，避免复杂的QueryWrapper问题
            QueryWrapper<Order> queryWrapper = new QueryWrapper<>();

            // 总任务数
            queryWrapper.clear();
            Long totalCount = orderMapper.selectCount(queryWrapper);
            stats.put("total", totalCount != null ? totalCount.intValue() : 0);

            // 待接单
            queryWrapper.clear();
            queryWrapper.eq("status", "pending");
            Long pendingCount = orderMapper.selectCount(queryWrapper);
            stats.put("pending", pendingCount != null ? pendingCount.intValue() : 0);

            // 已接单
            queryWrapper.clear();
            queryWrapper.eq("status", "accepted");
            Long acceptedCount = orderMapper.selectCount(queryWrapper);
            stats.put("accepted", acceptedCount != null ? acceptedCount.intValue() : 0);

            // 进行中
            queryWrapper.clear();
            queryWrapper.eq("status", "in_progress");
            Long progressCount = orderMapper.selectCount(queryWrapper);
            stats.put("in_progress", progressCount != null ? progressCount.intValue() : 0);

            // 已完成
            queryWrapper.clear();
            queryWrapper.eq("status", "completed");
            Long completedCount = orderMapper.selectCount(queryWrapper);
            stats.put("completed", completedCount != null ? completedCount.intValue() : 0);

            // 已取消
            queryWrapper.clear();
            queryWrapper.eq("status", "cancelled");
            Long cancelledCount = orderMapper.selectCount(queryWrapper);
            stats.put("cancelled", cancelledCount != null ? cancelledCount.intValue() : 0);

            log.info("管理员任务统计结果: {}", stats);
            return stats;

        } catch (Exception e) {
            log.error("获取管理员任务统计失败", e);
            // 返回空统计
            stats.put("total", 0);
            stats.put("pending", 0);
            stats.put("accepted", 0);
            stats.put("in_progress", 0);
            stats.put("completed", 0);
            stats.put("cancelled", 0);
            return stats;
        }
    }

    // 修改 getAdminOrderList 方法，修复SQL查询问题
    @Override
    @Transactional(readOnly = true)
    public PageResult<OrderVO> getAdminOrderList(Integer page, Integer limit,
                                                 String status, String category,
                                                 String publisher, String runner,
                                                 String time, String search) {
        log.info("获取管理员任务列表: page={}, limit={}, status={}, category={}, publisher={}, runner={}, time={}, search={}",
                page, limit, status, category, publisher, runner, time, search);

        try {
            // 计算分页偏移量
            int offset = (page - 1) * limit;

            // 构建查询条件 - 使用Map存储参数
            Map<String, Object> params = new HashMap<>();

            // 状态筛选
            if (StringUtils.hasText(status)) {
                params.put("status", status);
            }

            // 分类筛选
            if (StringUtils.hasText(category)) {
                params.put("category", category);
            }

            // 时间范围筛选
            if (StringUtils.hasText(time)) {
                LocalDateTime now = LocalDateTime.now();
                LocalDateTime startTime = null;

                switch (time) {
                    case "today":
                        startTime = now.withHour(0).withMinute(0).withSecond(0);
                        params.put("startTime", startTime);
                        break;
                    case "week":
                        startTime = now.minusWeeks(1);
                        params.put("startTime", startTime);
                        break;
                    case "month":
                        startTime = now.minusMonths(1);
                        params.put("startTime", startTime);
                        break;
                }
            }

            // 搜索关键词（订单号、标题、描述）
            if (StringUtils.hasText(search)) {
                params.put("search", "%" + search + "%");
            }

            // 发布者筛选（通过用户ID或姓名）
            if (StringUtils.hasText(publisher)) {
                // 先查询符合条件的用户ID
                QueryWrapper<User> userQuery = new QueryWrapper<>();
                userQuery.like("name", publisher).or().like("student_id", publisher);
                List<User> users = userService.list(userQuery);

                if (!users.isEmpty()) {
                    List<Integer> userIds = users.stream()
                            .map(User::getId)
                            .collect(Collectors.toList());
                    params.put("publisherIds", userIds);
                } else {
                    // 如果没有匹配的用户，返回空结果
                    params.put("emptyPublisher", true);
                }
            }

            // 接单人筛选（通过用户ID或姓名）
            if (StringUtils.hasText(runner)) {
                // 先查询符合条件的用户ID
                QueryWrapper<User> userQuery = new QueryWrapper<>();
                userQuery.like("name", runner).or().like("student_id", runner);
                List<User> users = userService.list(userQuery);

                if (!users.isEmpty()) {
                    List<Integer> userIds = users.stream()
                            .map(User::getId)
                            .collect(Collectors.toList());
                    params.put("runnerIds", userIds);
                } else {
                    // 如果没有匹配的用户，返回空结果
                    params.put("emptyRunner", true);
                }
            }

            // 使用自定义Mapper方法查询
            List<Order> orders;
            Long total;

            // 检查是否有空结果条件
            if ((params.containsKey("emptyPublisher") && (Boolean) params.get("emptyPublisher")) ||
                    (params.containsKey("emptyRunner") && (Boolean) params.get("emptyRunner"))) {
                // 返回空结果
                orders = Collections.emptyList();
                total = 0L;
            } else {
                // 设置分页参数
                params.put("offset", offset);
                params.put("limit", limit);

                // 查询数据
                orders = orderMapper.selectAdminOrderList(params);
                total = orderMapper.countAdminOrderList(params);
            }

            // 转换为VO
            List<OrderVO> orderVOs = convertToOrderVOs(orders);

            return new PageResult<>(orderVOs, total, page, limit);

        } catch (Exception e) {
            log.error("获取管理员任务列表失败", e);
            throw new BusinessException("获取任务列表失败: " + e.getMessage());
        }
    }



    // 在 OrderServiceImpl 中添加以下方法：

    @Override
    public OrderVO getAdminOrderDetail(Integer orderId) {
        log.info("管理员获取订单详情: orderId={}", orderId);

        // 使用自定义SQL查询订单详情
        Order order = orderMapper.selectAdminOrderDetail(orderId);
        if (order == null) {
            throw new BusinessException("订单不存在");
        }

        OrderVO orderVO = convertToOrderVO(order);

        // 获取订单日志
        List<OrderLogVO> logs = getOrderLogs(orderId);
        // 需要在OrderVO中添加logs字段，这里先注释掉
        // orderVO.setLogs(logs);

        return orderVO;
    }

    @Override
    @Transactional
    public boolean adminCancelOrder(Integer orderId) {
        log.info("管理员取消订单: orderId={}", orderId);

        Order order = orderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException("订单不存在");
        }

        // 检查订单状态是否可以取消
        List<String> allowedStatus = Arrays.asList("pending", "accepted", "in_progress");
        if (!allowedStatus.contains(order.getStatus())) {
            throw new BusinessException("当前状态不允许取消");
        }

        String oldStatus = order.getStatus();

        // 更新订单状态
        order.setStatus("cancelled");
        order.setUpdateTime(LocalDateTime.now());

        int result = orderMapper.updateById(order);

        if (result > 0) {
            // 记录取消日志
            recordOrderLog(orderId, oldStatus, "cancelled", null, "管理员取消订单");

            // 处理退款逻辑（如果需要）
            handleAdminCancelRefund(order);

            // 扣除双方信用分
            if (order.getPublisherId() != null) {
                creditService.updateUserCreditScore(
                        order.getPublisherId(),
                        -5,
                        "cancel_order",
                        "管理员取消订单扣除信用分",
                        orderId
                );
            }

            if (order.getRunnerId() != null) {
                creditService.updateUserCreditScore(
                        order.getRunnerId(),
                        -5,
                        "cancel_order",
                        "管理员取消订单扣除信用分",
                        orderId
                );
            }

            log.info("管理员取消订单成功: orderId={}", orderId);
            return true;
        } else {
            log.error("管理员取消订单失败: orderId={}", orderId);
            return false;
        }
    }

    @Override
    @Transactional
    public boolean adminCompleteOrder(Integer orderId) {
        log.info("管理员标记订单完成: orderId={}", orderId);

        Order order = orderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException("订单不存在");
        }

        // 检查订单状态是否可以标记完成
        if (!"in_progress".equals(order.getStatus())) {
            throw new BusinessException("只有进行中的订单可以标记完成");
        }

        String oldStatus = order.getStatus();

        // 更新订单状态
        order.setStatus("completed");
        order.setUpdateTime(LocalDateTime.now());

        int result = orderMapper.updateById(order);

        if (result > 0) {
            // 记录完成日志
            recordOrderLog(orderId, oldStatus, "completed", null, "管理员标记完成");

            // 完成任务奖励和支付
            if (order.getPublisherId() != null) {
                creditService.updateUserCreditScore(
                        order.getPublisherId(),
                        5,
                        "task_complete",
                        "管理员标记完成奖励（发布者）-" + order.getOrderNo(),
                        orderId
                );
            }

            if (order.getRunnerId() != null) {
                creditService.updateUserCreditScore(
                        order.getRunnerId(),
                        5,
                        "task_complete",
                        "管理员标记完成奖励（接单人）-" + order.getOrderNo(),
                        orderId
                );

                // 处理任务完成支付
                handleTaskCompletePayment(order);
            }

            log.info("管理员标记订单完成成功: orderId={}", orderId);
            return true;
        } else {
            log.error("管理员标记订单完成失败: orderId={}", orderId);
            return false;
        }
    }

    // 辅助方法：处理管理员取消订单退款
    private void handleAdminCancelRefund(Order order) {
        try {
            // 根据订单状态处理退款
            if ("pending".equals(order.getStatus())) {
                // 订单还未被接单，全额退款给发布者
                var refundResult = balanceService.refund(
                        order.getPublisherId(),
                        order.getReward(),
                        order.getId(),
                        "管理员取消订单退款"
                );

                if (refundResult != null && refundResult.getCode() == 200 && Boolean.TRUE.equals(refundResult.getData())) {
                    log.info("管理员取消订单退款成功: orderId={}, amount={}", order.getId(), order.getReward());
                }
            } else if ("accepted".equals(order.getStatus()) || "in_progress".equals(order.getStatus())) {
                // 订单已被接单，根据情况部分退款
                // 这里可以根据具体业务规则实现，比如退还50%等
                BigDecimal refundAmount = order.getReward().multiply(new BigDecimal("0.5"));

                var refundResult = balanceService.refund(
                        order.getPublisherId(),
                        refundAmount,
                        order.getId(),
                        "管理员取消订单部分退款"
                );

                if (refundResult != null && refundResult.getCode() == 200 && Boolean.TRUE.equals(refundResult.getData())) {
                    log.info("管理员取消订单部分退款成功: orderId={}, amount={}", order.getId(), refundAmount);
                }
            }
        } catch (Exception e) {
            log.error("处理管理员取消订单退款异常: orderId={}", order.getId(), e);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<OrderVO> exportOrders(String status, String category,
                                      String publisher, String runner,
                                      String time, String search) {
        log.info("导出订单数据: status={}, category={}, publisher={}, runner={}, time={}, search={}",
                status, category, publisher, runner, time, search);

        try {
            // 构建查询条件
            QueryWrapper<Order> queryWrapper = new QueryWrapper<>();

            // 状态筛选
            if (StringUtils.hasText(status)) {
                queryWrapper.eq("status", status);
            }

            // 分类筛选
            if (StringUtils.hasText(category)) {
                queryWrapper.eq("category", category);
            }

            // 时间范围筛选
            if (StringUtils.hasText(time)) {
                LocalDateTime now = LocalDateTime.now();
                LocalDateTime startTime = null;

                switch (time) {
                    case "today":
                        startTime = now.withHour(0).withMinute(0).withSecond(0);
                        queryWrapper.ge("create_time", startTime);
                        break;
                    case "week":
                        startTime = now.minusWeeks(1);
                        queryWrapper.ge("create_time", startTime);
                        break;
                    case "month":
                        startTime = now.minusMonths(1);
                        queryWrapper.ge("create_time", startTime);
                        break;
                }
            }

            // 搜索关键词（订单号、标题、描述）
            if (StringUtils.hasText(search)) {
                queryWrapper.and(wrapper -> wrapper
                        .like("order_no", search)
                        .or().like("title", search)
                        .or().like("description", search));
            }

            // 发布者筛选（通过用户ID）
            if (StringUtils.hasText(publisher)) {
                // 先查询符合条件的用户ID
                QueryWrapper<User> userQuery = new QueryWrapper<>();
                userQuery.like("name", publisher).or().like("student_id", publisher);
                List<User> users = userService.list(userQuery);

                if (!users.isEmpty()) {
                    List<Integer> userIds = users.stream()
                            .map(User::getId)
                            .collect(Collectors.toList());
                    queryWrapper.in("publisher_id", userIds);
                } else {
                    // 如果没有匹配的用户，返回空结果
                    queryWrapper.eq("publisher_id", -1);
                }
            }

            // 接单人筛选（通过用户ID）
            if (StringUtils.hasText(runner)) {
                // 先查询符合条件的用户ID
                QueryWrapper<User> userQuery = new QueryWrapper<>();
                userQuery.like("name", runner).or().like("student_id", runner);
                List<User> users = userService.list(userQuery);

                if (!users.isEmpty()) {
                    List<Integer> userIds = users.stream()
                            .map(User::getId)
                            .collect(Collectors.toList());
                    queryWrapper.in("runner_id", userIds);
                } else {
                    // 如果没有匹配的用户，返回空结果
                    queryWrapper.eq("runner_id", -1);
                }
            }

            // 排序
            queryWrapper.orderByDesc("create_time");

            // 查询所有数据（不分页）
            List<Order> orders = orderMapper.selectList(queryWrapper);

            // 转换为VO
            List<OrderVO> orderVOs = new ArrayList<>();
            for (Order order : orders) {
                OrderVO orderVO = convertToOrderVO(order);
                orderVOs.add(orderVO);
            }

            log.info("导出订单数据成功，共{}条记录", orderVOs.size());
            return orderVOs;

        } catch (Exception e) {
            log.error("导出订单数据失败", e);
            throw new BusinessException("导出数据失败: " + e.getMessage());
        }
    }
}