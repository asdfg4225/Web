package com.campushelper.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.campushelper.dto.FeedbackDTO;
import com.campushelper.dto.FeedbackQueryDTO;
import com.campushelper.dto.FeedbackReplyDTO;
import com.campushelper.entity.Feedback;
import com.campushelper.entity.User;
import com.campushelper.exception.BusinessException;
import com.campushelper.mapper.FeedbackMapper;
import com.campushelper.mapper.UserMapper;
import com.campushelper.service.FeedbackService;
import com.campushelper.vo.FeedbackStatsVO;
import com.campushelper.vo.FeedbackVO;
import com.campushelper.vo.PageResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.TemporalAdjusters;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class FeedbackServiceImpl implements FeedbackService {

    private final FeedbackMapper feedbackMapper;
    private final UserMapper userMapper;

    @Override
    @Transactional
    public void submitFeedback(Integer userId, FeedbackDTO feedbackDTO) {
        // 验证用户是否存在
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }

        // 创建反馈
        Feedback feedback = new Feedback();
        feedback.setUserId(userId);
        feedback.setType(feedbackDTO.getType());
        feedback.setContent(feedbackDTO.getContent());
        feedback.setStatus("pending");

        int result = feedbackMapper.insert(feedback);
        if (result <= 0) {
            throw new BusinessException("提交反馈失败");
        }

        log.info("用户 {} 提交反馈成功，反馈ID: {}", userId, feedback.getId());
    }

    @Override
    public List<FeedbackVO> getMyFeedback(Integer userId) {
        return feedbackMapper.selectMyFeedback(userId);
    }

    @Override
    public FeedbackStatsVO getFeedbackStats() {
        return feedbackMapper.selectFeedbackStats();
    }

    @Override
    public PageResult<FeedbackVO> getFeedbackList(FeedbackQueryDTO queryDTO) {
        // 处理时间筛选
        LocalDateTime startTime = null;
        LocalDateTime endTime = null;

        if (queryDTO.getTime() != null) {
            LocalDateTime now = LocalDateTime.now();
            switch (queryDTO.getTime()) {
                case "today":
                    startTime = now.with(LocalTime.MIN);
                    endTime = now.with(LocalTime.MAX);
                    break;
                case "week":
                    startTime = now.with(TemporalAdjusters.previousOrSame(java.time.DayOfWeek.MONDAY))
                            .with(LocalTime.MIN);
                    endTime = now.with(LocalTime.MAX);
                    break;
                case "month":
                    startTime = now.with(TemporalAdjusters.firstDayOfMonth())
                            .with(LocalTime.MIN);
                    endTime = now.with(LocalTime.MAX);
                    break;
            }
        }

        // 计算分页偏移量
        Integer offset = (queryDTO.getPage() - 1) * queryDTO.getLimit();

        // 查询列表和总数
        List<FeedbackVO> list = feedbackMapper.selectFeedbackList(
                queryDTO.getType(),
                queryDTO.getStatus(),
                startTime,
                endTime,
                offset,
                queryDTO.getLimit()
        );

        Long total = feedbackMapper.countFeedbackList(
                queryDTO.getType(),
                queryDTO.getStatus(),
                startTime,
                endTime
        );

        // 构建分页结果
        PageResult<FeedbackVO> result = new PageResult<>();
        result.setList(list);
        result.setTotal(total);
        result.setPage(queryDTO.getPage());
        result.setLimit(queryDTO.getLimit());

        return result;
    }

    @Override
    public FeedbackVO getFeedbackDetail(Integer id) {
        FeedbackVO feedbackVO = feedbackMapper.selectFeedbackDetail(id);
        if (feedbackVO == null) {
            throw new BusinessException("反馈不存在");
        }
        return feedbackVO;
    }

    @Override
    @Transactional
    public void replyFeedback(Integer id, FeedbackReplyDTO replyDTO) {
        Feedback feedback = feedbackMapper.selectById(id);
        if (feedback == null) {
            throw new BusinessException("反馈不存在");
        }

        if ("resolved".equals(feedback.getStatus())) {
            throw new BusinessException("已解决的反馈不能回复");
        }

        // 更新回复
        feedback.setAdminReply(replyDTO.getReply());
        feedback.setStatus("processing");

        int result = feedbackMapper.updateById(feedback);
        if (result <= 0) {
            throw new BusinessException("回复失败");
        }

        log.info("反馈 {} 已回复", id);
    }

    @Override
    @Transactional
    public void resolveFeedback(Integer id) {
        Feedback feedback = feedbackMapper.selectById(id);
        if (feedback == null) {
            throw new BusinessException("反馈不存在");
        }

        feedback.setStatus("resolved");

        int result = feedbackMapper.updateById(feedback);
        if (result <= 0) {
            throw new BusinessException("标记解决失败");
        }

        log.info("反馈 {} 已标记为解决", id);
    }
}