package com.campushelper.service;

import com.campushelper.dto.*;
import com.campushelper.vo.AdminUserDetailVO;
import com.campushelper.vo.AdminUserListVO;
import com.campushelper.dto.UserStatsDTO;

import java.util.List;

public interface UserAdminService {

    /**
     * 获取用户统计信息
     */
    UserStatsDTO getUserStats();

    /**
     * 获取用户列表（分页+筛选）
     */
    AdminUserListVO getUserList(UserQueryDTO queryDTO);

    /**
     * 获取用户详情
     */
    AdminUserDetailVO getUserDetail(Integer userId);

    /**
     * 认证用户
     */
    void verifyUser(Integer userId);

    /**
     * 封禁用户
     */
    void banUser(Integer userId, String reason);

    /**
     * 解封用户
     */
    void unbanUser(Integer userId);

    /**
     * 重置用户密码
     */
    String resetPassword(Integer userId);

    /**
     * 更新用户信息
     */
    void updateUser(Integer userId, UpdateUserDTO updateUserDTO);

    /**
     * 删除用户
     */
    void deleteUser(Integer userId);

    /**
     * 批量认证用户
     */
    void bulkVerify(List<Integer> userIds);

    /**
     * 批量封禁用户
     */
    void bulkBan(List<Integer> userIds, String reason);

    /**
     * 批量重置密码
     */
    List<String> bulkResetPassword(List<Integer> userIds);

    /**
     * 批量删除用户
     */
    void bulkDelete(List<Integer> userIds);

    /**
     * 导出用户数据（不分页）
     */
    List<AdminUserDTO> exportUsers(UserQueryDTO queryDTO);
}