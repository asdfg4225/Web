package com.campushelper.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.campushelper.dto.UserDTO;
import com.campushelper.entity.User;
import com.campushelper.exception.BusinessException;
import com.campushelper.mapper.UserMapper;
import com.campushelper.service.BalanceService;
import com.campushelper.service.UserService;
import com.campushelper.vo.UserVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserMapper userMapper;
    private final BalanceService balanceService; // 添加余额服务依赖

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        log.debug("正在加载用户: {}", username);

        User user = userMapper.selectByStudentId(username);
        if (user == null) {
            log.error("用户不存在: {}", username);
            throw new UsernameNotFoundException("用户不存在: " + username);
        }

        log.debug("找到用户: {}, ID: {}, 状态: {}", username, user.getId(), user.getStatus());

        // 直接返回User实体，因为User实现了UserDetails接口
        // User类通过getUsername()方法返回studentId，所以不需要设置username字段
        return user;
    }

    @Override
    @Transactional(readOnly = true)
    public User getUserByStudentId(String studentId) {
        return userMapper.selectByStudentId(studentId);
    }

    @Override
    @Transactional(readOnly = true)
    public User getUserByUsername(String username) {
        return getUserByStudentId(username);
    }

    @Override
    @Transactional(readOnly = true)
    public UserDTO getUserById(Integer id) {
        User user = userMapper.selectById(id);
        if (user == null) {
            return null;
        }

        UserDTO userDTO = new UserDTO();
        BeanUtils.copyProperties(user, userDTO);
        userDTO.setUsername(user.getStudentId()); // 这里设置的是UserDTO的username字段
        return userDTO;
    }

    @Override
    @Transactional(readOnly = true)
    public UserVO getUserProfile(Integer userId) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            return null;
        }

        UserVO userVO = new UserVO();
        BeanUtils.copyProperties(user, userVO);
        // 不需要设置username，UserVO会通过getUsername()方法返回studentId
        return userVO;
    }

    @Override
    @Transactional
    public void updateUser(User user) {
        // 只更新允许修改的字段
        User existingUser = userMapper.selectById(user.getId());
        if (existingUser != null) {
            if (user.getName() != null) {
                existingUser.setName(user.getName());
            }
            if (user.getCollege() != null) {
                existingUser.setCollege(user.getCollege());
            }
            if (user.getGrade() != null) {
                existingUser.setGrade(user.getGrade());
            }
            if (user.getAvatarUrl() != null) {
                existingUser.setAvatarUrl(user.getAvatarUrl());
            }
            userMapper.updateById(existingUser);
        }
    }

    @Override
    @Transactional
    public void switchRole(Integer userId, String role) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }

        // 检查是否是管理员用户（根据用户名或特定ID）
        if ("管理员".equals(user.getName()) || userId == 5) {
            throw new BusinessException("管理员用户不能切换角色");
        }

        // 检查要切换的角色是否有效
        if (!"requester".equals(role) && !"runner".equals(role)) {
            throw new BusinessException("无效的角色");
        }

        user.setRole(role);

        int result = userMapper.updateById(user);
        if (result <= 0) {
            throw new BusinessException("角色切换失败");
        }

        log.info("用户 {} 切换角色为 {}", userId, role);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existsByStudentId(String studentId) {
        return userMapper.countByStudentId(studentId) > 0;
    }

    @Override
    @Transactional
    public User saveUser(User user) {
        if (user.getId() == null) {
            // 新增用户时创建钱包
            userMapper.insert(user);
            // 创建用户钱包
            try {
                balanceService.createWallet(user.getId());
                log.info("用户注册成功，已创建钱包: userId={}, studentId={}", user.getId(), user.getStudentId());
            } catch (Exception e) {
                log.error("创建用户钱包失败，但用户已创建: userId={}, error={}", user.getId(), e.getMessage());
                // 这里不抛出异常，因为用户创建成功了，钱包可以在后续补建
            }
        } else {
            userMapper.updateById(user);
        }
        return user;
    }

    @Override
    @Transactional(readOnly = true)
    public User getUserEntityById(Integer id) {
        return userMapper.selectById(id);
    }

    /**
     * 检查用户余额是否充足（新增方法）
     */
    @Override
    @Transactional(readOnly = true)
    public boolean checkUserBalance(Integer userId, BigDecimal amount) {
        if (userId == null || amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }

        try {
            return balanceService.checkBalance(userId, amount);
        } catch (Exception e) {
            log.error("检查用户余额失败: userId={}, amount={}", userId, amount, e);
            return false;
        }
    }

    /**
     * 获取用户余额（新增方法）
     */
    @Override
    @Transactional(readOnly = true)
    public BigDecimal getUserBalance(Integer userId) {
        if (userId == null) {
            return BigDecimal.ZERO;
        }

        try {
            var result = balanceService.getWallet(userId);
            if (result != null && result.getCode() == 200 && result.getData() != null) {
                return result.getData().getBalance();
            }
        } catch (Exception e) {
            log.error("获取用户余额失败: userId={}", userId, e);
        }

        return BigDecimal.ZERO;
    }

    /**
     * 初始化用户钱包（用于现有用户）（新增方法）
     */
    @Override
    @Transactional
    public boolean initUserWallet(Integer userId) {
        try {
            var result = balanceService.createWallet(userId);
            return result != null && result.getCode() == 200;
        } catch (Exception e) {
            log.error("初始化用户钱包失败: userId={}", userId, e);
            return false;
        }
    }

    /**
     * 新增的list方法实现（用于查询用户列表）
     */
    @Override
    @Transactional(readOnly = true)
    public List<User> list(QueryWrapper<User> queryWrapper) {
        return userMapper.selectList(queryWrapper);
    }
}