package com.campushelper.service;

import com.campushelper.entity.CreditLog;
import com.campushelper.vo.CreditOverviewVO;
import com.campushelper.vo.CreditLogVO;

import java.util.List;

public interface CreditService {

    /**
     * 获取信用分概览
     */
    CreditOverviewVO getCreditOverview(Integer userId);

    /**
     * 获取信用分变更记录
     */
    List<CreditLogVO> getCreditLogs(Integer userId, String filterType);

    /**
     * 添加信用分记录
     */
    void addCreditLog(CreditLog creditLog);

    /**
     * 获取用户当前信用分
     */
    Integer getCurrentCreditScore(Integer userId);

    /**
     * 更新用户信用分
     */
    void updateUserCreditScore(Integer userId, Integer changeScore, String changeType,
                               String remark, Integer orderId);

    /**
     * 获取最近N条信用分记录
     */
    List<CreditLogVO> getRecentCreditLogs(Integer userId, Integer limit);
}