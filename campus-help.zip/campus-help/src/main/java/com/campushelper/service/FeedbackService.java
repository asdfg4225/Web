package com.campushelper.service;

import com.campushelper.dto.FeedbackDTO;
import com.campushelper.dto.FeedbackQueryDTO;
import com.campushelper.dto.FeedbackReplyDTO;
import com.campushelper.vo.FeedbackStatsVO;
import com.campushelper.vo.FeedbackVO;
import com.campushelper.vo.PageResult;

import java.util.List;

public interface FeedbackService {

    void submitFeedback(Integer userId, FeedbackDTO feedbackDTO);

    List<FeedbackVO> getMyFeedback(Integer userId);

    FeedbackStatsVO getFeedbackStats();

    PageResult<FeedbackVO> getFeedbackList(FeedbackQueryDTO queryDTO);

    FeedbackVO getFeedbackDetail(Integer id);

    void replyFeedback(Integer id, FeedbackReplyDTO replyDTO);

    void resolveFeedback(Integer id);
}