package com.campushelper.service;

import com.campushelper.dto.EvaluationDTO;
import com.campushelper.utils.Result;
import com.campushelper.vo.UserEvaluationStatsVO;

import java.util.List;

public interface EvaluationService {

    /**
     * 提交评价
     */
    Result<String> submitEvaluation(EvaluationDTO evaluationDTO, Integer fromUserId);

    /**
     * 获取订单的评价列表
     */
    Result<List<?>> getEvaluationsByOrderId(Integer orderId);

    /**
     * 获取用户的评价列表
     */
    Result<List<?>> getEvaluationsByUserId(Integer userId);

    /**
     * 检查是否已评价
     */
    Result<Boolean> checkEvaluationStatus(Integer orderId, Integer userId);

    /**
     * 获取用户评价统计
     */
    Result<UserEvaluationStatsVO> getUserEvaluationStats(Integer userId);
}