package com.campushelper.service;

import com.campushelper.entity.BalanceLog;
import com.campushelper.entity.Wallet;
import com.campushelper.utils.Result;
import com.campushelper.vo.BalanceOverviewVO;
import com.campushelper.vo.BalanceLogVO;

import java.math.BigDecimal;
import java.util.List;

public interface BalanceService {

    /**
     * 获取钱包信息
     */
    Result<Wallet> getWallet(Integer userId);

    /**
     * 获取用户余额
     */
    BigDecimal getUserBalance(Integer userId);

    /**
     * 获取余额概览
     */
    Result<BalanceOverviewVO> getBalanceOverview(Integer userId);

    /**
     * 获取余额变动记录
     */
    Result<List<BalanceLogVO>> getBalanceLogs(Integer userId, Integer page, Integer size);

    /**
     * 发起充值
     */
    Result<String> recharge(Integer userId, BigDecimal amount, String paymentMethod);

    /**
     * 处理充值回调
     */
    Result<Boolean> handleRechargeCallback(String paymentNo, String status);

    /**
     * 消费扣款
     */
    Result<Boolean> consume(Integer userId, BigDecimal amount, Integer orderId, String remark);

    /**
     * 退款
     */
    Result<Boolean> refund(Integer userId, BigDecimal amount, Integer orderId, String remark);

    /**
     * 检查余额是否充足
     */
    boolean checkBalance(Integer userId, BigDecimal amount);

    /**
     * 创建用户钱包（用户注册时调用）
     */
    Result<Boolean> createWallet(Integer userId);

    /**
     * 获取充值状态
     */
    Result<String> getRechargeStatus(String paymentNo);

    /**
     * 获取累计统计
     */
    Result<Wallet> getTotalStats(Integer userId);

    // 在BalanceService.java中添加提现相关方法
    /**
     * 提现申请
     */
    Result<String> withdraw(Integer userId, BigDecimal amount, String method, String remark);

    /**
     * 处理提现回调
     */
    Result<Boolean> handleWithdrawCallback(String withdrawNo, String status);

    /**
     * 获取提现状态
     */
    Result<String> getWithdrawStatus(String withdrawNo);

    /**
     * 获取提现记录
     */
    Result<List<BalanceLogVO>> getWithdrawLogs(Integer userId, Integer page, Integer size);

    /**
     * 获取提现费用
     */
    Result<BigDecimal> calculateWithdrawFee(BigDecimal amount, String method, Integer userId);

    /**
     * 检查是否可以提现
     */
    Result<Boolean> checkWithdrawAvailable(Integer userId);
}