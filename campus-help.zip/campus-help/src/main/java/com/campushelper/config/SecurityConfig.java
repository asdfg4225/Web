package com.campushelper.config;

import com.campushelper.security.JwtAuthenticationFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.List;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                .csrf(AbstractHttpConfigurer::disable)
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(authz -> authz
                        // 允许访问的静态资源和公共API
                        .requestMatchers(
                                "/",
                                "/index.html",
                                "/user.html",
                                "/task-hall.html",
                                "/publish-task.html",
                                "/chat.html",
                                "/order-detail.html",
                                "/evaluate.html",  // 添加评价页面
                                "/credit.html",  // 添加信用分页面
                                "/feedback.html",  // 添加用户反馈页面
                                "/admin-feedback.html",  // 添加管理员反馈页面
                                "/admin-tasks.html",  // 添加管理员任务管理页面
                                "/admin-users.html",  // 添加管理员用户管理页面
                                "/recharge.html",  // 添加充值页面
                                "/withdraw.html",  // 添加提现页面
                                "/error",
                                "/error/**",
                                "/favicon.ico",  // 添加 favicon.ico
                                "/favicon.*"    // 添加 favicon 的各种格式
                        ).permitAll()
                        .requestMatchers("/static/**", "/css/**", "/js/**", "/images/**").permitAll()
                        .requestMatchers("/api/auth/**", "/ws/**").permitAll()
                        .requestMatchers("/api/credit/**").permitAll()
                        .requestMatchers("/api/feedback/submit", "/api/feedback/my").authenticated()
                        .requestMatchers("/api/feedback/stats", "/api/feedback/list", "/api/feedback/detail/**",
                                "/api/feedback/reply/**", "/api/feedback/resolve/**").hasRole("ADMIN")
                        .requestMatchers("/api/recharge/**").authenticated()
                        .requestMatchers("/api/withdraw/**").authenticated()
                        // 管理员任务管理接口
                        .requestMatchers(
                                "/api/order/admin/**",
                                "/api/order/admin/stats",
                                "/api/order/admin/list",
                                "/api/order/admin/detail/**",
                                "/api/order/admin/cancel/**",
                                "/api/order/admin/complete/**",
                                "/api/order/admin/export/**",
                                "/api/order/admin/export/excel",
                                "/api/order/admin/export/json",
                                "/api/order/admin/export/preview"
                        ).hasRole("ADMIN")
                        // 管理员用户管理接口
                        .requestMatchers("/api/user/admin/**").hasRole("ADMIN")
                        .anyRequest().authenticated()
                )
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(List.of("*"));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(Arrays.asList("authorization", "content-type", "x-auth-token"));
        configuration.setExposedHeaders(List.of("x-auth-token"));
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
        return authConfig.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
