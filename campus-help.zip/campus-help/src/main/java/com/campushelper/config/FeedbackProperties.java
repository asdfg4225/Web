package com.campushelper.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "feedback")
public class FeedbackProperties {

    /**
     * 分页默认大小
     */
    private Integer pageSize = 10;

    /**
     * 自动处理时间（小时）
     */
    private Integer autoProcessHours = 72;

    /**
     * 提醒管理员的时间间隔（小时）
     */
    private Integer remindAdminHours = 24;
}